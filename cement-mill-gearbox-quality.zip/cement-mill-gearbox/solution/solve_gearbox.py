#!/usr/bin/env python3
"""Calibrated nonlinear gearbox contact inference and maintenance decisions."""
import os
os.environ.setdefault("OPENBLAS_NUM_THREADS","1")
os.environ.setdefault("OMP_NUM_THREADS","1")
import json,time
from pathlib import Path
import os
os.environ.setdefault('OPENBLAS_NUM_THREADS','1');os.environ.setdefault('OMP_NUM_THREADS','1')
import numpy as np,time,json
from numba import njit
from scipy import optimize,signal

@njit
def pulse(angle,width):
 x=(angle+np.pi)%(2*np.pi)-np.pi
 if abs(x)>=width:return 0.
 return np.cos(.5*np.pi*x/width)**2

@njit
def rhs(q1,q2,v1,v2,th,u1,u2,a1,a2,tooth1,tooth2,b1,b2,eta1,eta2,z1,ratio,coupling,m2,k1,k2,c1,c2,shaft1,shaft2,phase2):
 M=z1;z3=z1/ratio
 p1=pulse(th-2*np.pi*tooth1/z1,np.pi*1.55/z1) if a1>0 else 0.
 p2=pulse(th*ratio-2*np.pi*tooth2/z3,np.pi*1.55/z3) if a2>0 else 0.
 base1=k1*(1+.18*np.cos(M*th)+.035*np.cos(2*M*th))
 base2=k2*(1+.16*np.cos(M*th+phase2)+.045*np.cos(2*M*th+2*phase2))
 # Opening damage weakens the loaded drive flank; coast-side contact has
 # its own qualified stiffness. q and v use scaled displacement/time.
 F1=base1*((1-a1*p1)*max(q1-b1,0.)+eta1*min(q1+b1,0.))
 F2=base2*((1-a2*p2)*max(q2-b2,0.)+eta2*min(q2+b2,0.))
 a=u1-c1*v1-shaft1*q1-F1;d=u2-c2*v2-shaft2*q2-F2
 determinant=m2-coupling*coupling
 return v1,v2,(m2*a-coupling*d)/determinant,(d-coupling*a)/determinant,F1,F2

@njit
def simulation(theta,drive,levels,parameters,teeth,config,dt,subsample):
 # theta at half integration steps; drive holds two applied forces.
 z1,ratio,coupling,m2,k1,k2,c1,c2,shaft1,shaft2,phase2,weight=config
 b1,b2,eta1,eta2=parameters
 records=theta.shape[0];steps=(theta.shape[1]-1)//2
 output=np.zeros((records,steps//subsample));forces=np.zeros((records,2,steps//subsample))
 for r in range(records):
  q1=q2=v1=v2=0.;a1=levels[r,0];a2=levels[r,1];tooth1=teeth[0];tooth2=teeth[1]
  for n in range(steps):
   h=2*n;th=theta[r,h];thh=theta[r,h+1];th1=theta[r,h+2]
   u=drive[r,h];uh=drive[r,h+1];u1=drive[r,h+2]
   A=rhs(q1,q2,v1,v2,th,u[0],u[1],a1,a2,tooth1,tooth2,b1,b2,eta1,eta2,z1,ratio,coupling,m2,k1,k2,c1,c2,shaft1,shaft2,phase2)
   B=rhs(q1+.5*dt*A[0],q2+.5*dt*A[1],v1+.5*dt*A[2],v2+.5*dt*A[3],thh,uh[0],uh[1],a1,a2,tooth1,tooth2,b1,b2,eta1,eta2,z1,ratio,coupling,m2,k1,k2,c1,c2,shaft1,shaft2,phase2)
   C=rhs(q1+.5*dt*B[0],q2+.5*dt*B[1],v1+.5*dt*B[2],v2+.5*dt*B[3],thh,uh[0],uh[1],a1,a2,tooth1,tooth2,b1,b2,eta1,eta2,z1,ratio,coupling,m2,k1,k2,c1,c2,shaft1,shaft2,phase2)
   D=rhs(q1+dt*C[0],q2+dt*C[1],v1+dt*C[2],v2+dt*C[3],th1,u1[0],u1[1],a1,a2,tooth1,tooth2,b1,b2,eta1,eta2,z1,ratio,coupling,m2,k1,k2,c1,c2,shaft1,shaft2,phase2)
   q1+=dt/6*(A[0]+2*B[0]+2*C[0]+D[0]);q2+=dt/6*(A[1]+2*B[1]+2*C[1]+D[1])
   v1+=dt/6*(A[2]+2*B[2]+2*C[2]+D[2]);v2+=dt/6*(A[3]+2*B[3]+2*C[3]+D[3])
   if n%subsample==subsample-1:
    R=rhs(q1,q2,v1,v2,th1,u1[0],u1[1],a1,a2,tooth1,tooth2,b1,b2,eta1,eta2,z1,ratio,coupling,m2,k1,k2,c1,c2,shaft1,shaft2,phase2)
    j=n//subsample;output[r,j]=R[4]+weight*R[5];forces[r,0,j]=R[4];forces[r,1,j]=R[5]
 return output,forces

def inputs(speeds,loads,config,seconds=.75,rate=8192.):
 steps=int(round(seconds*rate));t=np.arange(2*steps+1)/(2*rate)
 theta=[];drive=[]
 z1=config[0]
 for i,(rpm,L) in enumerate(zip(speeds,loads)):
  th=2*np.pi*rpm/60*t+.012*np.sin(2*np.pi*1.3*t+i*.7)
  ramp=np.minimum(t/.025,1.)
  f1=ramp*(L+.63*np.cos(z1*th+.2)+.075*np.sin(th))
  f2=ramp*(.82*L+.59*np.cos(z1*th+1.6)+.065*np.sin(config[1]*th+.4))
  theta.append(th);drive.append(np.column_stack([f1,f2]))
 return np.asarray(theta),np.asarray(drive),2*np.pi*260/rate


import numpy as np
from numba import njit


@njit
def intensity(levels,parameters,teeth,config,rpm,load,resolution=48,settle=3,measure=3):
 z1,ratio,coupling,m2,k1,k2,c1,c2,shaft1,shaft2,phase2,weight=config
 b1,b2,eta1,eta2=parameters;a1,a2=levels;j1,j2=teeth
 intervals=int(round(z1*resolution/ratio));N=(settle+measure)*intervals
 omega=2*np.pi*rpm/60.;step_phase=2*np.pi/(z1*resolution);dt=step_phase/omega*(2*np.pi*260.)
 q1=q2=v1=v2=0.;s1=s2=norm1=norm2=0.
 for n in range(N):
  ph=n*step_phase;phh=ph+step_phase*.5;phe=ph+step_phase
  u1=load+.63*np.cos(z1*ph+.2)+.075*np.sin(ph)
  u2=.82*load+.59*np.cos(z1*ph+1.6)+.065*np.sin(ratio*ph+.4)
  u1h=load+.63*np.cos(z1*phh+.2)+.075*np.sin(phh)
  u2h=.82*load+.59*np.cos(z1*phh+1.6)+.065*np.sin(ratio*phh+.4)
  u1e=load+.63*np.cos(z1*phe+.2)+.075*np.sin(phe)
  u2e=.82*load+.59*np.cos(z1*phe+1.6)+.065*np.sin(ratio*phe+.4)
  A=rhs(q1,q2,v1,v2,ph,u1,u2,a1,a2,j1,j2,b1,b2,eta1,eta2,z1,ratio,coupling,m2,k1,k2,c1,c2,shaft1,shaft2,phase2)
  B=rhs(q1+.5*dt*A[0],q2+.5*dt*A[1],v1+.5*dt*A[2],v2+.5*dt*A[3],phh,u1h,u2h,a1,a2,j1,j2,b1,b2,eta1,eta2,z1,ratio,coupling,m2,k1,k2,c1,c2,shaft1,shaft2,phase2)
  C=rhs(q1+.5*dt*B[0],q2+.5*dt*B[1],v1+.5*dt*B[2],v2+.5*dt*B[3],phh,u1h,u2h,a1,a2,j1,j2,b1,b2,eta1,eta2,z1,ratio,coupling,m2,k1,k2,c1,c2,shaft1,shaft2,phase2)
  D=rhs(q1+dt*C[0],q2+dt*C[1],v1+dt*C[2],v2+dt*C[3],phe,u1e,u2e,a1,a2,j1,j2,b1,b2,eta1,eta2,z1,ratio,coupling,m2,k1,k2,c1,c2,shaft1,shaft2,phase2)
  q1+=dt/6*(A[0]+2*B[0]+2*C[0]+D[0]);q2+=dt/6*(A[1]+2*B[1]+2*C[1]+D[1])
  v1+=dt/6*(A[2]+2*B[2]+2*C[2]+D[2]);v2+=dt/6*(A[3]+2*B[3]+2*C[3]+D[3])
  if n>=settle*intervals:
   R=rhs(q1,q2,v1,v2,phe,u1e,u2e,a1,a2,j1,j2,b1,b2,eta1,eta2,z1,ratio,coupling,m2,k1,k2,c1,c2,shaft1,shaft2,phase2)
   h1=pulse(phe-2*np.pi*j1/z1,np.pi*1.55/z1)
   h2=pulse(phe*ratio-2*np.pi*j2/(z1/ratio),np.pi*1.55/(z1/ratio))
   s1+=h1*max(R[4],0.)**2;norm1+=h1
   s2+=h2*max(R[5],0.)**2;norm2+=h2
 return np.array([np.sqrt(s1/max(norm1,1e-20)),np.sqrt(s2/max(norm2,1e-20))])


import numpy as np
from numba import njit


def build_fields(params,teeth,cfg,duties,replacement,spacing=.05,resolution=48):
 n=int(round(.45/spacing))+1;grid=np.linspace(0,.45,n);fields=np.zeros((len(duties),3,n,n,2))
 for d,(rpm,load) in enumerate(duties):
  for i,x in enumerate(grid):
   for j,y in enumerate(grid):fields[d,0,i,j]=intensity(np.array([x,y]),params,teeth,cfg,rpm,load,resolution)
  p=params.copy();p[0]=replacement[0];p[2]=replacement[2]
  for j,y in enumerate(grid):fields[d,1,:,j]=intensity(np.array([0.,y]),p,teeth,cfg,rpm,load,resolution)
  p=params.copy();p[1]=replacement[1];p[3]=replacement[3]
  for i,x in enumerate(grid):fields[d,2,i,:]=intensity(np.array([x,0.]),p,teeth,cfg,rpm,load,resolution)
 return grid,fields

@njit
def rate(a1,a2,d,mode,fields,max_alpha,coeff,exp,rpm,ratio):
 n=fields.shape[2];xx=max(0.,min(a1,max_alpha))/max_alpha*(n-1);yy=max(0.,min(a2,max_alpha))/max_alpha*(n-1)
 i=min(int(xx),n-2);j=min(int(yy),n-2);u=xx-i;v=yy-j
 ans=np.zeros(2)
 for k,a in enumerate((a1,a2)):
  if a<=0.:continue
  I=(1-u)*(1-v)*fields[d,mode,i,j,k]+u*(1-v)*fields[d,mode,i+1,j,k]+(1-u)*v*fields[d,mode,i,j+1,k]+u*v*fields[d,mode,i+1,j+1,k]
  cycles=rpm*60*(1. if k==0 else ratio)
  ans[k]=coeff[k]*cycles*max(0.,I)**exp[k]*a/(1-a)**2
 return ans

@njit
def trajectory(start,scenario,fields,max_alpha,coeff,exponents,duties,ratio,limit=.4,plan_time=-1.,mask=0,max_step=.04):
 alpha=start.copy();peak=max(alpha);t=0.;mode=0;acted=False
 for r in range(scenario.shape[0]):
  d=int(scenario[r,0]);end=t+scenario[r,1];rpm=duties[d,0]
  while t<end-1e-10:
   if mask and not acted and t>=plan_time-1e-9:
    if mask&1:alpha[0]=0.
    if mask&2:alpha[1]=0.
    if mask==3:return -1.,peak
    mode=mask;acted=True
   h=min(max_step,end-t)
   if mask and not acted and t<plan_time<t+h:h=plan_time-t
   k1=rate(alpha[0],alpha[1],d,mode,fields,max_alpha,coeff,exponents,rpm,ratio)
   k2=rate(alpha[0]+h*k1[0]/2,alpha[1]+h*k1[1]/2,d,mode,fields,max_alpha,coeff,exponents,rpm,ratio)
   k3=rate(alpha[0]+h*k2[0]/2,alpha[1]+h*k2[1]/2,d,mode,fields,max_alpha,coeff,exponents,rpm,ratio)
   k4=rate(alpha[0]+h*k3[0],alpha[1]+h*k3[1],d,mode,fields,max_alpha,coeff,exponents,rpm,ratio)
   following=alpha+h*(k1+2*k2+2*k3+k4)/6
   if max(following)>=limit:
    fraction=1.
    for k in range(2):
     if following[k]>=limit and following[k]>alpha[k]:fraction=min(fraction,(limit-alpha[k])/(following[k]-alpha[k]))
    return t+h*max(0.,fraction),max(peak,limit)
   alpha=following;peak=max(peak,max(alpha));t+=h
 return -1.,peak

def evaluate(start,scenarios,fields,grid,coeff,exp,duties,ratio,plans,max_step=.04,planning_limit=.36):
 forecasts={};plan_results=[]
 for name,rows in scenarios.items():
  crossing,peak=trajectory(start,rows,fields,grid[-1],coeff,exp,duties,ratio,max_step=max_step)
  forecasts[name]=None if crossing<0 else float(crossing)
 for plan in plans:
  runs=[]
  for name,rows in scenarios.items():
   crossing,peak=trajectory(start,rows,fields,grid[-1],coeff,exp,duties,ratio,limit=planning_limit,plan_time=plan['time'],mask=plan['mask'],max_step=max_step)
   runs.append({'scenario':name,'crossing':None if crossing<0 else float(crossing),'peak':float(peak)})
  plan_results.append({'plan_id':plan['plan_id'],'cost_units':plan['cost_units'],'safe':all(r['crossing'] is None for r in runs),'peak':max(r['peak'] for r in runs),'runs':runs})
 best=min((p for p in plan_results if p['safe']),key=lambda p:p['cost_units'])
 finite=[x for x in forecasts.values() if x is not None]
 bounds={'by_scenario':forecasts,'earliest':min(finite) if finite else None,'latest':max(finite) if len(finite)==len(forecasts) else None}
 return {'forecast_hours':bounds,'maintenance_plan':{'plan_id':best['plan_id'],'worst_case_peak_loss':best['peak']},'plan_results':plan_results}

MEMBERS=['stage1_pinion','stage2_pinion']
AXES=['ax_g','ay_g','az_g']

def calibrate_mounts(frame,fs,F0):
 answers=[]
 for axis in AXES:
  part=frame[frame.axis==axis];freq=part.frequency_hz.to_numpy();h=(part.real_g_per_N.to_numpy()+1j*part.imag_g_per_N.to_numpy())*F0
  source=(part.source=='stage2').to_numpy().astype(int);omega=2*fs*np.tan(np.pi*freq/fs)
  f=part[part.source=='stage1'];index=np.argmax(np.hypot(f.real_g_per_N,f.imag_g_per_N));peak=f.frequency_hz.iloc[index]
  fn0=fs/np.pi*np.tan(np.pi*peak/fs);g0=[]
  for s in ['stage1','stage2']:
   row=part[part.source==s].iloc[-1];g0.append(float(row.real_g_per_N*F0))
  def residual(p):
   wn=2*np.pi*p[0];model=np.asarray(p[2:])[source]*(-omega*omega)/(wn*wn-omega*omega+2j*p[1]*wn*omega)
   e=(model-h)/(abs(h)+.0005);return np.r_[e.real,e.imag]
  fit=optimize.least_squares(residual,[fn0,.13,*g0],bounds=([200,.03,-1,-1],[1600,.5,1,1]),x_scale=[700,.15,.1,.1],ftol=1e-11,xtol=1e-11,gtol=1e-11)
  wn=2*np.pi*fit.x[0];b,a=signal.bilinear([1,0,0],[1,2*fit.x[1]*wn,wn*wn],fs=fs)
  answers.append((fit.x,b,a))
 return answers

def read_experiment(folder,substeps=2):
 import pandas as pd
 folder=Path(folder);spec=json.loads((folder/'gearbox.json').read_text());records=pd.read_csv(folder/'records.csv');obs=pd.read_csv(folder/'observations.csv');raw=pd.read_csv(folder/'vibration_windows.csv')
 fs=spec['sampling_rate_hz'];scale=spec['force_scale_N'];mounts=calibrate_mounts(pd.read_csv(folder/'transfer_calibration.csv'),fs,scale)
 cal,b,a=mounts[0];teeth=spec['teeth'];ratio=teeth['stage1_pinion']/teeth['stage1_wheel'];mass=spec['mass_matrix']
 config=np.array([teeth['stage1_pinion'],ratio,mass[0][1],mass[1][1],*spec['drive_mesh_stiffness'],*spec['modal_damping'],*spec['shaft_stiffness'],spec['mesh_phase_stage2_rad'],cal[3]/cal[2]])
 theta=[];drive=[];data=[];group=[];mapping={int(oid):i+1 for i,oid in enumerate(obs.observation_id)};mapping[0]=0
 for r in records.itertuples(index=False):
  v=raw[raw.record_id==r.record_id];T=v.input_angle_rad.to_numpy();U=v[['force1_N','force2_N']].to_numpy()/scale
  old=np.arange(len(v));dense=np.arange((len(v)-1)*substeps*2+1)/(substeps*2)
  theta.append(np.interp(dense,old,T));drive.append(np.column_stack([np.interp(dense,old,U[:,j]) for j in range(2)]));data.append(v.ax_g.to_numpy()/cal[2]);group.append(mapping[int(r.observation_id)])
 data=np.asarray(data);valid=np.isfinite(data);valid[:,:30]=False;observed=np.nan_to_num(data)
 return {'spec':spec,'observations':obs,'records':records,'theta':np.asarray(theta),'drive':np.asarray(drive),'data':observed,'valid':valid,'groups':np.asarray(group),'config':config,'b':b,'a':a,'dt':spec['reference_angular_frequency_rad_per_s']/(fs*substeps),'substeps':substeps,'mounts':mounts,'noise':spec['measurement_noise_standard_deviation_g']/abs(cal[2])}

def infer_physical_state(experiment,settings=None):
 settings={} if settings is None else settings
 ex=experiment;nobs=len(ex['observations']);nrec=len(ex['records']);group=ex['groups'];cfg=ex['config'];xscale=ex['spec']['displacement_scale_um']
 bound=ex['spec']['parameter_bounds'];lo=np.r_[np.repeat(bound['backlash_halfwidth_um'][0]/xscale,2),np.repeat(bound['coast_stiffness_ratio'][0],2)];hi=np.r_[np.repeat(bound['backlash_halfwidth_um'][1]/xscale,2),np.repeat(bound['coast_stiffness_ratio'][1],2)]
 stride=np.zeros(ex['data'].shape,dtype=bool);stride[:,::2]=True;valid=ex['valid']&stride;zero=np.zeros((nrec,2));empty=np.array([0,0],dtype=np.int64)
 def predict(p,levels,j,selection=None):
  tt=ex['theta'] if selection is None else ex['theta'][selection];uu=ex['drive'] if selection is None else ex['drive'][selection]
  out,_=simulation(tt,uu,levels,p,j,cfg,ex['dt'],ex['substeps']);out=np.c_[np.zeros(len(out)),out]
  return signal.lfilter(ex['b'],ex['a'],out,axis=1)
 def baseline_res(p):return (predict(p,zero,empty)-ex['data'])[valid]
 rough=optimize.least_squares(baseline_res,[.18,.20,.78,.78],bounds=(lo,hi),loss='soft_l1',f_scale=3*ex['noise'],x_scale='jac',diff_step=1e-4,max_nfev=50,ftol=1e-7).x
 latest=np.flatnonzero(group==nobs);data=ex['data'][latest];use=valid[latest];baseline=predict(rough,np.zeros((len(latest),2)),empty,latest);residual=(data-baseline)[use]
 templates=[];labels=[]
 for stage,count in enumerate([int(cfg[0]),int(round(cfg[0]/cfg[1]))]):
  block=[]
  for j in range(count):
   index=np.array([0,0],dtype=np.int64);index[stage]=j;lev=np.zeros((len(latest),2));lev[:,stage]=.12
   block.append(((predict(rough,lev,index,latest)-baseline)/.12)[use])
  templates.append(np.asarray(block));labels.append(np.arange(count))
 T1,T2=templates;g1=T1@residual;g2=T2@residual;d1=np.sum(T1*T1,axis=1);d2=np.sum(T2*T2,axis=1);cross=T1@T2.T
 den=d1[:,None]*d2[None,:]-cross*cross;coef1=(g1[:,None]*d2[None,:]-g2[None,:]*cross)/np.maximum(den,1e-15);coef2=(g2[None,:]*d1[:,None]-g1[:,None]*cross)/np.maximum(den,1e-15)
 coef1=np.clip(coef1,0,.44);coef2=np.clip(coef2,0,.44)
 score=-2*(coef1*g1[:,None]+coef2*g2[None,:])+coef1**2*d1[:,None]+coef2**2*d2[None,:]+2*coef1*coef2*cross
 order=np.argsort(score.ravel());best=None;tested=[]
 for pick in order[:8]:
  j1,j2=np.unravel_index(pick,score.shape);index=np.array([j1,j2],dtype=np.int64)
  def late_res(p):return (predict(p[:4],np.repeat(p[4:][None,:],len(latest),axis=0),index,latest)-data)[use]
  initial=np.r_[rough,max(.001,coef1[j1,j2]),max(.001,coef2[j1,j2])]
  fit=optimize.least_squares(late_res,initial,bounds=(np.r_[lo,0,0],np.r_[hi,.44,.44]),diff_step=1e-4,x_scale='jac',max_nfev=35,ftol=1e-7)
  error=float(np.sqrt(np.mean(fit.fun**2)));tested.append([int(j1),int(j2),error])
  if best is None or error<best[0]:best=(error,index,fit.x)
  if error<1.5*ex['noise']:break
 index=best[1];p0=best[2];scale=np.linspace(.3,1.,nobs)[:,None];init_losses=scale*p0[4:][None,:]
 def all_res(p):
  losses=np.vstack([np.zeros(2),p[4:].reshape(nobs,2)]);error=(predict(p[:4],losses[group],index)-ex['data'])[valid]
  return error
 initial=np.r_[p0[:4],init_losses.ravel()];fit=optimize.least_squares(all_res,initial,bounds=(np.r_[lo,np.zeros(nobs*2)],np.r_[hi,np.full(nobs*2,.44)]),diff_step=1e-4,x_scale='jac',ftol=1e-8,xtol=1e-8,max_nfev=70)
 states=fit.x[4:].reshape(nobs,2);present=states[-1]>=ex['spec']['stiffness_loss_detection'];states[:,~present]=0.
 return fit.x[:4],states,index,{'rms_force_residual':float(np.sqrt(np.mean(fit.fun**2))),'tested_tooth_pairs':tested,'n_evaluations':fit.nfev}

def fit_fatigue(folder):
 import pandas as pd
 data=pd.read_csv(Path(folder)/'fatigue_tests.csv');coeff=[];exponents=[]
 for member in MEMBERS:
  p=data[data.member==member];alpha=p.stiffness_loss.to_numpy();I=p.root_load_rms_over_reference.to_numpy();rate=p.loss_rate_per_pinion_cycle.to_numpy()
  slope,intercept=np.polyfit(np.log(I),np.log(rate*(1-alpha)**2/alpha),1);coeff.append(np.exp(intercept));exponents.append(slope)
 return np.asarray(coeff),np.asarray(exponents)

def planning_inputs(folder,scale):
 import pandas as pd
 future=pd.read_csv(Path(folder)/'future_duty.csv');policy=json.loads((Path(folder)/'maintenance_policy.json').read_text())
 duties=np.unique(future[['input_rpm','force_multiplier']].to_numpy(),axis=0);scenarios={}
 for name,part in future.groupby('scenario_id',sort=False):
  rows=[]
  for row in part.sort_values('segment_id').itertuples(index=False):
   d=int(np.flatnonzero((duties[:,0]==row.input_rpm)&(duties[:,1]==row.force_multiplier))[0]);rows.append([d,row.duration_hours])
  scenarios[name]=np.asarray(rows)
 replacement=np.r_[np.asarray(policy['replacement']['backlash_halfwidth_um'])/scale,policy['replacement']['coast_stiffness_ratio']]
 plans=[{'plan_id':p['plan_id'],'time':p['at_operating_hour'],'mask':sum(1<<MEMBERS.index(member) for member in p['replace']),'cost_units':p['cost_units']} for p in policy['plans']]
 return duties,scenarios,replacement,plans

def main(folder,output):
 import pandas as pd
 begin=time.monotonic();ex=read_experiment(folder);parameters,states,teeth,diagnostics=infer_physical_state(ex);coeff,exponents=fit_fatigue(folder);duties,scenarios,replacement,plans=planning_inputs(folder,ex['spec']['displacement_scale_um'])
 grid,fields=build_fields(parameters,teeth,ex['config'],duties,replacement,spacing=.045,resolution=48)
 decision=evaluate(states[-1],scenarios,fields,grid,coeff,exponents,duties,ex['config'][1],plans,max_step=.025)
 result={'faults':{member:int(teeth[j]) if states[-1,j]>=ex['spec']['stiffness_loss_detection'] else None for j,member in enumerate(MEMBERS)},'contact_parameters':{'backlash_halfwidth_um':(parameters[:2]*ex['spec']['displacement_scale_um']).tolist(),'coast_stiffness_ratio':parameters[2:].tolist()},'forecast_hours':decision['forecast_hours'],'maintenance_plan':decision['maintenance_plan']}
 output=Path(output);output.mkdir(parents=True,exist_ok=True);pd.DataFrame({'observation_id':ex['observations'].observation_id,'loss_stage1':states[:,0],'loss_stage2':states[:,1]}).to_csv(output/'gearbox_condition_assessment.csv',index=False)
 (output/'summary.json').write_text(json.dumps(result,indent=2,allow_nan=False)+'\n')
 print(json.dumps({'seconds':time.monotonic()-begin,'faults':result['faults'],'forecast':result['forecast_hours'],'plan':result['maintenance_plan'],'diagnostics':diagnostics}),flush=True)
 return result

if __name__=='__main__':
 import argparse
 parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('input_directory');parser.add_argument('output_directory');args=parser.parse_args();main(args.input_directory,args.output_directory)
