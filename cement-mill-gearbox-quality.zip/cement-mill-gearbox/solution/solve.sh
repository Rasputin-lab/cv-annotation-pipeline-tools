#!/bin/bash
set -euo pipefail
mkdir -p /logs/artifacts /root/results/example
cp /solution/solve_gearbox.py /logs/artifacts/solve_gearbox.py
chmod 644 /logs/artifacts/solve_gearbox.py
OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 python3 /logs/artifacts/solve_gearbox.py /root/data/unit_A /root/results/example
