#!/bin/bash
set -uo pipefail
mkdir -p /logs/verifier /logs/artifacts /root/agent_output /root/results
chmod 700 /logs/verifier /root/agent_output
printf '0\n' > /logs/verifier/reward.txt
chmod -R go-rwx /tests
if ! id nobody >/dev/null 2>&1 || ! command -v runuser >/dev/null 2>&1 || ! command -v pkill >/dev/null 2>&1; then
  exit 1
fi
SOLVER_DIR="$(mktemp -d)"
if [ -f /logs/artifacts/solve_gearbox.py ]; then
  cp /logs/artifacts/solve_gearbox.py "$SOLVER_DIR/solve_gearbox.py"
fi
chown -R nobody "$SOLVER_DIR"
chmod -R u+rwX,go-rwx "$SOLVER_DIR"
for unit in unit_B unit_C unit_D unit_E unit_F unit_G; do
  SCRATCH="$(mktemp -d)"
  mkdir "$SCRATCH/input" "$SCRATCH/output"
  cp -r "/tests/held_out/$unit/." "$SCRATCH/input/"
  rm -f "$SCRATCH/input/truth.json"
  chown -R nobody "$SCRATCH"
  chmod -R u+rwX,go-rwx "$SCRATCH"
  DEST="/root/agent_output/$unit"
  rm -rf "$DEST"
  mkdir -m 700 "$DEST"
  setsid timeout -k 5 300 runuser -u nobody -- bash -c 'cd "$1"; exec python3 "$2" "$3" "$4"' _ \
    "$SCRATCH" "$SOLVER_DIR/solve_gearbox.py" "$SCRATCH/input" "$SCRATCH/output" \
    > "/logs/verifier/$unit.stdout.log" 2> "/logs/verifier/$unit.stderr.log"
  STATUS=$?
  printf '%s\n' "$STATUS" > "/logs/verifier/$unit.exit_code.txt"
  pkill -9 -u nobody 2>/dev/null || true
  if [ "$STATUS" -eq 0 ]; then
    for artifact in gearbox_condition_assessment.csv summary.json; do
      # Read as the same unprivileged identity. A symlink cannot cause a root
      # read of private targets or the reward directory during collection.
      timeout -k 1 10 runuser -u nobody -- /bin/cat -- "$SCRATCH/output/$artifact" \
        | head -c 2000001 > "$DEST/$artifact"
    done
  fi
  rm -rf "$SCRATCH"
done
rm -rf "$SOLVER_DIR"
pytest /tests/test_gearbox_condition.py -rA --ctrf=/logs/verifier/ctrf.json
STATUS=$?
if [ "$STATUS" -eq 0 ]; then
  printf '1\n' > /logs/verifier/reward.txt
else
  printf '0\n' > /logs/verifier/reward.txt
fi
exit "$STATUS"
