"""Outcome grading against independently generated physical states and decisions."""
import json,math
from pathlib import Path
import numpy as np
import pandas as pd
import pytest

MEMBERS=('stage1_pinion','stage2_pinion')
SUMMARY={'faults','contact_parameters','forecast_hours','maintenance_plan'}
CSV={'observation_id','loss_stage1','loss_stage2'}
def finite(x):return type(x) in (int,float) and math.isfinite(x)
def unique(pairs):
 out={}
 for k,v in pairs:
  if k in out:raise ValueError('duplicate JSON key')
  out[k]=v
 return out

def read_json(path):
 if path.stat().st_size>2000000:raise ValueError('artifact too large')
 def bad(_):raise ValueError('nonfinite JSON')
 return json.loads(path.read_text(),object_pairs_hook=unique,parse_constant=bad)

def grade_prediction(expected,table,summary,folder,check_physics=True):
 folder=Path(folder);failures=[];metrics={}
 def check(condition,label):
  if not condition:failures.append(label)
  return bool(condition)
 try:
  observations=pd.read_csv(folder/'observations.csv');spec=json.loads((folder/'gearbox.json').read_text());policy=json.loads((folder/'maintenance_policy.json').read_text())
  if not check(isinstance(summary,dict) and set(summary)==SUMMARY,'summary schema'):return {'passed':False,'failures':failures,'metrics':metrics}
  if not check(set(table.columns)==CSV and len(table)==len(observations),'CSV schema/count'):return {'passed':False,'failures':failures,'metrics':metrics}
  numeric=table.apply(pd.to_numeric,errors='coerce')
  if not check(np.isfinite(numeric.to_numpy()).all(),'finite CSV'):return {'passed':False,'failures':failures,'metrics':metrics}
  check(np.array_equal(numeric.observation_id,observations.observation_id),'observation identifiers/order')
  states=numeric[['loss_stage1','loss_stage2']].to_numpy();metrics['max_loss_error']=float(np.max(abs(states-np.asarray(expected['losses']))))
  check(np.min(states)>=0 and np.max(states)<=.45,'physical stiffness-loss range')
  check(metrics['max_loss_error']<=.008,'stiffness-loss trajectory')
  faults=summary['faults']
  if not check(isinstance(faults,dict) and set(faults)==set(MEMBERS),'fault schema'):return {'passed':False,'failures':failures,'metrics':metrics}
  for j,member in enumerate(MEMBERS):
   value=faults[member];count=spec['teeth'][member]
   check(value is None or (type(value) is int and 0<=value<count),'tooth-index convention for '+member)
   check(value==expected['faults'][member],'tooth location for '+member)
   check((value is None)==(states[-1,j]<spec['stiffness_loss_detection']),'fault/loss consistency for '+member)
  contact=summary['contact_parameters']
  if not check(isinstance(contact,dict) and set(contact)=={'backlash_halfwidth_um','coast_stiffness_ratio'},'contact schema'):return {'passed':False,'failures':failures,'metrics':metrics}
  for key,tol in [('backlash_halfwidth_um',3.),('coast_stiffness_ratio',.018)]:
   values=contact[key];valid=isinstance(values,list) and len(values)==2 and all(finite(x) and x>0 for x in values)
   if not check(valid,'contact '+key):return {'passed':False,'failures':failures,'metrics':metrics}
   error=float(np.max(abs(np.array(values)-expected['contact_parameters'][key])));metrics['max_'+key+'_error']=error
   check(error<=tol,'physical '+key)
  future=summary['forecast_hours'];wanted=expected['forecast_hours'];scenario_names=set(pd.read_csv(folder/'future_duty.csv').scenario_id)
  if not check(isinstance(future,dict) and set(future)=={'by_scenario','earliest','latest'} and isinstance(future['by_scenario'],dict) and set(future['by_scenario'])==scenario_names,'forecast schema'):return {'passed':False,'failures':failures,'metrics':metrics}
  def same(left,right,tolerance):
   return (left is None and right is None) or (finite(left) and finite(right) and left>=0 and abs(left-right)<=tolerance(right))
  times=list(future['by_scenario'].values());valid=all(v is None or (finite(v) and 0<=v<=policy['horizon_operating_hours']+1e-6) for v in times)
  if not check(valid,'finite conditional times/censoring'):return {'passed':False,'failures':failures,'metrics':metrics}
  finite_times=[x for x in times if x is not None];earliest=min(finite_times) if finite_times else None;latest=max(finite_times) if len(finite_times)==len(times) else None
  check(same(future['earliest'],earliest,lambda _:1e-6) and same(future['latest'],latest,lambda _:1e-6),'scenario envelope arithmetic')
  for name in scenario_names:check(same(future['by_scenario'][name],wanted['by_scenario'][name],lambda x:.12+.04*x),'conditional diagnostic time for '+name)
  check(same(future['earliest'],wanted['earliest'],lambda x:.12+.04*x) and same(future['latest'],wanted['latest'],lambda x:.12+.04*x),'diagnostic envelope')
  plan=summary['maintenance_plan']
  if not check(isinstance(plan,dict) and set(plan)=={'plan_id','worst_case_peak_loss'} and type(plan['plan_id']) is str and finite(plan['worst_case_peak_loss']),'maintenance schema'):return {'passed':False,'failures':failures,'metrics':metrics}
  options={p['plan_id']:p for p in expected['plan_results']}
  if check(plan['plan_id'] in options,'supplied candidate job'):
   selected=options[plan['plan_id']];best=min(p['cost_units'] for p in options.values() if p['safe'])
   check(selected['safe'],'admissible job under both scenarios')
   check(selected['cost_units']<=best+1e-6,'cost-minimal admissible job')
   check(abs(plan['worst_case_peak_loss']-selected['peak'])<=.012,'counterfactual peak loss')
   check(0<=plan['worst_case_peak_loss']<policy['planning_loss_ceiling'],'reported planning safety ceiling')
  # Recompute the conditional forecast from the reported current state and
  # contact properties using private forward physics, never submitted code.
  if check_physics and not failures:
   from physics import check_reported_forecast
   consistency=check_reported_forecast(folder,states[-1],contact,faults)
   metrics['reported_state_physics_forecast']=consistency
   for name in scenario_names:check(same(future['by_scenario'][name],consistency[name],lambda x:.08+.03*x),'reported-state forecast consistency for '+name)
 except (ValueError,TypeError,KeyError,IndexError,OverflowError,AttributeError,ZeroDivisionError) as error:
  failures.append('invalid output: '+type(error).__name__)
 return {'passed':not failures,'failures':failures,'metrics':metrics}

def grade_files(folder,output,expected=None,check_physics=True):
 folder=Path(folder);output=Path(output)
 try:
  if expected is None:expected=json.loads((folder/'truth.json').read_text())
  csv=output/'gearbox_condition_assessment.csv'
  if csv.stat().st_size>2000000:raise ValueError('CSV exceeds size allowance')
  return grade_prediction(expected,pd.read_csv(csv),read_json(output/'summary.json'),folder,check_physics)
 except (OSError,ValueError,TypeError,RecursionError,pd.errors.ParserError) as error:return {'passed':False,'failures':['unreadable artifacts: '+type(error).__name__],'metrics':{}}

def test_all_held_out_units():
 root=Path(__file__).resolve().parent;reports={}
 for folder in sorted((root/'held_out').glob('unit_*')):reports[folder.name]=grade_files(folder,Path('/root/agent_output')/folder.name)
 assert len(reports)==6
 report={'n_units':len(reports),'n_pass':sum(v['passed'] for v in reports.values()),'units':reports};Path('/root/results').mkdir(exist_ok=True);Path('/root/results/metrics.json').write_text(json.dumps(report,indent=2)+'\n')
 assert report['n_pass']==report['n_units'],json.dumps({k:v['failures'] for k,v in reports.items() if not v['passed']})
