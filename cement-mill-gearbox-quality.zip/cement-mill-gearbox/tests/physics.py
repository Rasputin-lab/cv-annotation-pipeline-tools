"""Private forward-physics consistency calculation; no solution imports."""
import json
from pathlib import Path
MEMBERS=["stage1_pinion","stage2_pinion"]
import os
os.environ.setdefault('OPENBLAS_NUM_THREADS','1');os.environ.setdefault('OMP_NUM_THREADS','1')
import numpy as np,time,json
from numba import njit
from scipy import optimize,signal

@njit
def pulse(angle,width):
 x=(angle+np.pi)%(2*np.pi)-np.pi
 if abs(x)>=width:return 0.
 return np.cos(.5*np.pi*x/width)**2

@njit
def rhs(q1,q2,v1,v2,th,u1,u2,a1,a2,tooth1,tooth2,b1,b2,eta1,eta2,z1,ratio,coupling,m2,k1,k2,c1,c2,shaft1,shaft2,phase2):
 M=z1;z3=z1/ratio
 p1=pulse(th-2*np.pi*tooth1/z1,np.pi*1.55/z1) if a1>0 else 0.
 p2=pulse(th*ratio-2*np.pi*tooth2/z3,np.pi*1.55/z3) if a2>0 else 0.
 base1=k1*(1+.18*np.cos(M*th)+.035*np.cos(2*M*th))
 base2=k2*(1+.16*np.cos(M*th+phase2)+.045*np.cos(2*M*th+2*phase2))
 # Opening damage weakens the loaded drive flank; coast-side contact has
 # its own qualified stiffness. q and v use scaled displacement/time.
 F1=base1*((1-a1*p1)*max(q1-b1,0.)+eta1*min(q1+b1,0.))
 F2=base2*((1-a2*p2)*max(q2-b2,0.)+eta2*min(q2+b2,0.))
 a=u1-c1*v1-shaft1*q1-F1;d=u2-c2*v2-shaft2*q2-F2
 determinant=m2-coupling*coupling
 return v1,v2,(m2*a-coupling*d)/determinant,(d-coupling*a)/determinant,F1,F2

@njit
def simulation(theta,drive,levels,parameters,teeth,config,dt,subsample):
 # theta at half integration steps; drive holds two applied forces.
 z1,ratio,coupling,m2,k1,k2,c1,c2,shaft1,shaft2,phase2,weight=config
 b1,b2,eta1,eta2=parameters
 records=theta.shape[0];steps=(theta.shape[1]-1)//2
 output=np.zeros((records,steps//subsample));forces=np.zeros((records,2,steps//subsample))
 for r in range(records):
  q1=q2=v1=v2=0.;a1=levels[r,0];a2=levels[r,1];tooth1=teeth[0];tooth2=teeth[1]
  for n in range(steps):
   h=2*n;th=theta[r,h];thh=theta[r,h+1];th1=theta[r,h+2]
   u=drive[r,h];uh=drive[r,h+1];u1=drive[r,h+2]
   A=rhs(q1,q2,v1,v2,th,u[0],u[1],a1,a2,tooth1,tooth2,b1,b2,eta1,eta2,z1,ratio,coupling,m2,k1,k2,c1,c2,shaft1,shaft2,phase2)
   B=rhs(q1+.5*dt*A[0],q2+.5*dt*A[1],v1+.5*dt*A[2],v2+.5*dt*A[3],thh,uh[0],uh[1],a1,a2,tooth1,tooth2,b1,b2,eta1,eta2,z1,ratio,coupling,m2,k1,k2,c1,c2,shaft1,shaft2,phase2)
   C=rhs(q1+.5*dt*B[0],q2+.5*dt*B[1],v1+.5*dt*B[2],v2+.5*dt*B[3],thh,uh[0],uh[1],a1,a2,tooth1,tooth2,b1,b2,eta1,eta2,z1,ratio,coupling,m2,k1,k2,c1,c2,shaft1,shaft2,phase2)
   D=rhs(q1+dt*C[0],q2+dt*C[1],v1+dt*C[2],v2+dt*C[3],th1,u1[0],u1[1],a1,a2,tooth1,tooth2,b1,b2,eta1,eta2,z1,ratio,coupling,m2,k1,k2,c1,c2,shaft1,shaft2,phase2)
   q1+=dt/6*(A[0]+2*B[0]+2*C[0]+D[0]);q2+=dt/6*(A[1]+2*B[1]+2*C[1]+D[1])
   v1+=dt/6*(A[2]+2*B[2]+2*C[2]+D[2]);v2+=dt/6*(A[3]+2*B[3]+2*C[3]+D[3])
   if n%subsample==subsample-1:
    R=rhs(q1,q2,v1,v2,th1,u1[0],u1[1],a1,a2,tooth1,tooth2,b1,b2,eta1,eta2,z1,ratio,coupling,m2,k1,k2,c1,c2,shaft1,shaft2,phase2)
    j=n//subsample;output[r,j]=R[4]+weight*R[5];forces[r,0,j]=R[4];forces[r,1,j]=R[5]
 return output,forces

def inputs(speeds,loads,config,seconds=.75,rate=8192.):
 steps=int(round(seconds*rate));t=np.arange(2*steps+1)/(2*rate)
 theta=[];drive=[]
 z1=config[0]
 for i,(rpm,L) in enumerate(zip(speeds,loads)):
  th=2*np.pi*rpm/60*t+.012*np.sin(2*np.pi*1.3*t+i*.7)
  ramp=np.minimum(t/.025,1.)
  f1=ramp*(L+.63*np.cos(z1*th+.2)+.075*np.sin(th))
  f2=ramp*(.82*L+.59*np.cos(z1*th+1.6)+.065*np.sin(config[1]*th+.4))
  theta.append(th);drive.append(np.column_stack([f1,f2]))
 return np.asarray(theta),np.asarray(drive),2*np.pi*260/rate


import numpy as np
from numba import njit


@njit
def intensity(levels,parameters,teeth,config,rpm,load,resolution=48,settle=3,measure=3):
 z1,ratio,coupling,m2,k1,k2,c1,c2,shaft1,shaft2,phase2,weight=config
 b1,b2,eta1,eta2=parameters;a1,a2=levels;j1,j2=teeth
 intervals=int(round(z1*resolution/ratio));N=(settle+measure)*intervals
 omega=2*np.pi*rpm/60.;step_phase=2*np.pi/(z1*resolution);dt=step_phase/omega*(2*np.pi*260.)
 q1=q2=v1=v2=0.;s1=s2=norm1=norm2=0.
 for n in range(N):
  ph=n*step_phase;phh=ph+step_phase*.5;phe=ph+step_phase
  u1=load+.63*np.cos(z1*ph+.2)+.075*np.sin(ph)
  u2=.82*load+.59*np.cos(z1*ph+1.6)+.065*np.sin(ratio*ph+.4)
  u1h=load+.63*np.cos(z1*phh+.2)+.075*np.sin(phh)
  u2h=.82*load+.59*np.cos(z1*phh+1.6)+.065*np.sin(ratio*phh+.4)
  u1e=load+.63*np.cos(z1*phe+.2)+.075*np.sin(phe)
  u2e=.82*load+.59*np.cos(z1*phe+1.6)+.065*np.sin(ratio*phe+.4)
  A=rhs(q1,q2,v1,v2,ph,u1,u2,a1,a2,j1,j2,b1,b2,eta1,eta2,z1,ratio,coupling,m2,k1,k2,c1,c2,shaft1,shaft2,phase2)
  B=rhs(q1+.5*dt*A[0],q2+.5*dt*A[1],v1+.5*dt*A[2],v2+.5*dt*A[3],phh,u1h,u2h,a1,a2,j1,j2,b1,b2,eta1,eta2,z1,ratio,coupling,m2,k1,k2,c1,c2,shaft1,shaft2,phase2)
  C=rhs(q1+.5*dt*B[0],q2+.5*dt*B[1],v1+.5*dt*B[2],v2+.5*dt*B[3],phh,u1h,u2h,a1,a2,j1,j2,b1,b2,eta1,eta2,z1,ratio,coupling,m2,k1,k2,c1,c2,shaft1,shaft2,phase2)
  D=rhs(q1+dt*C[0],q2+dt*C[1],v1+dt*C[2],v2+dt*C[3],phe,u1e,u2e,a1,a2,j1,j2,b1,b2,eta1,eta2,z1,ratio,coupling,m2,k1,k2,c1,c2,shaft1,shaft2,phase2)
  q1+=dt/6*(A[0]+2*B[0]+2*C[0]+D[0]);q2+=dt/6*(A[1]+2*B[1]+2*C[1]+D[1])
  v1+=dt/6*(A[2]+2*B[2]+2*C[2]+D[2]);v2+=dt/6*(A[3]+2*B[3]+2*C[3]+D[3])
  if n>=settle*intervals:
   R=rhs(q1,q2,v1,v2,phe,u1e,u2e,a1,a2,j1,j2,b1,b2,eta1,eta2,z1,ratio,coupling,m2,k1,k2,c1,c2,shaft1,shaft2,phase2)
   h1=pulse(phe-2*np.pi*j1/z1,np.pi*1.55/z1)
   h2=pulse(phe*ratio-2*np.pi*j2/(z1/ratio),np.pi*1.55/(z1/ratio))
   s1+=h1*max(R[4],0.)**2;norm1+=h1
   s2+=h2*max(R[5],0.)**2;norm2+=h2
 return np.array([np.sqrt(s1/max(norm1,1e-20)),np.sqrt(s2/max(norm2,1e-20))])


import numpy as np
from numba import njit


def build_fields(params,teeth,cfg,duties,replacement,spacing=.05,resolution=48):
 n=int(round(.45/spacing))+1;grid=np.linspace(0,.45,n);fields=np.zeros((len(duties),3,n,n,2))
 for d,(rpm,load) in enumerate(duties):
  for i,x in enumerate(grid):
   for j,y in enumerate(grid):fields[d,0,i,j]=intensity(np.array([x,y]),params,teeth,cfg,rpm,load,resolution)
  p=params.copy();p[0]=replacement[0];p[2]=replacement[2]
  for j,y in enumerate(grid):fields[d,1,:,j]=intensity(np.array([0.,y]),p,teeth,cfg,rpm,load,resolution)
  p=params.copy();p[1]=replacement[1];p[3]=replacement[3]
  for i,x in enumerate(grid):fields[d,2,i,:]=intensity(np.array([x,0.]),p,teeth,cfg,rpm,load,resolution)
 return grid,fields

@njit
def rate(a1,a2,d,mode,fields,max_alpha,coeff,exp,rpm,ratio):
 n=fields.shape[2];xx=max(0.,min(a1,max_alpha))/max_alpha*(n-1);yy=max(0.,min(a2,max_alpha))/max_alpha*(n-1)
 i=min(int(xx),n-2);j=min(int(yy),n-2);u=xx-i;v=yy-j
 ans=np.zeros(2)
 for k,a in enumerate((a1,a2)):
  if a<=0.:continue
  I=(1-u)*(1-v)*fields[d,mode,i,j,k]+u*(1-v)*fields[d,mode,i+1,j,k]+(1-u)*v*fields[d,mode,i,j+1,k]+u*v*fields[d,mode,i+1,j+1,k]
  cycles=rpm*60*(1. if k==0 else ratio)
  ans[k]=coeff[k]*cycles*max(0.,I)**exp[k]*a/(1-a)**2
 return ans

@njit
def trajectory(start,scenario,fields,max_alpha,coeff,exponents,duties,ratio,limit=.4,plan_time=-1.,mask=0,max_step=.04):
 alpha=start.copy();peak=max(alpha);t=0.;mode=0;acted=False
 for r in range(scenario.shape[0]):
  d=int(scenario[r,0]);end=t+scenario[r,1];rpm=duties[d,0]
  while t<end-1e-10:
   if mask and not acted and t>=plan_time-1e-9:
    if mask&1:alpha[0]=0.
    if mask&2:alpha[1]=0.
    if mask==3:return -1.,peak
    mode=mask;acted=True
   h=min(max_step,end-t)
   if mask and not acted and t<plan_time<t+h:h=plan_time-t
   k1=rate(alpha[0],alpha[1],d,mode,fields,max_alpha,coeff,exponents,rpm,ratio)
   k2=rate(alpha[0]+h*k1[0]/2,alpha[1]+h*k1[1]/2,d,mode,fields,max_alpha,coeff,exponents,rpm,ratio)
   k3=rate(alpha[0]+h*k2[0]/2,alpha[1]+h*k2[1]/2,d,mode,fields,max_alpha,coeff,exponents,rpm,ratio)
   k4=rate(alpha[0]+h*k3[0],alpha[1]+h*k3[1],d,mode,fields,max_alpha,coeff,exponents,rpm,ratio)
   following=alpha+h*(k1+2*k2+2*k3+k4)/6
   if max(following)>=limit:
    fraction=1.
    for k in range(2):
     if following[k]>=limit and following[k]>alpha[k]:fraction=min(fraction,(limit-alpha[k])/(following[k]-alpha[k]))
    return t+h*max(0.,fraction),max(peak,limit)
   alpha=following;peak=max(peak,max(alpha));t+=h
 return -1.,peak

def evaluate(start,scenarios,fields,grid,coeff,exp,duties,ratio,plans,max_step=.04,planning_limit=.36):
 forecasts={};plan_results=[]
 for name,rows in scenarios.items():
  crossing,peak=trajectory(start,rows,fields,grid[-1],coeff,exp,duties,ratio,max_step=max_step)
  forecasts[name]=None if crossing<0 else float(crossing)
 for plan in plans:
  runs=[]
  for name,rows in scenarios.items():
   crossing,peak=trajectory(start,rows,fields,grid[-1],coeff,exp,duties,ratio,limit=planning_limit,plan_time=plan['time'],mask=plan['mask'],max_step=max_step)
   runs.append({'scenario':name,'crossing':None if crossing<0 else float(crossing),'peak':float(peak)})
  plan_results.append({'plan_id':plan['plan_id'],'cost_units':plan['cost_units'],'safe':all(r['crossing'] is None for r in runs),'peak':max(r['peak'] for r in runs),'runs':runs})
 best=min((p for p in plan_results if p['safe']),key=lambda p:p['cost_units'])
 finite=[x for x in forecasts.values() if x is not None]
 bounds={'by_scenario':forecasts,'earliest':min(finite) if finite else None,'latest':max(finite) if len(finite)==len(forecasts) else None}
 return {'forecast_hours':bounds,'maintenance_plan':{'plan_id':best['plan_id'],'worst_case_peak_loss':best['peak']},'plan_results':plan_results}

def fit_fatigue(folder):
 import pandas as pd
 data=pd.read_csv(Path(folder)/'fatigue_tests.csv');coeff=[];exponents=[]
 for member in MEMBERS:
  p=data[data.member==member];alpha=p.stiffness_loss.to_numpy();I=p.root_load_rms_over_reference.to_numpy();rate=p.loss_rate_per_pinion_cycle.to_numpy()
  slope,intercept=np.polyfit(np.log(I),np.log(rate*(1-alpha)**2/alpha),1);coeff.append(np.exp(intercept));exponents.append(slope)
 return np.asarray(coeff),np.asarray(exponents)

def planning_inputs(folder,scale):
 import pandas as pd
 future=pd.read_csv(Path(folder)/'future_duty.csv');policy=json.loads((Path(folder)/'maintenance_policy.json').read_text())
 duties=np.unique(future[['input_rpm','force_multiplier']].to_numpy(),axis=0);scenarios={}
 for name,part in future.groupby('scenario_id',sort=False):
  rows=[]
  for row in part.sort_values('segment_id').itertuples(index=False):
   d=int(np.flatnonzero((duties[:,0]==row.input_rpm)&(duties[:,1]==row.force_multiplier))[0]);rows.append([d,row.duration_hours])
  scenarios[name]=np.asarray(rows)
 replacement=np.r_[np.asarray(policy['replacement']['backlash_halfwidth_um'])/scale,policy['replacement']['coast_stiffness_ratio']]
 plans=[{'plan_id':p['plan_id'],'time':p['at_operating_hour'],'mask':sum(1<<MEMBERS.index(member) for member in p['replace']),'cost_units':p['cost_units']} for p in policy['plans']]
 return duties,scenarios,replacement,plans



def check_reported_forecast(folder,current,contact,faults):
 parameters=np.r_[np.array(contact['backlash_halfwidth_um'])/500.,contact['coast_stiffness_ratio']]
 spec=json.loads((Path(folder)/'gearbox.json').read_text());scale=spec['displacement_scale_um'];parameters[:2]=np.array(contact['backlash_halfwidth_um'])/scale
 teeth=np.array([faults[m] if faults[m] is not None else 0 for m in MEMBERS],dtype=np.int64)
 geometry=spec['teeth'];mass=spec['mass_matrix'];ratio=geometry['stage1_pinion']/geometry['stage1_wheel']
 cfg=np.array([geometry['stage1_pinion'],ratio,mass[0][1],mass[1][1],*spec['drive_mesh_stiffness'],*spec['modal_damping'],*spec['shaft_stiffness'],spec['mesh_phase_stage2_rad'],1.])
 C,m=fit_fatigue(folder);duties,scenarios,replacement,plans=planning_inputs(folder,scale)
 grid,fields=build_fields(parameters,teeth,cfg,duties,replacement,spacing=.06,resolution=48)
 answer={}
 for name,rows in scenarios.items():
  crossing,_=trajectory(np.asarray(current),rows,fields,grid[-1],C,m,duties,ratio,max_step=.025)
  answer[name]=None if crossing<0 else float(crossing)
 return answer
