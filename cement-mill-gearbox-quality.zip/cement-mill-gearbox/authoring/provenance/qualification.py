import numpy as np
from numba import njit
from simulator import intensity

def build_fields(params,teeth,cfg,duties,replacement,spacing=.05,resolution=48):
 n=int(round(.45/spacing))+1;grid=np.linspace(0,.45,n);fields=np.zeros((len(duties),3,n,n,2))
 for d,(rpm,load) in enumerate(duties):
  for i,x in enumerate(grid):
   for j,y in enumerate(grid):fields[d,0,i,j]=intensity(np.array([x,y]),params,teeth,cfg,rpm,load,resolution)
  p=params.copy();p[0]=replacement[0];p[2]=replacement[2]
  for j,y in enumerate(grid):fields[d,1,:,j]=intensity(np.array([0.,y]),p,teeth,cfg,rpm,load,resolution)
  p=params.copy();p[1]=replacement[1];p[3]=replacement[3]
  for i,x in enumerate(grid):fields[d,2,i,:]=intensity(np.array([x,0.]),p,teeth,cfg,rpm,load,resolution)
 return grid,fields

@njit
def rate(a1,a2,d,mode,fields,max_alpha,coeff,exp,rpm,ratio):
 n=fields.shape[2];xx=max(0.,min(a1,max_alpha))/max_alpha*(n-1);yy=max(0.,min(a2,max_alpha))/max_alpha*(n-1)
 i=min(int(xx),n-2);j=min(int(yy),n-2);u=xx-i;v=yy-j
 ans=np.zeros(2)
 for k,a in enumerate((a1,a2)):
  if a<=0.:continue
  I=(1-u)*(1-v)*fields[d,mode,i,j,k]+u*(1-v)*fields[d,mode,i+1,j,k]+(1-u)*v*fields[d,mode,i,j+1,k]+u*v*fields[d,mode,i+1,j+1,k]
  cycles=rpm*60*(1. if k==0 else ratio)
  ans[k]=coeff[k]*cycles*max(0.,I)**exp[k]*a/(1-a)**2
 return ans

@njit
def trajectory(start,scenario,fields,max_alpha,coeff,exponents,duties,ratio,limit=.4,plan_time=-1.,mask=0,max_step=.04):
 alpha=start.copy();peak=max(alpha);t=0.;mode=0;acted=False
 for r in range(scenario.shape[0]):
  d=int(scenario[r,0]);end=t+scenario[r,1];rpm=duties[d,0]
  while t<end-1e-10:
   if mask and not acted and t>=plan_time-1e-9:
    if mask&1:alpha[0]=0.
    if mask&2:alpha[1]=0.
    if mask==3:return -1.,peak
    mode=mask;acted=True
   h=min(max_step,end-t)
   if mask and not acted and t<plan_time<t+h:h=plan_time-t
   k1=rate(alpha[0],alpha[1],d,mode,fields,max_alpha,coeff,exponents,rpm,ratio)
   k2=rate(alpha[0]+h*k1[0]/2,alpha[1]+h*k1[1]/2,d,mode,fields,max_alpha,coeff,exponents,rpm,ratio)
   k3=rate(alpha[0]+h*k2[0]/2,alpha[1]+h*k2[1]/2,d,mode,fields,max_alpha,coeff,exponents,rpm,ratio)
   k4=rate(alpha[0]+h*k3[0],alpha[1]+h*k3[1],d,mode,fields,max_alpha,coeff,exponents,rpm,ratio)
   following=alpha+h*(k1+2*k2+2*k3+k4)/6
   if max(following)>=limit:
    fraction=1.
    for k in range(2):
     if following[k]>=limit and following[k]>alpha[k]:fraction=min(fraction,(limit-alpha[k])/(following[k]-alpha[k]))
    return t+h*max(0.,fraction),max(peak,limit)
   alpha=following;peak=max(peak,max(alpha));t+=h
 return -1.,peak

def evaluate(start,scenarios,fields,grid,coeff,exp,duties,ratio,plans,max_step=.04,planning_limit=.36):
 forecasts={};plan_results=[]
 for name,rows in scenarios.items():
  crossing,peak=trajectory(start,rows,fields,grid[-1],coeff,exp,duties,ratio,max_step=max_step)
  forecasts[name]=None if crossing<0 else float(crossing)
 for plan in plans:
  runs=[]
  for name,rows in scenarios.items():
   crossing,peak=trajectory(start,rows,fields,grid[-1],coeff,exp,duties,ratio,limit=planning_limit,plan_time=plan['time'],mask=plan['mask'],max_step=max_step)
   runs.append({'scenario':name,'crossing':None if crossing<0 else float(crossing),'peak':float(peak)})
  plan_results.append({'plan_id':plan['plan_id'],'cost_units':plan['cost_units'],'safe':all(r['crossing'] is None for r in runs),'peak':max(r['peak'] for r in runs),'runs':runs})
 best=min((p for p in plan_results if p['safe']),key=lambda p:p['cost_units'])
 finite=[x for x in forecasts.values() if x is not None]
 bounds={'by_scenario':forecasts,'earliest':min(finite) if finite else None,'latest':max(finite) if len(finite)==len(forecasts) else None}
 return {'forecast_hours':bounds,'maintenance_plan':{'plan_id':best['plan_id'],'worst_case_peak_loss':best['peak']},'plan_results':plan_results}
