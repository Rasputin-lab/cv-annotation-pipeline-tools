#!/usr/bin/env python3
"""Generate controlled nonlinear gearbox measurements and physical-state targets."""
import os
os.environ.setdefault('OPENBLAS_NUM_THREADS','1');os.environ.setdefault('OMP_NUM_THREADS','1')
import csv,hashlib,json,time
from pathlib import Path
import numpy as np
from scipy import signal
from simulator import simulation
from qualification import build_fields,evaluate

AXES=['ax_g','ay_g','az_g'];MEMBERS=['stage1_pinion','stage2_pinion'];F0=100000.;X0_UM=500.;FS=4096.;OMEGA=2*np.pi*260
PUBLIC=['gearbox.json','records.csv','observations.csv','vibration_windows.csv','transfer_calibration.csv','fatigue_tests.csv','future_duty.csv','maintenance_policy.json','README.txt']
def write_csv(path,header,rows):
 with path.open('w',newline='') as f:
  writer=csv.writer(f);writer.writerow(header);writer.writerows(rows)
def array_inputs(theta,u,substeps):
 factor=2*substeps;idx=np.arange((len(theta[0])-1)*factor+1)/factor;nodes=np.arange(len(theta[0]))
 return (np.array([np.interp(idx,nodes,x) for x in theta]),np.array([np.column_stack([np.interp(idx,nodes,x[:,j]) for j in range(2)]) for x in u]))

def generate(root,letter,seed,present,aligned=False):
 rng=np.random.default_rng(seed);folder=root/('environment/data' if letter=='A' else 'tests/held_out')/('unit_'+letter);folder.mkdir(parents=True,exist_ok=True)
 z1=int(rng.choice([18,20,22]));reduction=int(rng.choice([3,4]));r1=1/reduction;z3=z1*reduction
 cfg=np.array([z1,r1,rng.uniform(.24,.34),rng.uniform(.70,.85),rng.uniform(.88,1.02),rng.uniform(1.15,1.32),rng.uniform(.19,.25),rng.uniform(.17,.23),.035,.055,rng.uniform(1.3,1.9),rng.uniform(.65,.85)])
 parameters=np.r_[rng.uniform(.13,.23,2),rng.uniform(.52,.95,2)]
 if letter in ('C','F'):parameters[2]=1.
 if letter=='D':parameters[3]=1.
 tooth1=int(rng.integers(z1));tooth2=tooth1+z1*int(rng.integers(reduction)) if aligned else int(rng.integers(z3));teeth=np.array([tooth1,tooth2],dtype=np.int64)
 nobs=6;ends=np.array([rng.uniform(.22,.32),rng.uniform(.18,.30)])*np.array(present)
 losses=np.zeros((nobs,2))
 for j in range(2):
  if present[j]:
   increments=rng.uniform(.6,1.6,nobs);shape=np.cumsum(increments)/sum(increments);losses[:,j]=.035+(ends[j]-.035)*shape
 scalar_coeff=rng.uniform(4e-7,1.0e-6,2)*np.array([1.,2.7]);exponents=rng.uniform(2.2,2.9,2)
 # One qualified material/duty campaign emphasizes branch-switching production.
 # Its more rapidly accumulating stage-2 loss is measured in its fatigue tests.
 if letter=='G':scalar_coeff[1]*=10.
 duration=.75;n=int(FS*duration);t=np.arange(n+1)/FS;record_rows=[];theta_nodes=[];force_nodes=[];record_loss=[]
 # Healthy commissioning is measured at low-speed loaded conditions. Operating
 # sweeps include high-speed/light-load conditions with contact branch changes.
 probes=[(540.,1.20),(730.,.22),(910.,.35),(810.,.18)]
 for oid in range(nobs+1):
  choices=[(250.,1.25),(330.,1.35)] if oid==0 else probes
  for rpm,load in choices:
   rpm*=rng.uniform(.97,1.03);phase=float(rng.uniform(-np.pi,np.pi));start=float(rng.uniform(0,2*np.pi))
   angle=start+2*np.pi*rpm/60*t+.012*(np.sin(2*np.pi*1.3*t+phase)-np.sin(phase))
   ramp=np.minimum(t/.025,1.);u1=ramp*(load+.63*np.cos(z1*angle+.2)+.075*np.sin(angle));u2=ramp*(.82*load+.59*np.cos(z1*angle+1.6)+.065*np.sin(r1*angle+.4))
   rid=len(record_rows)+1;record_rows.append([rid,oid,rpm,load]);theta_nodes.append(angle);force_nodes.append(np.column_stack([u1,u2]));record_loss.append([0.,0.] if oid==0 else losses[oid-1])
 theta_nodes=np.asarray(theta_nodes);force_nodes=np.asarray(force_nodes);record_loss=np.asarray(record_loss)
 dense_theta,dense_forces=array_inputs(theta_nodes,force_nodes,8)
 trace,forces=simulation(dense_theta,dense_forces,record_loss,parameters,teeth,cfg,OMEGA/(FS*8),8)
 raw_force=np.c_[np.zeros(len(trace)),trace]
 fn=rng.uniform([530,650,810],[600,730,900]);zeta=rng.uniform(.10,.17,3);gain=np.array([.08,-.055,.067])*rng.uniform(.9,1.1,3)
 data=np.zeros((len(trace),n+1,3));cal=[];freq=np.unique(np.r_[np.linspace(30,1850,55),np.linspace(450,950,31)])
 for a in range(3):
  wn=2*np.pi*fn[a];b,den=signal.bilinear([1,0,0],[1,2*zeta[a]*wn,wn*wn],fs=FS)
  data[:,:,a]=gain[a]*signal.lfilter(b,den,raw_force,axis=1)+rng.normal(0,.00016,data.shape[:2])
  _,response=signal.freqz(b,den,worN=freq,fs=FS)
  for src,w in zip(['stage1','stage2'],[1.,cfg[-1]]):
   for f,h in zip(freq,response):
    observed=gain[a]*w/F0*h*(1+rng.normal(0,.0005)+1j*rng.normal(0,.0005))
    cal.append([AXES[a],src,float(f),float(observed.real),float(observed.imag)])
  for r in range(len(trace)):
   data[r,rng.choice(n+1,6,replace=False),a]=np.nan
 for r in [5,15,23]:
  if r<len(trace):data[r,1100:1116,r%3]=np.nan
 spec={'experiment':'controlled nonlinear two-stage gearbox contact experiment','sampling_rate_hz':FS,'record_seconds':duration,'force_scale_N':F0,'displacement_scale_um':X0_UM,'reference_angular_frequency_rad_per_s':OMEGA,
       'teeth':{'stage1_pinion':z1,'stage1_wheel':z1*reduction,'stage2_pinion':z3,'stage2_wheel':3*z3},
       'mass_matrix':[[1.,float(cfg[2])],[float(cfg[2]),float(cfg[3])]],'drive_mesh_stiffness':[float(cfg[4]),float(cfg[5])],'modal_damping':[float(cfg[6]),float(cfg[7])],'shaft_stiffness':[.035,.055],'mesh_phase_stage2_rad':float(cfg[10]),
       'contact_ratio':1.55,'phase_qualification':'tooth j is centred at intrinsic pinion angle 2*pi*j/Z; angles increase in the pinion rotation direction','stiffness_loss_detection':.03,'fatigue_force_moment_qualification':[0.,5.],
       'parameter_bounds':{'backlash_halfwidth_um':[25.,175.],'coast_stiffness_ratio':[.35,1.2],'stiffness_loss':[0.,.45]},
       'calibration_relative_standard_deviation':.0005,'measurement_noise_standard_deviation_g':.00016,'fatigue_relative_standard_deviation':.003,
       'future_probe':{'settling_intermediate_revolutions':3,'measurement_intermediate_revolutions':3,'u1_formula':'L+0.63*cos(M*theta+0.2)+0.075*sin(theta)','u2_formula':'0.82*L+0.59*cos(M*theta+1.6)+0.065*sin(r1*theta+0.4)'},
       'qualification':'see README.txt; stiffness-loss alert, not component fracture life'}
 (folder/'gearbox.json').write_text(json.dumps(spec,indent=2)+'\n')
 write_csv(folder/'records.csv',['record_id','observation_id','input_rpm','force_multiplier'],record_rows)
 hours=np.r_[0.,np.cumsum(rng.uniform(10,25,nobs-1))];write_csv(folder/'observations.csv',['observation_id','service_hours'],zip(range(1,nobs+1),hours))
 write_csv(folder/'transfer_calibration.csv',['axis','source','frequency_hz','real_g_per_N','imag_g_per_N'],cal)
 with (folder/'vibration_windows.csv').open('w') as f:
  f.write('record_id,time_s,input_angle_rad,force1_N,force2_N,ax_g,ay_g,az_g\n')
  for r in range(len(trace)):
   for i in range(n+1):
    values=[t[i],theta_nodes[r,i],force_nodes[r,i,0]*F0,force_nodes[r,i,1]*F0,*data[r,i]]
    f.write(str(r+1)+','+','.join('' if not np.isfinite(v) else format(v,'.11g') for v in values)+'\n')
 fatigue=[]
 for j,member in enumerate(MEMBERS):
  for alpha in [.08,.20,.32]:
   for I in [.25,.55,1.,2.,3.5,5.]:
    for _ in range(2):
     rate=scalar_coeff[j]*I**exponents[j]*alpha/(1-alpha)**2*np.exp(rng.normal(0,.003))
     fatigue.append([member,alpha,I,float(rate)])
 write_csv(folder/'fatigue_tests.csv',['member','stiffness_loss','root_load_rms_over_reference','loss_rate_per_pinion_cycle'],fatigue)
 duties=np.array([[550.,1.2],[800.,.2],[950.,.35],[640.,1.4],[730.,.45]])
 sequences={'normal_production':[0,1,2,0],'production_push':[3,4,0,2]}
 if letter=='G':sequences={'normal_production':[1,4,1,4],'production_push':[4,1,4,1]}
 scenarios={name:np.array([[idx,2.] for idx in seq],dtype=float) for name,seq in sequences.items()}
 write_csv(folder/'future_duty.csv',['scenario_id','segment_id','duration_hours','input_rpm','force_multiplier'],[[name,k+1,2.,*duties[idx]] for name,seq in sequences.items() for k,idx in enumerate(seq)])
 replacements=np.array([.10,.12,1.,1.]);plans=[{'plan_id':'continue','time':-1.,'mask':0,'cost_units':0.}]
 component_cost=rng.uniform([95,125],[120,165]);job=0
 for slot,when in enumerate([0.,.5,1.,2.,3.,4.]):
  downtime=180*np.exp(-when/.9)
  for mask in (1,2,3):
   job+=1;cost=float(downtime+sum(component_cost[j] for j in range(2) if mask&(1<<j)))
   plans.append({'plan_id':f'job_{job:02d}','time':when,'mask':mask,'cost_units':cost})
 policy={'diagnostic_stiffness_loss_limit':.40,'planning_loss_ceiling':.36,'horizon_operating_hours':8.,'replacement':{'backlash_halfwidth_um':[50.,60.],'coast_stiffness_ratio':[1.,1.]},
         'plans':[{'plan_id':p['plan_id'],'at_operating_hour':p['time'],'replace':[MEMBERS[j] for j in range(2) if p['mask']&(1<<j)],'cost_units':p['cost_units']} for p in plans]}
 (folder/'maintenance_policy.json').write_text(json.dumps(policy,indent=2)+'\n')
 print('building physical future targets',letter,flush=True);grid,fields=build_fields(parameters,teeth,cfg,duties,replacements,spacing=.025,resolution=72)
 assessment=evaluate(losses[-1],scenarios,fields,grid,scalar_coeff,exponents,duties,r1,plans,max_step=.01)
 expected={'losses':losses.tolist(),'faults':{member:int(teeth[j]) if present[j] else None for j,member in enumerate(MEMBERS)},'contact_parameters':{'backlash_halfwidth_um':(parameters[:2]*X0_UM).tolist(),'coast_stiffness_ratio':parameters[2:].tolist()},'forecast_hours':assessment['forecast_hours'],'maintenance_plan':assessment['maintenance_plan'],'plan_results':assessment['plan_results']}
 if letter!='A':(folder/'truth.json').write_text(json.dumps(expected,indent=2,allow_nan=False)+'\n')
 return {'seed':seed,'present':list(present),'aligned_tooth_events':aligned,'model_vector':cfg.tolist(),'parameters':parameters.tolist(),'tooth_indices':teeth.tolist(),'fatigue_coefficients':scalar_coeff.tolist(),'fatigue_exponents':exponents.tolist(),'sensor_natural_frequency_hz':fn.tolist(),'sensor_damping_ratio':zeta.tolist(),'sensor_gain':gain.tolist(),'future_force_moment_min':float(fields.min()),'future_force_moment_max':float(fields.max()),'expected':expected}

if __name__=='__main__':
 root=Path(__file__).resolve().parents[2];manifest={'description':'Independent generating physical states, not solution outputs.','cases':{}}
 designs=[('A',2026102401,(1,1),True),('B',2026102419,(1,1),True),('C',2026102427,(1,0),False),('D',2026102443,(0,1),False),('E',2026102461,(1,1),False),('F',2026102479,(1,1),True),('G',2026102497,(1,1),False)]
 for letter,seed,present,aligned in designs:
  start=time.monotonic();item=generate(root,letter,seed,present,aligned);manifest['cases']['unit_'+letter]=item
  canonical=Path(__file__).with_name('DATA_README.md')
  if canonical.exists():(root/('environment/data' if letter=='A' else 'tests/held_out')/('unit_'+letter)/'README.txt').write_bytes(canonical.read_bytes())
  Path(__file__).with_name('generation_manifest.json').write_text(json.dumps(manifest,indent=2,allow_nan=False)+'\n')
  print('generated',letter,'seconds',round(time.monotonic()-start,2),'forecast',item['expected']['forecast_hours'],'plan',item['expected']['maintenance_plan'],flush=True)
