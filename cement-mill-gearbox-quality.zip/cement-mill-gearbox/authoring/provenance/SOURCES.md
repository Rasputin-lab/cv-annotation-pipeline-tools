# Scientific sources and applications

The user's **PREDICTIVE MAINTENANCE.docx**, SHA-256
`ca092042e6a8f7890bf12c18007ad9fe7af777908657f09ca85ebea0b83e49ba`,
motivates the cement-mill pinion context, casing vibration measurements,
independent baselines and advance maintenance planning. No unsupported cost,
service-life or failure-probability claim from it is used as ground truth.
Raw personal documents and browser exports are not part of the runnable task.

1. Wan, Z. et al. (2014), *An improved time-varying mesh stiffness algorithm and
   dynamic modeling of gear-rotor system with tooth root crack*, Engineering
   Failure Analysis 42,157–177.
   https://doi.org/10.1016/j.engfailanal.2014.04.005
   Supports modelling local root damage through time-varying stiffness and a
   coupled dynamic response, rather than equating spectral amplitude with damage.
2. Yang, L. et al. (2021), *Investigation of tooth crack opening state on time
   varying meshing stiffness and dynamic response of spur gear pair*, Engineering
   Failure Analysis 121,105181.
   https://doi.org/10.1016/j.engfailanal.2020.105181
   Supports distinguishing opening contact conditions in crack-related stiffness.
3. *Nonlinear dynamics of a spur gear pair with tooth root crack based on an
   amplitude modulation function*, Engineering Computations 39(4),1575–1596 (2022).
   https://doi.org/10.1108/EC-06-2020-0334
   Supports localized stiffness-modulation modelling and nonlinear gear dynamics.
4. *Physics-informed inverse identification and dynamic reconstruction of
   high-speed gear systems with asymmetric mesh stiffness*, Scientific Reports
   (2026). https://www.nature.com/articles/s41598-026-68864-1
   Its publisher-indexed abstract motivates examining contact-model validity
   across low-speed loaded and high-speed light-load conditions.
5. ISO17359:2018, *Condition monitoring and diagnostics of machines — General
   guidelines*. https://www.iso.org/standard/71194.html
   Provides condition-monitoring workflow context; no certification is claimed.

Publisher abstracts/official records were consulted for the methodological scope.
Full articles were not assumed available where access was restricted. The task
is an independently constructed synthetic qualification experiment, not a
replication of any paper's numerical results. Its matrices, measurement response,
fatigue correlation, alert thresholds and maintenance costs are explicitly supplied
experimental assumptions. The empirical stiffness-loss qualification does not
establish a universal fracture-growth law or remaining mechanical life.
