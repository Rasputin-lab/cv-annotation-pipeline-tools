# Controlled gearbox contact experiment

All records are synthetic. They represent a reduced mechanical experiment for a
cement-mill gearbox. The assessed quantities are effective pinion tooth stiffness
losses and conditional maintenance decisions. No crack depth, unconditional
fracture life or plant failure probability is requested. The mechanical model
and the fatigue qualification below define this experiment, not a universal
gear life law.

## Complete input directory

- `gearbox.json`: geometry, dimensional scales, known mechanical coefficients,
  unknown-parameter bounds, measurement accuracy and future probe protocol.
- `records.csv`: record_id, observation_id, nominal input_rpm and force_multiplier.
  Observation 0 is an independent healthy commissioning state. Positive
  observation identifiers correspond to the operating states to assess.
- `observations.csv`: the chronological operating observation IDs and service
  hours. The intervening load history is not included. The future fatigue
  qualification does not supply the unknown past duty history.
- `vibration_windows.csv`: record_id, time_s, input_angle_rad, force1_N, force2_N,
  ax_g, ay_g, az_g. The force columns are applied generalized forces driving the
  two mesh coordinates. Acceleration is in g; blank acceleration cells are
  missing observations. Time restarts at zero for each record. Applied forces
  and input angle are complete, synchronously sampled inputs. Interpolate these
  inputs linearly between their timestamps when solving the continuous dynamics.
- `transfer_calibration.csv`: axis, source, frequency_hz, real_g_per_N,
  imag_g_per_N. Sources stage1 and stage2 denote independently applied known
  contact-force equivalents during sensor-path calibration.
- `fatigue_tests.csv`: member, stiffness_loss, root_load_rms_over_reference,
  loss_rate_per_pinion_cycle. These are independent noisy qualification tests
  for each pinion's future stiffness-loss correlation.
- `future_duty.csv`: scenario_id, segment_id, duration_hours, input_rpm,
  force_multiplier. Rows define alternative complete production scenarios.
- `maintenance_policy.json`: diagnostic loss limit, lower planning ceiling,
  horizon, known replacement properties and candidate jobs with total costs.
- `README.txt`: this contract, supplied identically in every experiment.

## Coordinates, geometry and unknowns

Let theta be input_angle_rad, and r1 be the stage1 pinion/wheel tooth-count ratio.
The intrinsic pinion angles are phi1=theta and phi2=r1*theta. Each angle increases
in that pinion's rotation direction; these are intrinsic rolling coordinates.
Tooth indices are zero-based. Tooth j is centred at intrinsic angle 2*pi*j/Z,
where Z is the corresponding pinion's tooth count. This fixes phase and sign.

The two measured meshes have the same fundamental order:
M=Z_stage1_pinion=Z_stage2_pinion*r1. Use the supplied tooth counts. Pinions are
labelled `stage1_pinion` and `stage2_pinion`. Either or both may have a local
opening tooth disturbance; no other damage mechanism is in this qualification.
A disturbed pinion has one affected tooth. An absent disturbance has loss zero.

For each stage j, infer a constant backlash half-width b_j and coast/drive
stiffness ratio eta_j, shared across its records. Infer each pinion's fractional
local stiffness loss alpha_j,w at every operating observation. Alpha is a
nonnegative fraction: at the affected tooth's centre, its drive-flank stiffness
is reduced by that fraction. It is not a phase-modulation amplitude.
Commissioning records have alpha1=alpha2=0. Operating records are not certified
healthy. A pinion whose current loss is below stiffness_loss_detection is
reported absent. Qualified cases are separated from this decision boundary.

## Mechanical dynamics

q_j is line-of-action mesh deflection divided by displacement_scale_um. Let
F0=force_scale_N, Omega=reference_angular_frequency_rad_per_s and tau=Omega*time_s.
Primes denote derivatives with respect to tau. The known normalized matrices
are in gearbox.json. The mass matrix has first diagonal entry 1; modal damping
and shaft stiffness are diagonal. Applied normalized forces are u_j=forcej_N/F0.

    mass_matrix * q'' + diag(modal_damping)*q'
        + diag(shaft_stiffness)*q + [F1,F2] = [u1,u2].

F_j denotes normalized internal contact reaction. Physical contact force is
F0*F_j. Backlash b_j in this equation is half-width divided by displacement_scale_um.
The known healthy time-varying mesh stiffnesses are

    k1(theta) = drive_mesh_stiffness[0] *
                (1 + 0.18*cos(M*theta) + 0.035*cos(2*M*theta)),
    k2(theta) = drive_mesh_stiffness[1] *
                (1 + 0.16*cos(M*theta+mesh_phase_stage2_rad)
                   + 0.045*cos(2*M*theta+2*mesh_phase_stage2_rad)).

For a tooth at index j, define delta=wrap(phi-2*pi*j/Z) into [-pi,pi), and
half=pi*contact_ratio/Z. Its engagement profile is

    W(phi,j,Z) = cos(pi*delta/(2*half))^2  if abs(delta)<half,
                0                       otherwise.

The contact reactions are

    F_j = k_j(theta) * [
             (1-alpha_j*W_j) * max(q_j-b_j,0)
             + eta_j * min(q_j+b_j,0) ].

There is no contact force inside the backlash interval. The local opening
loss acts on the loaded drive flank; the coast branch has the qualified
stiffness eta_j. Modal damping acts through the specified damping matrix.
For an absent disturbance alpha_j=0, so its tooth index has no effect.

Every measured record starts with q=q'=0 at time zero and uses its measured
applied-force ramp. These initial conditions are part of the controlled test.
Losses are constant within a record and shared by records at the same
observation. Geometry, mass, damping, shaft stiffness, clearances, flank ratios
and sensor paths are constant during these measurements.

## Measurement model

At each recorded time, sample physical contact forces and apply the calibrated
acquisition response. For each axis a:

    acceleration_a[n] = H_a(z) {B[a,1]*F0*F1[n] + B[a,2]*F0*F2[n]} + noise.

B is real, in g/N. H_a is the bilinear-discretized response at the supplied
sample rate of

    H_a(s) = s^2 / (s^2 + 2*zeta_a*omega_a*s + omega_a^2).

omega_a=2*pi*natural_frequency_hz. Calibration uses the same acquisition clock
and filter convention; the response is evaluated for exp(+i*2*pi*f*t).
Calibration has independent small multiplicative real/imaginary errors with
the stated relative standard deviation. Operational measurement noise has
the stated standard deviation in g. All input and output channels share a
clock. The acquisition filter starts at zero state in each record.
The sensor's selected record bandwidth and this calibrated response define
what is observed; no unmeasured higher-bandwidth sensor information is needed.

## Future root loading and fatigue qualification

Forecasts start immediately after the last operating observation. Time here is
operating hours, excluding maintenance downtime. Each future row has constant
input speed and force multiplier L. Its root-load intensity is obtained from
a standardized mechanical probe at the current losses and contact parameters.
The probe uses the same dynamics with theta=2*pi*input_rpm/60*t, q=q'=0 initially,
and the following continuous applied forces, without the measured-record ramp:

    u1 = L + 0.63*cos(M*theta+0.2) + 0.075*sin(theta),
    u2 = 0.82*L + 0.59*cos(M*theta+1.6) + 0.065*sin(r1*theta+0.4).

Settle for future_probe.settling_intermediate_revolutions, then measure for
future_probe.measurement_intermediate_revolutions, at fixed losses. Over that
measurement interval define each tooth's normalized tensile root-load intensity:

    I_j = sqrt( integral W_j * max(F_j,0)^2 dt / integral W_j dt ).

The force reference is F0, so I_j is dimensionless. Use the affected tooth's
index for an existing disturbance. An uncracked or replaced pinion has zero
loss throughout this horizon, so its index is irrelevant. New crack initiation
is outside this qualification.

Infer positive C_j and m_j from the supplied fatigue tests. The test-specific
local correlation is

    loss_rate_per_pinion_cycle = C_j * I_j^m_j * alpha_j/(1-alpha_j)^2.

It applies within the stated stiffness and root-load qualification ranges.
The coefficients describe these simulated qualification tests, not universal
material constants. Accelerated force probes and slow loss accumulation are
separate time scales. During a future production segment, evolve

    d(alpha_j)/d(operating_hour) = 60*input_rpm*r_j
                                 * C_j * I_j(alpha1,alpha2)^m_j
                                 * alpha_j/(1-alpha_j)^2,
    r_1=1, r_2=r1.

Re-evaluate root loading as either loss changes. For alpha_j=0 the rate is zero.
The shared dynamics mean root loading can change when the other pinion changes.
The prescribed probe defines each segment's averaged loading correlation.

## Conditional diagnostic forecasts

For each complete future scenario, start from the inferred current losses and
apply no repair. Find the first operating hour at which either loss reaches
maintenance_policy.diagnostic_stiffness_loss_limit. Stop at that first alert;
no continuation beyond an alert is required. A crossing outside the supplied
scenario horizon is null. These are conditional diagnostic times, not failure life.

Report by_scenario, then earliest=min(finite crossings), or null if none is
finite. Latest is the maximum only when all scenarios cross; otherwise it is
null. This envelope represents the supplied production alternatives. It is not
a statistical confidence interval. An alert present at the start has time 0.

## Counterfactual maintenance decision

Each candidate job specifies its operating-hour time, replaced pinion set and
total cost_units. Choose one job before the future scenario is known. For each
scenario, simulate its pre-job evolution. At the job time reset replaced losses
to zero and change those stages' backlash half-widths and coast stiffness ratios
to maintenance_policy.replacement. Other properties and unreplaced losses stay
as they are. Recompute coupled root loading after this change. Replacement does
not initiate a new crack in this horizon. Job times share the operating clock;
downtime is already reflected in total cost.

A plan is admissible only if both losses stay strictly below
planning_loss_ceiling throughout the full horizon in every scenario. This
planning ceiling is lower than the diagnostic alert to reserve inspection margin.
Reaching the ceiling before or exactly at a scheduled job is inadmissible.
Choose the lowest-cost admissible candidate. Equal-cost minima are all valid.
A feasible candidate is included. The initial measured losses are below the
planning ceiling.

worst_case_peak_loss is the maximum of either loss over all scenarios under the
chosen job. Include the current pre-job values even for an immediate job. A
plan's future loading uses its replacement properties, not its pre-job properties.

## Required outputs and tolerances

Write gearbox_condition_assessment.csv with exactly these columns, one row per
observations.csv row in that order:

    observation_id,loss_stage1,loss_stage2

The losses are alpha fractions, including zero for an absent disturbance.
Write summary.json with exactly four keys:

- faults: {"stage1_pinion": tooth-index-or-null,
           "stage2_pinion": tooth-index-or-null}.
- contact_parameters: {"backlash_halfwidth_um": [stage1,stage2],
                       "coast_stiffness_ratio": [stage1,stage2]}.
- forecast_hours: {"by_scenario": {scenario-id: number-or-null,...},
                   "earliest": number-or-null,"latest": number-or-null}.
- maintenance_plan: {"plan_id": string,"worst_case_peak_loss": number}.

Numbers must be finite; null is used only for absent faults and censored crossings.
A reported tooth index is an integer in the pinion's zero-based range and must
identify the supported local disturbance under the phase convention above.

Numerical allowances are 0.008 absolute loss fraction, 3 micrometres backlash
half-width, 0.018 coast ratio, and 0.012 peak loss. Conditional crossing times
have an allowance of 0.12+0.04*target hours. Envelope arithmetic must agree with
the reported scenario times within 1e-6 hours. The selected plan must be physically
admissible and cost-minimal within the stated cost rounding allowance of 1e-6 cost_units; numerical
allowances do not permit choosing an unsafe or needlessly expensive plan.
Forecasts recomputed from the reported current state and contact properties have
a consistency allowance of 0.08+0.03*computed hours. Independent integration,
calibration and estimation methods are accepted.
