import os
os.environ.setdefault('OPENBLAS_NUM_THREADS','1');os.environ.setdefault('OMP_NUM_THREADS','1')
import numpy as np,time,json
from numba import njit
from scipy import optimize,signal

@njit
def pulse(angle,width):
 x=(angle+np.pi)%(2*np.pi)-np.pi
 if abs(x)>=width:return 0.
 return np.cos(.5*np.pi*x/width)**2

@njit
def rhs(q1,q2,v1,v2,th,u1,u2,a1,a2,tooth1,tooth2,b1,b2,eta1,eta2,z1,ratio,coupling,m2,k1,k2,c1,c2,shaft1,shaft2,phase2):
 M=z1;z3=z1/ratio
 p1=pulse(th-2*np.pi*tooth1/z1,np.pi*1.55/z1) if a1>0 else 0.
 p2=pulse(th*ratio-2*np.pi*tooth2/z3,np.pi*1.55/z3) if a2>0 else 0.
 base1=k1*(1+.18*np.cos(M*th)+.035*np.cos(2*M*th))
 base2=k2*(1+.16*np.cos(M*th+phase2)+.045*np.cos(2*M*th+2*phase2))
 # Opening damage weakens the loaded drive flank; coast-side contact has
 # its own qualified stiffness. q and v use scaled displacement/time.
 F1=base1*((1-a1*p1)*max(q1-b1,0.)+eta1*min(q1+b1,0.))
 F2=base2*((1-a2*p2)*max(q2-b2,0.)+eta2*min(q2+b2,0.))
 a=u1-c1*v1-shaft1*q1-F1;d=u2-c2*v2-shaft2*q2-F2
 determinant=m2-coupling*coupling
 return v1,v2,(m2*a-coupling*d)/determinant,(d-coupling*a)/determinant,F1,F2

@njit
def simulation(theta,drive,levels,parameters,teeth,config,dt,subsample):
 # theta at half integration steps; drive holds two applied forces.
 z1,ratio,coupling,m2,k1,k2,c1,c2,shaft1,shaft2,phase2,weight=config
 b1,b2,eta1,eta2=parameters
 records=theta.shape[0];steps=(theta.shape[1]-1)//2
 output=np.zeros((records,steps//subsample));forces=np.zeros((records,2,steps//subsample))
 for r in range(records):
  q1=q2=v1=v2=0.;a1=levels[r,0];a2=levels[r,1];tooth1=teeth[0];tooth2=teeth[1]
  for n in range(steps):
   h=2*n;th=theta[r,h];thh=theta[r,h+1];th1=theta[r,h+2]
   u=drive[r,h];uh=drive[r,h+1];u1=drive[r,h+2]
   A=rhs(q1,q2,v1,v2,th,u[0],u[1],a1,a2,tooth1,tooth2,b1,b2,eta1,eta2,z1,ratio,coupling,m2,k1,k2,c1,c2,shaft1,shaft2,phase2)
   B=rhs(q1+.5*dt*A[0],q2+.5*dt*A[1],v1+.5*dt*A[2],v2+.5*dt*A[3],thh,uh[0],uh[1],a1,a2,tooth1,tooth2,b1,b2,eta1,eta2,z1,ratio,coupling,m2,k1,k2,c1,c2,shaft1,shaft2,phase2)
   C=rhs(q1+.5*dt*B[0],q2+.5*dt*B[1],v1+.5*dt*B[2],v2+.5*dt*B[3],thh,uh[0],uh[1],a1,a2,tooth1,tooth2,b1,b2,eta1,eta2,z1,ratio,coupling,m2,k1,k2,c1,c2,shaft1,shaft2,phase2)
   D=rhs(q1+dt*C[0],q2+dt*C[1],v1+dt*C[2],v2+dt*C[3],th1,u1[0],u1[1],a1,a2,tooth1,tooth2,b1,b2,eta1,eta2,z1,ratio,coupling,m2,k1,k2,c1,c2,shaft1,shaft2,phase2)
   q1+=dt/6*(A[0]+2*B[0]+2*C[0]+D[0]);q2+=dt/6*(A[1]+2*B[1]+2*C[1]+D[1])
   v1+=dt/6*(A[2]+2*B[2]+2*C[2]+D[2]);v2+=dt/6*(A[3]+2*B[3]+2*C[3]+D[3])
   if n%subsample==subsample-1:
    R=rhs(q1,q2,v1,v2,th1,u1[0],u1[1],a1,a2,tooth1,tooth2,b1,b2,eta1,eta2,z1,ratio,coupling,m2,k1,k2,c1,c2,shaft1,shaft2,phase2)
    j=n//subsample;output[r,j]=R[4]+weight*R[5];forces[r,0,j]=R[4];forces[r,1,j]=R[5]
 return output,forces

def inputs(speeds,loads,config,seconds=.75,rate=8192.):
 steps=int(round(seconds*rate));t=np.arange(2*steps+1)/(2*rate)
 theta=[];drive=[]
 z1=config[0]
 for i,(rpm,L) in enumerate(zip(speeds,loads)):
  th=2*np.pi*rpm/60*t+.012*np.sin(2*np.pi*1.3*t+i*.7)
  ramp=np.minimum(t/.025,1.)
  f1=ramp*(L+.63*np.cos(z1*th+.2)+.075*np.sin(th))
  f2=ramp*(.82*L+.59*np.cos(z1*th+1.6)+.065*np.sin(config[1]*th+.4))
  theta.append(th);drive.append(np.column_stack([f1,f2]))
 return np.asarray(theta),np.asarray(drive),2*np.pi*260/rate


import numpy as np
from numba import njit


@njit
def intensity(levels,parameters,teeth,config,rpm,load,resolution=48,settle=3,measure=3):
 z1,ratio,coupling,m2,k1,k2,c1,c2,shaft1,shaft2,phase2,weight=config
 b1,b2,eta1,eta2=parameters;a1,a2=levels;j1,j2=teeth
 intervals=int(round(z1*resolution/ratio));N=(settle+measure)*intervals
 omega=2*np.pi*rpm/60.;step_phase=2*np.pi/(z1*resolution);dt=step_phase/omega*(2*np.pi*260.)
 q1=q2=v1=v2=0.;s1=s2=norm1=norm2=0.
 for n in range(N):
  ph=n*step_phase;phh=ph+step_phase*.5;phe=ph+step_phase
  u1=load+.63*np.cos(z1*ph+.2)+.075*np.sin(ph)
  u2=.82*load+.59*np.cos(z1*ph+1.6)+.065*np.sin(ratio*ph+.4)
  u1h=load+.63*np.cos(z1*phh+.2)+.075*np.sin(phh)
  u2h=.82*load+.59*np.cos(z1*phh+1.6)+.065*np.sin(ratio*phh+.4)
  u1e=load+.63*np.cos(z1*phe+.2)+.075*np.sin(phe)
  u2e=.82*load+.59*np.cos(z1*phe+1.6)+.065*np.sin(ratio*phe+.4)
  A=rhs(q1,q2,v1,v2,ph,u1,u2,a1,a2,j1,j2,b1,b2,eta1,eta2,z1,ratio,coupling,m2,k1,k2,c1,c2,shaft1,shaft2,phase2)
  B=rhs(q1+.5*dt*A[0],q2+.5*dt*A[1],v1+.5*dt*A[2],v2+.5*dt*A[3],phh,u1h,u2h,a1,a2,j1,j2,b1,b2,eta1,eta2,z1,ratio,coupling,m2,k1,k2,c1,c2,shaft1,shaft2,phase2)
  C=rhs(q1+.5*dt*B[0],q2+.5*dt*B[1],v1+.5*dt*B[2],v2+.5*dt*B[3],phh,u1h,u2h,a1,a2,j1,j2,b1,b2,eta1,eta2,z1,ratio,coupling,m2,k1,k2,c1,c2,shaft1,shaft2,phase2)
  D=rhs(q1+dt*C[0],q2+dt*C[1],v1+dt*C[2],v2+dt*C[3],phe,u1e,u2e,a1,a2,j1,j2,b1,b2,eta1,eta2,z1,ratio,coupling,m2,k1,k2,c1,c2,shaft1,shaft2,phase2)
  q1+=dt/6*(A[0]+2*B[0]+2*C[0]+D[0]);q2+=dt/6*(A[1]+2*B[1]+2*C[1]+D[1])
  v1+=dt/6*(A[2]+2*B[2]+2*C[2]+D[2]);v2+=dt/6*(A[3]+2*B[3]+2*C[3]+D[3])
  if n>=settle*intervals:
   R=rhs(q1,q2,v1,v2,phe,u1e,u2e,a1,a2,j1,j2,b1,b2,eta1,eta2,z1,ratio,coupling,m2,k1,k2,c1,c2,shaft1,shaft2,phase2)
   h1=pulse(phe-2*np.pi*j1/z1,np.pi*1.55/z1)
   h2=pulse(phe*ratio-2*np.pi*j2/(z1/ratio),np.pi*1.55/(z1/ratio))
   s1+=h1*max(R[4],0.)**2;norm1+=h1
   s2+=h2*max(R[5],0.)**2;norm2+=h2
 return np.array([np.sqrt(s1/max(norm1,1e-20)),np.sqrt(s2/max(norm2,1e-20))])

