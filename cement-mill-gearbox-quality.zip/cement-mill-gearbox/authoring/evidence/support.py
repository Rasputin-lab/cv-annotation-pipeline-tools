"""Authoring-only readers and exact generating-state output fixtures."""
import copy,hashlib,importlib.util,json,sys
from pathlib import Path
import numpy as np
import pandas as pd

ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT/'tests'))
sys.path.insert(0,str(ROOT/'authoring/provenance'))
MEMBERS=['stage1_pinion','stage2_pinion']
def load(name,path):
    spec=importlib.util.spec_from_file_location(name,path)
    mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod);return mod
def manifest():return json.loads((ROOT/'authoring/provenance/generation_manifest.json').read_text())['cases']
def folder_for(name):return ROOT/('environment/data' if name=='unit_A' else 'tests/held_out')/name
def fixture(name):
    expected=manifest()[name]['expected']
    table=pd.DataFrame({'observation_id':range(1,len(expected['losses'])+1),'loss_stage1':np.array(expected['losses'])[:,0],'loss_stage2':np.array(expected['losses'])[:,1]})
    summary={k:copy.deepcopy(expected[k]) for k in ('faults','contact_parameters','forecast_hours','maintenance_plan')}
    return expected,table,summary
def write_outputs(output,table,summary):
    output=Path(output);output.mkdir(parents=True,exist_ok=True)
    table.to_csv(output/'gearbox_condition_assessment.csv',index=False)
    (output/'summary.json').write_text(json.dumps(summary,allow_nan=False)+'\n')
def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def hashes(paths):return {str(p.relative_to(ROOT)):sha(p) for p in paths}
def save(path,report):Path(path).write_text(json.dumps(report,indent=2,allow_nan=False)+'\n')
