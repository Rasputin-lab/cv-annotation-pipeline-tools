#!/usr/bin/env python3
"""Complete, executable wrong-science controls; no crashes counted as difficulty."""
import os
os.environ.setdefault('OPENBLAS_NUM_THREADS','1');os.environ.setdefault('OMP_NUM_THREADS','1')
import copy,json,subprocess,sys,tempfile,time
from pathlib import Path
import numpy as np
from support import ROOT,manifest,folder_for,fixture,load,save,hashes

def main():
    reference=load('reference_controls',ROOT/'solution/solve_gearbox.py')
    grader=load('grader_controls',ROOT/'tests/test_gearbox_condition.py')
    methods={k:{} for k in ['healthy_null','single_fault_only','frozen_repair_contact','mean_load_only','single_future_scenario','replace_both_immediately']}
    for name,case in manifest().items():
        if name=='unit_A':continue
        begin=time.monotonic();folder=folder_for(name);e,t,s=fixture(name)
        cfg=np.asarray(case['model_vector']);params=np.asarray(case['parameters']);teeth=np.array(case['tooth_indices'],dtype=np.int64)
        C=np.asarray(case['fatigue_coefficients']);m=np.asarray(case['fatigue_exponents']);start=np.array(e['losses'][-1])
        duties,scenarios,replacement,plans=reference.planning_inputs(folder,500.)
        grid,fields=reference.build_fields(params,teeth,cfg,duties,replacement,spacing=.045,resolution=48)
        def assess(current,field,scenario=scenarios):
            return reference.evaluate(current,scenario,field,grid,C,m,duties,cfg[1],plans,max_step=.025)
        def record(method,table,summary,extra=None):
            result=grader.grade_prediction(e,table,summary,folder,False)
            methods[method][name]={'grade':result,'summary':summary,**(extra or {})}
        tt=t.copy();tt[['loss_stage1','loss_stage2']]=0.;ss=copy.deepcopy(s)
        ss['faults']={k:None for k in ss['faults']};ss['forecast_hours']={'by_scenario':{k:None for k in scenarios},'earliest':None,'latest':None};ss['maintenance_plan']={'plan_id':'continue','worst_case_peak_loss':0.}
        record('healthy_null',tt,ss)
        # A strong one-fault control is given the correct dominant fault and all
        # true contact/qualification parameters, then computes the wrong future.
        keep=int(np.argmax(start));single=start.copy();single[1-keep]=0.
        tt=t.copy();tt['loss_stage'+str(2-keep)]=0.;ss=copy.deepcopy(s)
        ss['faults'][['stage1_pinion','stage2_pinion'][1-keep]]=None
        result=assess(single,fields);ss.update({k:result[k] for k in ['forecast_hours','maintenance_plan']});record('single_fault_only',tt,ss)
        # Preserve the old clearance/coast properties after loss reset.
        frozen=fields.copy();frozen[:,1]=fields[:,0,0:1,:,:];frozen[:,2]=fields[:,0,:,0:1,:]
        result=assess(start,frozen);ss=copy.deepcopy(s);ss['maintenance_plan']=result['maintenance_plan'];record('frozen_repair_contact',t,ss)
        mean=fields.copy()
        for d,(_,force) in enumerate(duties):mean[d,...]=np.array([force,.82*force])
        result=assess(start,mean);ss=copy.deepcopy(s);ss.update({k:result[k] for k in ['forecast_hours','maintenance_plan']});record('mean_load_only',t,ss)
        selected=next(iter(scenarios));result=assess(start,fields,{selected:scenarios[selected]});ss=copy.deepcopy(s)
        crossing=result['forecast_hours']['by_scenario'][selected]
        ss['forecast_hours']={'by_scenario':{k:crossing for k in scenarios},'earliest':crossing,'latest':crossing};ss['maintenance_plan']=result['maintenance_plan'];record('single_future_scenario',t,ss)
        immediate=next(p for p in e['plan_results'] if p['plan_id']=='job_03');ss=copy.deepcopy(s);ss['maintenance_plan']={'plan_id':immediate['plan_id'],'worst_case_peak_loss':immediate['peak']};record('replace_both_immediately',t,ss)
        print('completed controls',name,'seconds',round(time.monotonic()-begin,2),flush=True)
    # A complete inverse-fit ablation, rather than editing an answer's label.
    original=(ROOT/'solution/solve_gearbox.py').read_text()
    variant=original.replace("np.repeat(bound['coast_stiffness_ratio'][0],2)","np.repeat(.9999,2)").replace("np.repeat(bound['coast_stiffness_ratio'][1],2)","np.repeat(1.0001,2)").replace('[.18,.20,.78,.78]','[.18,.20,1.,1.]')
    assert variant!=original
    with tempfile.TemporaryDirectory() as temp:
        temp=Path(temp);source=temp/'symmetric_coast.py';source.write_text(variant);out=temp/'output'
        run=subprocess.run([sys.executable,str(source),str(folder_for('unit_B')),str(out)],capture_output=True,text=True,timeout=300)
        assert run.returncode==0,(run.stdout,run.stderr)
        ablation={'scope':'Complete nonlinear inverse fit, unit_B; coast stiffness constrained to symmetric value 1. All other stages run normally.','exit_code':run.returncode,'stdout':run.stdout,'grade':grader.grade_files(folder_for('unit_B'),out,check_physics=False),'summary':json.loads((out/'summary.json').read_text())}
        assert not ablation['grade']['passed']
    summaries={k:{'n_units':len(v),'n_pass':sum(row['grade']['passed'] for row in v.values()),'suite_reward':int(all(row['grade']['passed'] for row in v.values()))} for k,v in methods.items()}
    print(json.dumps(summaries),flush=True)
    report={'scope':'Authoring controls, not agent solve rates. Controls receive true unaffected quantities and true fatigue coefficients, deliberately making them stronger. Every control emits a complete valid-shape artifact; rejection is on physical targets/decisions.','source_sha256':hashes([ROOT/'solution/solve_gearbox.py',ROOT/'tests/test_gearbox_condition.py',Path(__file__)]),'controls':methods,'summary':summaries,'symmetric_coast_fit':ablation,'passed':all(x['suite_reward']==0 for x in summaries.values())}
    save(Path(__file__).with_name('scientific_controls.json'),report);print(json.dumps(summaries),flush=True)
    if not report['passed']:raise SystemExit('At least one wrong-science control still passes the entire suite')
if __name__=='__main__':main()
