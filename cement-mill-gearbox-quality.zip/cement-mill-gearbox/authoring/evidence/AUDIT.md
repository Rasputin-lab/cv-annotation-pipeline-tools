# Local scientific and runtime audit

These are authoring checks on the supplied experiments. They are not platform
Quality, Easiness, Difficulty or Run-audit results. New remote probes must evaluate
this revision; no model solve rate or automatic acceptance is guaranteed.

## Correct numerical methods

Both implementations pass all seven generated experiments (14/14 fresh executions),
including the private forward forecast-consistency calculation. The reference
runs in 11.7–24.3 seconds per input;
the alternative runs in 18.2–36.2 seconds.
The per-case allowance is 300 seconds. Local process timings are not a container
performance guarantee. validation_results.json records input/source hashes,
exit codes, numerical errors, summaries and diagnostics.

Physical-state targets are generated independently of either inverse estimate.
The generator uses finer mechanical integration and a finer future loading grid.
The alternative has its own contact evaluation, SSPRK3 integration, response
calibration, tooth search, qualification fitting and adaptive growth integration.
Only ordinary input/schema reader text is shared. Neither method imports the
other solution or private truth at runtime. Local numerical validation itself is
not an isolation test; validate_containers.py covers that separate property.

## Wrong scientific assumptions

Every control provides complete valid-shape outputs. Most receive perfect true
unaffected quantities and qualification coefficients, deliberately giving the
wrong model an advantage. Scientific controls concern the consequences of the
wrong assumption, not process crashes or formatting failures.

| Control | Individual cases passed | Full-suite reward |
| --- | --- | --- |
| healthy null | 0/6 | 0 |
| single fault only | 2/6 | 0 |
| frozen repair contact | 5/6 | 0 |
| mean load only | 0/6 | 0 |
| single future scenario | 0/6 | 0 |
| replace both immediately | 0/6 | 0 |

Single-fault modelling legitimately passes the two single-fault experiments.
Keeping old post-repair contact properties passes five experiments but selects
an unsafe job in the production campaign where contact-branch effects matter.
All six graded experiments have real measured stiffness losses; no healthy null
gets free credit. The complete constrained-symmetric-coast inverse fit on unit_B
also exits successfully and receives a failing physical grade. Its scope is one
experiment, not six. scientific_controls.json records every result and failure.
These counts are engineered control results, not model-agent solve rates.

## Mechanics and specification

physical_checks.json records positive mass-matrix eigenvalues and coefficients,
a zero-force backlash interval, nonnegative fixed-angle contact potential,
consistent tooth periods and coincident mesh fundamental orders. The spatial
sensor matrix has rank one. Allowance-scaled local sensitivities across operating
probes have rank six for the four contact properties and two current losses.
This is local sensitivity evidence, not a proof of global identifiability.

Mechanical integration is compared at 2,4,8 RK4 substeps. A separately coded
SciPy DOP853 forward calculation agrees with the finest unit_B force trace to
7.63e-06 g RMS after force-to-g scaling,
before acquisition filtering. Future-load integration is compared at 48,72,96
steps per tooth; settling sensitivity is recorded. All computed force moments
are inside the fatigue qualification. A separate, unscored healthy experiment
is correctly assessed by both complete solvers after its truth file is removed.

semantic_checks.json records 35 passing regression checks, including
correct fixtures, schema/finite-number enforcement, duplicate JSON keys,
tooth-index types, censoring, envelope arithmetic, unsafe jobs, excess cost and
missing artifacts. The canonical input README specifies exactly what is scored,
in what units, with explicit tolerances and mechanical conditioning.

## Runtime status

Actual fresh offline Docker runs passed: three reference rewards 1,1,1; three no-change rewards 0,0,0; an alternative-solver reward 1; and an unprivileged private-answer/reward-write probe reward 0. Each container used 2 CPUs and 8192 MB. Read denials and output transport were checked. See container_validation.json.

## Bundle boundaries

Only the visible unit and dependencies enter the agent image. Graded inputs,
expected states and forward grader remain in the separate verifier image;
authoring scripts and reports are excluded from both image contexts except for
the explicitly private tests. The input copy supplied to the submitted solver
contains no truth.json. No raw browser exports, personal résumés, session
credentials, downloaded papers, caches or development prototypes are shipped.
See ../provenance/PROVENANCE.md and CHECKSUMS.sha256 for file purposes and integrity.
