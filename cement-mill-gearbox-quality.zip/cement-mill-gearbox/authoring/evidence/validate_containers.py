#!/usr/bin/env python3
"""Build the shipped runtimes and exercise actual offline artifact transport."""
import argparse,hashlib,json,os,subprocess,tempfile,time
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2]
DOCKER=['env','-u','DOCKER_HOST','-u','DOCKER_CONTEXT','-u','DOCKER_TLS','-u','DOCKER_TLS_VERIFY','-u','DOCKER_CERT_PATH','docker','--host=unix:///var/run/docker.sock']
AGENT='gearbox-agent:nonlinear-20261024';VERIFIER='gearbox-verifier:nonlinear-20261024'
SOURCES=['solution/solve_gearbox.py','solution/solve.sh','authoring/evidence/independent_solver.py','authoring/evidence/self_cheat.py','tests/test.sh','tests/test_gearbox_condition.py','tests/Dockerfile','environment/Dockerfile','authoring/provenance/generate_cases.py','authoring/provenance/simulator.py','authoring/provenance/qualification.py','tests/physics.py']
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def command(args,**kwargs):return subprocess.run(DOCKER+args,text=True,capture_output=True,check=False,**kwargs)
def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('work_directory',type=Path);p.add_argument('--build',action='store_true');p.add_argument('--managed-ca',type=Path);a=p.parse_args()
    base=a.work_directory.resolve();base.mkdir(parents=True,exist_ok=True)
    initial={s:sha(ROOT/s) for s in SOURCES};os.environ.setdefault('BUILDX_CONFIG',str(base/'buildx'))
    if a.build:
        for context,image in [('environment',AGENT),('tests',VERIFIER)]:
            text=(ROOT/context/'Dockerfile').read_text();args=[]
            if a.managed_ca:
                # Preserve exactly the pins/contexts; session CA is a build-only
                # secret and never copied into an image layer or the task.
                text=text.replace('RUN pip install','RUN --mount=type=secret,id=proxy_ca,required=true PIP_CERT=/run/secrets/proxy_ca pip install')
                args=['--secret','id=proxy_ca,src='+str(a.managed_ca)]
            dockerfile=base/(context+'.Dockerfile');dockerfile.write_text(text)
            result=command(['build',*args,'-f',str(dockerfile),'-t',image,str(ROOT/context)],timeout=900)
            (base/(context+'-build.log')).write_text(result.stdout+result.stderr)
            if result.returncode:raise RuntimeError('Image build failed; inspect '+str(base/(context+'-build.log')))
            print('Built',image,flush=True)
    audit='''import json,os,pathlib
records=[]
for name in ('unit_B','unit_C','unit_D','unit_E','unit_F','unit_G'):
 try:pathlib.Path('/tests/held_out',name,'truth.json').read_text();result='readable'
 except OSError as e:result=type(e).__name__
 records.append(result)
try:pathlib.Path('/logs/verifier/audit-write.txt').write_text('probe');write='writable'
except OSError as e:write=type(e).__name__
print('ISOLATION='+json.dumps({'uid':os.getuid(),'private_truth_reads':records,'reward_directory_write':write}))
'''
    audit_path=base/'isolation_audit.py';audit_path.write_text(audit);audit_path.chmod(0o644)
    report={'scope':'Actual fresh Docker executions with 2 CPUs, 8192 MB and network none. No platform or model-probe results claimed.',
            'source_sha256':initial,'trials':[],'images':{}}
    for image in (AGENT,VERIFIER):
        result=command(['image','inspect',image,'--format','{{.Id}}']);assert result.returncode==0
        report['images'][image]=result.stdout.strip()
    for route,attempts in [('oracle',3),('nop',3),('independent',1),('self_cheat',1)]:
        for attempt in range(1,attempts+1):
            trial=base/(route+'-'+str(attempt));trial.mkdir(exist_ok=True);logs=trial/'logs';logs.mkdir(exist_ok=True)
            if route!='nop':
                src=ROOT/{'oracle':'solution/solve_gearbox.py','independent':'authoring/evidence/independent_solver.py','self_cheat':'authoring/evidence/self_cheat.py'}[route]
                staging=trial/'solution';staging.mkdir(exist_ok=True)
                (staging/'solve_gearbox.py').write_bytes(src.read_bytes());(staging/'solve.sh').write_bytes((ROOT/'solution/solve.sh').read_bytes())
                # The adversarial control needs only staging, since its expected
                # access denials occur in the private verifier runtime.
                stage_cmd='mkdir -p /logs/artifacts; cp /solution/solve_gearbox.py /logs/artifacts/solve_gearbox.py; chmod 600 /logs/artifacts/solve_gearbox.py' if route=='self_cheat' else 'bash /solution/solve.sh && chmod 600 /logs/artifacts/solve_gearbox.py'
                stage=command(['run','--rm','--network=none','--cpus=2','--memory=8192m','-v',str(staging)+':/solution:ro','-v',str(logs)+':/logs',AGENT,'bash','-c',stage_cmd],timeout=400)
                (trial/'staging.log').write_text(stage.stdout+stage.stderr);assert stage.returncode==0,stage.stderr
            shell='''bash /tests/test.sh
status=$?
runuser -u nobody -- python3 /tmp/isolation_audit.py
python3 - <<'CODE'
import json,pathlib,platform
print('RESULT='+json.dumps({'reward':pathlib.Path('/logs/verifier/reward.txt').read_text(),'metrics':json.loads(pathlib.Path('/root/results/metrics.json').read_text()),'python':platform.python_version(),'memory_bytes':pathlib.Path('/sys/fs/cgroup/memory.max').read_text().strip(),'unit_exit_codes':{n:int(pathlib.Path('/logs/verifier',n+'.exit_code.txt').read_text()) for n in ('unit_B','unit_C','unit_D','unit_E','unit_F','unit_G')},'unit_stdout':{n:pathlib.Path('/logs/verifier',n+'.stdout.log').read_text() for n in ('unit_B','unit_C','unit_D','unit_E','unit_F','unit_G')}}))
CODE
exit "$status"
'''
            begin=time.monotonic();run=command(['run','--rm','--network=none','--cpus=2','--memory=8192m','-v',str(logs)+':/logs','-v',str(audit_path)+':/tmp/isolation_audit.py:ro',VERIFIER,'bash','-c',shell],timeout=2100)
            (trial/'runtime.log').write_text(run.stdout+run.stderr)
            result=next((json.loads(s[7:]) for s in run.stdout.splitlines() if s.startswith('RESULT=')),None)
            isolation=next((json.loads(s[10:]) for s in run.stdout.splitlines() if s.startswith('ISOLATION=')),None)
            record={'route':route,'attempt':attempt,'exit_code':run.returncode,'seconds':time.monotonic()-begin,'result':result,'isolation':isolation};report['trials'].append(record)
            (base/'progress.json').write_text(json.dumps(report,indent=2)+'\n')
            print(route,attempt,'reward',result['reward'].strip() if result else None,'seconds',round(record['seconds'],2),flush=True)
            expected=0 if route in ('nop','self_cheat') else 1
            assert result and result['reward']==str(expected)+'\n',record
            assert result['memory_bytes']==str(8192*1024*1024)
            assert isolation and isolation['uid']!=0 and isolation['private_truth_reads']==['PermissionError']*6 and isolation['reward_directory_write']=='PermissionError'
            if expected:assert run.returncode==0 and set(result['unit_exit_codes'].values())=={0} and result['metrics']['n_pass']==6
            if route=='self_cheat':
                for value in result['unit_stdout'].values():
                    probe=json.loads(value);assert probe['uid']!=0 and all(r['read']=='PermissionError' for r in probe['reads']) and probe['reward_write']=='PermissionError'
    report['source_unchanged']=initial=={s:sha(ROOT/s) for s in SOURCES};assert report['source_unchanged']
    report['artifact_transport']='Actual solve.sh staging, then artifact chmod0600, then private scratch copy readable by nobody.'
    report['passed']=True
    Path(__file__).with_name('container_validation.json').write_text(json.dumps(report,indent=2,allow_nan=False)+'\n')
    print('All isolated runtime checks passed',flush=True)
if __name__=='__main__':main()
