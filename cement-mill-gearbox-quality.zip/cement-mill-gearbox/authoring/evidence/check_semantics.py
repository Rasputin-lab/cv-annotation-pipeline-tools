#!/usr/bin/env python3
"""Exercise exact schema, censoring, physical targets and decision semantics."""
import copy,json,tempfile
from pathlib import Path
import numpy as np
from support import ROOT,folder_for,fixture,load,save,write_outputs,hashes

def main():
    g=load('grader_semantics',ROOT/'tests/test_gearbox_condition.py');checks=[]
    def record(label,result,wanted):
        ok=result['passed']==wanted
        checks.append({'check':label,'expected_pass':wanted,'passed':ok,'grade':result})
        assert ok,(label,result)
    for letter in 'BCDEFG':
        name='unit_'+letter;e,t,s=fixture(name);folder=folder_for(name)
        record(name+' exact generating-state fixture',g.grade_prediction(e,t,s,folder,False),True)
    e,t,s=fixture('unit_B');folder=folder_for('unit_B')
    def mutate(label,change):
        tt=t.copy(deep=True);ss=copy.deepcopy(s);change(tt,ss)
        record(label,g.grade_prediction(e,tt,ss,folder,False),False)
    mutate('unknown JSON field',lambda t,s:s.update(extra=1))
    mutate('missing summary field',lambda t,s:s.pop('faults'))
    mutate('unknown CSV column',lambda t,s:t.insert(0,'extra',0))
    mutate('duplicate observation',lambda t,s:t.__setitem__('observation_id',[1]*len(t)))
    mutate('nonfinite loss',lambda t,s:t.loc.__setitem__((0,'loss_stage1'),np.nan))
    mutate('negative loss',lambda t,s:t.loc.__setitem__((0,'loss_stage1'),-.01))
    mutate('incorrect loss',lambda t,s:t.__setitem__('loss_stage1',t.loss_stage1+.02))
    mutate('boolean tooth is not integer index',lambda t,s:s['faults'].__setitem__('stage1_pinion',True))
    mutate('incorrect tooth index',lambda t,s:s['faults'].__setitem__('stage1_pinion',s['faults']['stage1_pinion']+1))
    mutate('negative tooth index',lambda t,s:s['faults'].__setitem__('stage1_pinion',-1))
    mutate('false healthy diagnosis',lambda t,s:s['faults'].__setitem__('stage1_pinion',None))
    mutate('incorrect clearance',lambda t,s:s['contact_parameters']['backlash_halfwidth_um'].__setitem__(0,s['contact_parameters']['backlash_halfwidth_um'][0]+10))
    mutate('incorrect coast ratio',lambda t,s:s['contact_parameters']['coast_stiffness_ratio'].__setitem__(0,s['contact_parameters']['coast_stiffness_ratio'][0]+.05))
    mutate('boolean continuous parameter',lambda t,s:s['contact_parameters']['coast_stiffness_ratio'].__setitem__(0,True))
    mutate('unknown scenario',lambda t,s:s['forecast_hours']['by_scenario'].update(unknown=None))
    mutate('nonfinite forecast',lambda t,s:s['forecast_hours']['by_scenario'].__setitem__('normal_production',float('inf')))
    mutate('wrong censoring',lambda t,s:s['forecast_hours']['by_scenario'].__setitem__('normal_production',None))
    mutate('inconsistent envelope',lambda t,s:s['forecast_hours'].__setitem__('earliest',0.))
    mutate('negative forecast',lambda t,s:s['forecast_hours']['by_scenario'].__setitem__('normal_production',-2.))
    mutate('unknown plan',lambda t,s:s['maintenance_plan'].__setitem__('plan_id','invented'))
    bad=next(p for p in e['plan_results'] if not p['safe'])
    mutate('unsafe but cheap plan',lambda t,s:s.__setitem__('maintenance_plan',{'plan_id':bad['plan_id'],'worst_case_peak_loss':.35}))
    costly=max((p for p in e['plan_results'] if p['safe']),key=lambda p:p['cost_units'])
    mutate('safe but nonminimal plan',lambda t,s:s.__setitem__('maintenance_plan',{'plan_id':costly['plan_id'],'worst_case_peak_loss':costly['peak']}))
    mutate('wrong counterfactual peak',lambda t,s:s['maintenance_plan'].__setitem__('worst_case_peak_loss',.01))
    mutate('planning ceiling violated in report',lambda t,s:s['maintenance_plan'].__setitem__('worst_case_peak_loss',.4))
    with tempfile.TemporaryDirectory() as tmp:
        out=Path(tmp);write_outputs(out,t,s)
        record('complete files',g.grade_files(folder,out,e,False),True)
        for text,label in [('{"faults":{},"faults":{}}','duplicate JSON key'),('{"x":NaN}','JSON NaN constant')]:
            (out/'summary.json').write_text(text);record(label,g.grade_files(folder,out,e,False),False)
        write_outputs(out,t,s);(out/'summary.json').unlink();record('missing JSON',g.grade_files(folder,out,e,False),False)
        write_outputs(out,t,s);(out/'gearbox_condition_assessment.csv').unlink();record('missing CSV',g.grade_files(folder,out,e,False),False)
    report={'scope':'Semantic regression only; correct numerical solvers are checked separately with private forward physics.','source_sha256':hashes([ROOT/'tests/test_gearbox_condition.py',Path(__file__)]),'checks':checks,'n_checks':len(checks),'passed':all(c['passed'] for c in checks)}
    save(Path(__file__).with_name('semantic_checks.json'),report);print('semantic checks',len(checks),'PASS',report['passed'])
if __name__=='__main__':main()
