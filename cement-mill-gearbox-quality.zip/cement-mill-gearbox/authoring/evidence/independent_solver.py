#!/usr/bin/env python3
"""Calibrated nonlinear gearbox contact inference and maintenance decisions."""
import os
os.environ.setdefault("OPENBLAS_NUM_THREADS","1")
os.environ.setdefault("OMP_NUM_THREADS","1")
import json,time
from pathlib import Path
MEMBERS=["stage1_pinion","stage2_pinion"]
AXES=["ax_g","ay_g","az_g"]
import os
os.environ.setdefault('OPENBLAS_NUM_THREADS','1');os.environ.setdefault('OMP_NUM_THREADS','1')
import numpy as np
from numba import njit
from scipy import optimize,signal,stats,interpolate,integrate

@njit
def tooth_window(angle,index,teeth):
 gap=(angle/(2*np.pi)-index/teeth+.5)%1.-.5
 half=1.55/(2*teeth)
 if abs(gap)>half:return 0.
 return .5+.5*np.cos(np.pi*gap/half)

@njit
def flow(x,y,v,w,theta,f,g,loss1,loss2,j1,j2,p,cfg):
 z=cfg[0];ratio=cfg[1];k1=cfg[4]*(1+.18*np.cos(z*theta)+.035*np.cos(2*z*theta));k2=cfg[5]*(1+.16*np.cos(z*theta+cfg[10])+.045*np.cos(2*z*theta+2*cfg[10]))
 if x>p[0]:F=k1*(x-p[0])*(1-loss1*tooth_window(theta,j1,z))
 elif x<-p[0]:F=k1*p[2]*(x+p[0])
 else:F=0.
 if y>p[1]:G=k2*(y-p[1])*(1-loss2*tooth_window(ratio*theta,j2,z/ratio))
 elif y<-p[1]:G=k2*p[3]*(y+p[1])
 else:G=0.
 u=f-cfg[6]*v-cfg[8]*x-F;h=g-cfg[7]*w-cfg[9]*y-G;det=cfg[3]-cfg[2]**2
 return v,w,(cfg[3]*u-cfg[2]*h)/det,(h-cfg[2]*u)/det,F,G

@njit
def simulation(theta,drive,levels,parameters,teeth,config,dt,subsample):
 nr=theta.shape[0];ns=(theta.shape[1]-1)//2;force=np.zeros((nr,2,ns//subsample));trace=np.zeros((nr,ns//subsample))
 for r in range(nr):
  x=y=v=w=0.
  for n in range(ns):
   t=2*n;a=flow(x,y,v,w,theta[r,t],drive[r,t,0],drive[r,t,1],levels[r,0],levels[r,1],teeth[0],teeth[1],parameters,config)
   b=flow(x+dt*a[0],y+dt*a[1],v+dt*a[2],w+dt*a[3],theta[r,t+2],drive[r,t+2,0],drive[r,t+2,1],levels[r,0],levels[r,1],teeth[0],teeth[1],parameters,config)
   c=flow(x+dt*(a[0]+b[0])/4,y+dt*(a[1]+b[1])/4,v+dt*(a[2]+b[2])/4,w+dt*(a[3]+b[3])/4,theta[r,t+1],drive[r,t+1,0],drive[r,t+1,1],levels[r,0],levels[r,1],teeth[0],teeth[1],parameters,config)
   x+=dt*(a[0]+b[0]+4*c[0])/6;y+=dt*(a[1]+b[1]+4*c[1])/6;v+=dt*(a[2]+b[2]+4*c[2])/6;w+=dt*(a[3]+b[3]+4*c[3])/6
   if (n+1)%subsample==0:
    f=flow(x,y,v,w,theta[r,t+2],drive[r,t+2,0],drive[r,t+2,1],levels[r,0],levels[r,1],teeth[0],teeth[1],parameters,config);i=n//subsample
    force[r,0,i]=f[4];force[r,1,i]=f[5];trace[r,i]=f[4]+config[-1]*f[5]
 return trace,force

def calibrate_mounts(frame,fs,F0):
 result=[]
 for axis in AXES:
  data=frame[frame.axis==axis];frequency=data.frequency_hz.to_numpy();h=(data.real_g_per_N.to_numpy()+1j*data.imag_g_per_N.to_numpy())*F0;src=(data.source=='stage2').to_numpy().astype(int)
  reference=2*np.pi*700.;omega=2*fs*np.tan(np.pi*frequency/fs);x=omega/reference
  matrix=np.c_[h,1j*h*x,np.eye(2)[src]*x[:,None]**2];rhs=h*x*x;base_weight=1/(abs(h)+.0005);weight=base_weight.copy()
  for _ in range(7):
   A=np.r_[matrix.real*weight[:,None],matrix.imag*weight[:,None]];y=np.r_[rhs.real*weight,rhs.imag*weight];p=np.linalg.lstsq(A,y,rcond=None)[0]
   weight=base_weight/abs(p[0]-x*x+1j*p[1]*x)
  wn=reference*np.sqrt(p[0]);damping=p[1]/(2*np.sqrt(p[0]));k=2*fs;den=k*k+2*damping*wn*k+wn*wn
  b=np.array([k*k,-2*k*k,k*k])/den;a=np.array([1.,2*(wn*wn-k*k)/den,(k*k-2*damping*wn*k+wn*wn)/den])
  result.append((np.array([wn/(2*np.pi),damping,p[2],p[3]]),b,a))
 return result

def filter_kernel(b,a,length=384):
 h=np.zeros(length);h[0]=b[0];h[1]=b[1]-a[1]*h[0];h[2]=b[2]-a[1]*h[1]-a[2]*h[0]
 for i in range(3,length):h[i]=-a[1]*h[i-1]-a[2]*h[i-2]
 return h

def infer_physical_state(ex,settings=None):
 import pandas as pd
 root=Path(ex['folder']);raw=pd.read_csv(root/'vibration_windows.csv');data=[]
 gain=np.array([m[0][2] for m in ex['mounts']]);kernels=[filter_kernel(m[1],m[2]) for m in ex['mounts']];sigma=ex['spec']['measurement_noise_standard_deviation_g']/abs(gain)
 for r in ex['records'].itertuples(index=False):data.append(raw[raw.record_id==r.record_id][AXES].to_numpy()/gain)
 data=np.asarray(data);use=np.isfinite(data);use[:,:30]=False;use[:,np.arange(data.shape[1])%3!=0]=False;data=np.nan_to_num(data)
 cfg=ex['config'];nobs=len(ex['observations']);group=ex['groups'];scale=ex['spec']['displacement_scale_um'];bounds=ex['spec']['parameter_bounds']
 lo=np.r_[[bounds['backlash_halfwidth_um'][0]/scale]*2,[bounds['coast_stiffness_ratio'][0]]*2];hi=np.r_[[bounds['backlash_halfwidth_um'][1]/scale]*2,[bounds['coast_stiffness_ratio'][1]]*2]
 cfg[-1]=float(np.median([m[0][3]/m[0][2] for m in ex['mounts']]))
 def prediction(p,levels,teeth,selection=None):
  theta=ex['theta'] if selection is None else ex['theta'][selection];u=ex['drive'] if selection is None else ex['drive'][selection]
  trace,_=simulation(theta,u,levels,p,teeth,cfg,ex['dt'],ex['substeps']);trace=np.c_[np.zeros(len(trace)),trace]
  return np.stack([signal.fftconvolve(trace,h[None,:],axes=1,mode='full')[:,:trace.shape[1]] for h in kernels],axis=2)
 def residual(pred,selected=None):
  d=data if selected is None else data[selected];v=use if selected is None else use[selected]
  return ((pred-d)/sigma)[v]
 zeros=np.zeros((len(group),2));tooth=np.array([0,0],dtype=np.int64)
 rough=optimize.least_squares(lambda p:residual(prediction(p,zeros,tooth)),[.17,.21,.8,.8],bounds=(lo,hi),loss='huber',f_scale=3.,x_scale='jac',diff_step=2e-4,max_nfev=50).x
 selected=np.flatnonzero(group==nobs);amount=np.array([0.,0.]);history=[]
 for sweep in range(3):
  for stage,count in enumerate([int(cfg[0]),int(round(cfg[0]/cfg[1]))]):
   active=np.repeat(amount[None,:],len(selected),axis=0);active[:,stage]=0.;base=prediction(rough,active,tooth,selected);r0=residual(base,selected);ranking=[]
   for j in range(count):
    candidate=tooth.copy();candidate[stage]=j;test=active.copy();test[:,stage]=.15;delta=residual(prediction(rough,test,candidate,selected),selected)-r0
    coefficient=np.clip(-np.dot(r0,delta)/np.dot(delta,delta),0.,2.9);ranking.append((float(np.dot(r0+coefficient*delta,r0+coefficient*delta)),j,float(coefficient*.15)))
   winner=None
   for _,j,seed in sorted(ranking)[:3]:
    candidate=tooth.copy();candidate[stage]=j
    def objective(value):
     test=active.copy();test[:,stage]=value;rr=residual(prediction(rough,test,candidate,selected),selected);return float(np.dot(rr,rr))
    fit=optimize.minimize_scalar(objective,bounds=(0,.44),method='bounded',options={'xatol':2e-4,'maxiter':18})
    if winner is None or fit.fun<winner[0]:winner=(fit.fun,j,fit.x)
   tooth[stage]=winner[1];amount[stage]=winner[2]
  def late(p):return residual(prediction(p[:4],np.repeat(p[4:][None,:],len(selected),axis=0),tooth,selected),selected)
  fit=optimize.least_squares(late,np.r_[rough,amount],bounds=(np.r_[lo,0,0],np.r_[hi,.44,.44]),x_scale='jac',diff_step=2e-4,max_nfev=35)
  rough=fit.x[:4];amount=fit.x[4:];rms=float(np.sqrt(np.mean(fit.fun**2)));history.append({'teeth':tooth.tolist(),'rms_sigma':rms})
  if rms<1.45:break
 initial=np.r_[rough,(np.linspace(.3,1.,nobs)[:,None]*amount).ravel()]
 def all_residual(p):
  levels=np.vstack([np.zeros(2),p[4:].reshape(nobs,2)]);return residual(prediction(p[:4],levels[group],tooth))
 fit=optimize.least_squares(all_residual,initial,bounds=(np.r_[lo,np.zeros(nobs*2)],np.r_[hi,np.full(nobs*2,.44)]),x_scale='jac',diff_step=2e-4,max_nfev=70,ftol=1e-8,xtol=1e-8)
 states=fit.x[4:].reshape(nobs,2);present=states[-1]>=ex['spec']['stiffness_loss_detection'];states[:,~present]=0.
 return fit.x[:4],states,tooth,{'profile_sweeps':history,'final_rms_sigma':float(np.sqrt(np.mean(fit.fun**2))),'n_evaluations':fit.nfev}

def fit_fatigue(folder):
 import pandas as pd
 frame=pd.read_csv(Path(folder)/'fatigue_tests.csv');C=[];m=[]
 for member in MEMBERS:
  data=frame[frame.member==member];a=data.stiffness_loss.to_numpy();x=np.log(data.root_load_rms_over_reference);y=np.log(data.loss_rate_per_pinion_cycle*(1-a)**2/a)
  slope,intercept,_,_=stats.theilslopes(y,x);C.append(np.exp(intercept));m.append(slope)
 return np.array(C),np.array(m)

def independent_intensity(losses,parameters,teeth,cfg,rpm,L,resolution=64):
 z=cfg[0];ratio=cfg[1];period=int(round(z*resolution/ratio));total=6*period;phase=np.arange(2*total+1)*np.pi/(z*resolution);omega=2*np.pi*rpm/60.
 u1=L+.63*np.cos(z*phase+.2)+.075*np.sin(phase);u2=.82*L+.59*np.cos(z*phase+1.6)+.065*np.sin(ratio*phase+.4)
 _,force=simulation(phase[None,:],np.column_stack([u1,u2])[None,:,:],losses[None,:],parameters,teeth,cfg,(2*np.pi*260)*2*np.pi/(z*resolution)/omega,1)
 phase=phase[2::2][3*period:];answer=[]
 for j,angle in enumerate([phase,ratio*phase]):
  count=z if j==0 else z/ratio;gap=(angle/(2*np.pi)-teeth[j]/count+.5)%1.-.5;half=1.55/(2*count);weight=np.where(abs(gap)<half,.5+.5*np.cos(np.pi*gap/half),0.)
  answer.append(np.sqrt(np.dot(weight,np.maximum(force[0,j,3*period:],0.)**2)/sum(weight)))
 return np.asarray(answer)

def independent_fields(parameters,teeth,cfg,duties,replacement):
 grid=np.linspace(0,.45,16);maps={}
 for d,(rpm,L) in enumerate(duties):
  values=np.zeros((len(grid),len(grid),2))
  for i,x in enumerate(grid):
   for j,y in enumerate(grid):values[i,j]=independent_intensity(np.array([x,y]),parameters,teeth,cfg,rpm,L)
  maps[d,0]=interpolate.RegularGridInterpolator((grid,grid),values,bounds_error=False,fill_value=None)
  for mode in (1,2):
   p=parameters.copy();p[mode-1]=replacement[mode-1];p[mode+1]=replacement[mode+1];v=np.zeros_like(values)
   for i,x in enumerate(grid):
    levels=np.array([0.,x]) if mode==1 else np.array([x,0.]);I=independent_intensity(levels,p,teeth,cfg,rpm,L)
    if mode==1:v[:,i]=I
    else:v[i,:]=I
   maps[d,mode]=interpolate.RegularGridInterpolator((grid,grid),v,bounds_error=False,fill_value=None)
 return maps

def independent_path(initial,rows,maps,C,m,duties,ratio,ceiling,when=-1.,mask=0):
 state=initial.copy();peak=float(max(state));time=0.;acted=False;mode=0
 for d,hours in rows:
  d=int(d);end=time+hours
  while time<end-1e-10:
   if mask and not acted and when<=time+1e-9:
    if mask&1:state[0]=0.
    if mask&2:state[1]=0.
    acted=True;mode=mask
   if not np.any(state>0):return None,peak
   finish=min(end,when) if mask and not acted and when>time else end
   def derivative(t,y):
    I=np.maximum(maps[d,mode](np.clip(y,0,.45)[None,:])[0],0.)
    return duties[d,0]*60*np.array([1.,ratio])*C*I**m*y/(1-y)**2
   def hit(t,y):return ceiling-float(max(y))
   hit.terminal=True;hit.direction=-1
   solution=integrate.solve_ivp(derivative,(time,finish),state,rtol=2e-7,atol=1e-9,max_step=.08,events=hit)
   if len(solution.t_events[0]):return float(solution.t_events[0][0]),max(peak,ceiling)
   state=solution.y[:,-1];peak=max(peak,float(max(state)));time=finish
 return None,peak

def independent_decision(initial,scenarios,maps,C,m,duties,ratio,plans,policy):
 crossings={name:independent_path(initial,rows,maps,C,m,duties,ratio,policy['diagnostic_stiffness_loss_limit'])[0] for name,rows in scenarios.items()}
 finite=[v for v in crossings.values() if v is not None];forecast={'by_scenario':crossings,'earliest':min(finite) if finite else None,'latest':max(finite) if len(finite)==len(crossings) else None}
 chosen=None
 for plan in sorted(plans,key=lambda p:p['cost_units']):
  runs=[independent_path(initial,rows,maps,C,m,duties,ratio,policy['planning_loss_ceiling'],plan['time'],plan['mask']) for rows in scenarios.values()]
  if all(crossing is None for crossing,_ in runs):chosen={'plan_id':plan['plan_id'],'worst_case_peak_loss':max(peak for _,peak in runs)};break
 if chosen is None:raise RuntimeError('No feasible maintenance plan')
 return {'forecast_hours':forecast,'maintenance_plan':chosen}

def read_experiment(folder,substeps=2):
 import pandas as pd
 folder=Path(folder);spec=json.loads((folder/'gearbox.json').read_text());records=pd.read_csv(folder/'records.csv');obs=pd.read_csv(folder/'observations.csv');raw=pd.read_csv(folder/'vibration_windows.csv')
 fs=spec['sampling_rate_hz'];scale=spec['force_scale_N'];mounts=calibrate_mounts(pd.read_csv(folder/'transfer_calibration.csv'),fs,scale)
 cal,b,a=mounts[0];teeth=spec['teeth'];ratio=teeth['stage1_pinion']/teeth['stage1_wheel'];mass=spec['mass_matrix']
 config=np.array([teeth['stage1_pinion'],ratio,mass[0][1],mass[1][1],*spec['drive_mesh_stiffness'],*spec['modal_damping'],*spec['shaft_stiffness'],spec['mesh_phase_stage2_rad'],cal[3]/cal[2]])
 theta=[];drive=[];data=[];group=[];mapping={int(oid):i+1 for i,oid in enumerate(obs.observation_id)};mapping[0]=0
 for r in records.itertuples(index=False):
  v=raw[raw.record_id==r.record_id];T=v.input_angle_rad.to_numpy();U=v[['force1_N','force2_N']].to_numpy()/scale
  old=np.arange(len(v));dense=np.arange((len(v)-1)*substeps*2+1)/(substeps*2)
  theta.append(np.interp(dense,old,T));drive.append(np.column_stack([np.interp(dense,old,U[:,j]) for j in range(2)]));data.append(v.ax_g.to_numpy()/cal[2]);group.append(mapping[int(r.observation_id)])
 data=np.asarray(data);valid=np.isfinite(data);valid[:,:30]=False;observed=np.nan_to_num(data)
 return {'spec':spec,'observations':obs,'records':records,'theta':np.asarray(theta),'drive':np.asarray(drive),'data':observed,'valid':valid,'groups':np.asarray(group),'config':config,'b':b,'a':a,'dt':spec['reference_angular_frequency_rad_per_s']/(fs*substeps),'substeps':substeps,'mounts':mounts,'noise':spec['measurement_noise_standard_deviation_g']/abs(cal[2])}


def planning_inputs(folder,scale):
 import pandas as pd
 future=pd.read_csv(Path(folder)/'future_duty.csv');policy=json.loads((Path(folder)/'maintenance_policy.json').read_text())
 duties=np.unique(future[['input_rpm','force_multiplier']].to_numpy(),axis=0);scenarios={}
 for name,part in future.groupby('scenario_id',sort=False):
  rows=[]
  for row in part.sort_values('segment_id').itertuples(index=False):
   d=int(np.flatnonzero((duties[:,0]==row.input_rpm)&(duties[:,1]==row.force_multiplier))[0]);rows.append([d,row.duration_hours])
  scenarios[name]=np.asarray(rows)
 replacement=np.r_[np.asarray(policy['replacement']['backlash_halfwidth_um'])/scale,policy['replacement']['coast_stiffness_ratio']]
 plans=[{'plan_id':p['plan_id'],'time':p['at_operating_hour'],'mask':sum(1<<MEMBERS.index(member) for member in p['replace']),'cost_units':p['cost_units']} for p in policy['plans']]
 return duties,scenarios,replacement,plans


def main(folder,output):
 import pandas as pd
 start=time.monotonic();ex=read_experiment(folder,substeps=4);ex['folder']=str(folder);parameters,states,teeth,diagnostics=infer_physical_state(ex)
 C,m=fit_fatigue(folder);duties,scenarios,replacement,plans=planning_inputs(folder,ex['spec']['displacement_scale_um']);policy=json.loads((Path(folder)/'maintenance_policy.json').read_text())
 maps=independent_fields(parameters,teeth,ex['config'],duties,replacement);decision=independent_decision(states[-1],scenarios,maps,C,m,duties,ex['config'][1],plans,policy)
 result={'faults':{member:int(teeth[j]) if states[-1,j]>=ex['spec']['stiffness_loss_detection'] else None for j,member in enumerate(MEMBERS)},'contact_parameters':{'backlash_halfwidth_um':(parameters[:2]*ex['spec']['displacement_scale_um']).tolist(),'coast_stiffness_ratio':parameters[2:].tolist()},'forecast_hours':decision['forecast_hours'],'maintenance_plan':decision['maintenance_plan']}
 output=Path(output);output.mkdir(parents=True,exist_ok=True);pd.DataFrame({'observation_id':ex['observations'].observation_id,'loss_stage1':states[:,0],'loss_stage2':states[:,1]}).to_csv(output/'gearbox_condition_assessment.csv',index=False)
 (output/'summary.json').write_text(json.dumps(result,indent=2,allow_nan=False)+'\n')
 print(json.dumps({'seconds':time.monotonic()-start,'faults':result['faults'],'forecast':result['forecast_hours'],'plan':result['maintenance_plan'],'diagnostics':diagnostics}),flush=True)
 return result
if __name__=='__main__':
 import argparse
 parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('input_directory');parser.add_argument('output_directory');args=parser.parse_args();main(args.input_directory,args.output_directory)
