#!/usr/bin/env python3
"""Run both numerical implementations against independent physical-state targets."""
import os
os.environ.setdefault('OPENBLAS_NUM_THREADS','1');os.environ.setdefault('OMP_NUM_THREADS','1')
import argparse,hashlib,importlib.util,json,subprocess,sys,tempfile,time
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2]
PUBLIC=['gearbox.json','records.csv','observations.csv','vibration_windows.csv','transfer_calibration.csv','fatigue_tests.csv','future_duty.csv','maintenance_policy.json','README.txt']
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def module(name,path):
 spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m

def main():
 parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--units',default='ABCDEFG');parser.add_argument('--output',type=Path,default=Path(__file__).with_name('validation_results.json'));args=parser.parse_args()
 sys.path.insert(0,str(ROOT/'tests'));g=module('grader',ROOT/'tests/test_gearbox_condition.py');manifest=json.loads((ROOT/'authoring/provenance/generation_manifest.json').read_text())
 files={'reference':ROOT/'solution/solve_gearbox.py','independent':Path(__file__).with_name('independent_solver.py')}
 sources={str(p.relative_to(ROOT)):sha(p) for p in [*files.values(),ROOT/'tests/test_gearbox_condition.py',ROOT/'tests/physics.py',ROOT/'authoring/provenance/simulator.py',ROOT/'authoring/provenance/qualification.py',ROOT/'authoring/provenance/generate_cases.py']}
 report={'scope':'Fresh local executions, not platform or agent-probe results. Targets are independently generated physical states.','source_sha256':sources,'units':{}}
 begin=time.monotonic()
 for letter in args.units:
  name='unit_'+letter;folder=ROOT/('environment/data' if letter=='A' else 'tests/held_out')/name;e=manifest['cases'][name]['expected'];row={'input_sha256':{f:sha(folder/f) for f in PUBLIC}}
  for method,source in files.items():
   with tempfile.TemporaryDirectory() as temp:
    output=Path(temp);start=time.monotonic();p=subprocess.run([sys.executable,str(source),str(folder),str(output)],capture_output=True,text=True,timeout=300)
    result={'seconds':time.monotonic()-start,'exit_code':p.returncode,'stdout':p.stdout,'stderr':p.stderr}
    result['grade']=g.grade_files(folder,output,e) if p.returncode==0 else {'passed':False,'failures':['process failure']}
    if (output/'summary.json').exists():result['summary']=json.loads((output/'summary.json').read_text())
    if (output/'gearbox_condition_assessment.csv').exists():
     import pandas as pd
     result['window_outputs']=pd.read_csv(output/'gearbox_condition_assessment.csv').to_dict(orient='list')
    row[method]=result;print(name,method,result['grade']['passed'],round(result['seconds'],2),result['grade']['failures'],flush=True)
  report['units'][name]=row;args.output.write_text(json.dumps(report,indent=2,allow_nan=False)+'\n')
 report['sources_unchanged']=all(sha(ROOT/p)==v for p,v in sources.items());report['seconds']=time.monotonic()-begin;report['passed']=report['sources_unchanged'] and all(v[m]['grade']['passed'] for v in report['units'].values() for m in files)
 args.output.write_text(json.dumps(report,indent=2,allow_nan=False)+'\n');print('PASS',report['passed'],flush=True)
 if not report['passed']:raise SystemExit(1)
if __name__=='__main__':main()
