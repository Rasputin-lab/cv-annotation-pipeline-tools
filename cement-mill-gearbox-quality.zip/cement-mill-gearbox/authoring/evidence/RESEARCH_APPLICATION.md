# Applied research and review feedback

The three supplied trajectory exports show successful solutions of the earlier
phase-demodulation experiment. Trial 1 calibrated sensor paths and fitted a
filtered angular basis. Trial 2 used response deconvolution, speed-aware bands
and missing-sample reconstruction. Trial 3 directly fitted a nonlinear AM/PM
forward model. All three also describe their own synthetic checks. The screenshot
and exports establish rewards 1, 1, 1; the accompanying prose saying 0, 0, 0 is
inconsistent with that evidence. No completed Difficulty-probe results for this
cement task were supplied.

The exports include collapsed thinking/tool views, shortened commands and some
truncated code metadata. The analysis uses visible commands, output excerpts and
final explanations. It does not claim access to hidden reasoning or full scripts.

Their common success shows that a disclosed analytic phase-response class plus
a simple qualified trend admits reliable inversion. The new task requires a
coupled mechanical state that supports both measured responses and subsequent
decisions. Increasing file counts, reducing tolerances alone or inserting
unwritten exceptions would not supply that scientific requirement.

The two supplied saved AI discussions were treated as brainstorming, not as
scientific evidence. These applicable suggestions were implemented:

| Suggestion | Concrete use | Fairness safeguard |
| --- | --- | --- |
| Partial observation | Calibrated casing paths observe a force mixture while internal deflections are latent. | Inputs, calibration accuracy and mechanics are fully supplied; alternative solvers recover the state. |
| Coupled inference | Tooth loss, backlash and flank asymmetry affect the same dynamic response. | Different measured operating regimes and healthy commissioning constrain them. |
| Changes of physical regime | Loaded and lightly loaded speed sweeps exercise different contact branches. | The force law, initial conditions and measured forcing are explicit. |
| Causal decisions | Replacement changes both local loss and catalog contact properties. | Replacement specifications, candidate jobs and costs are public inputs. |
| Conditional planning | One job must satisfy two complete production scenarios. | Limits, time origin, envelope arithmetic and null/censoring are defined. |
| Realistic error | Small acquisition/calibration errors and missing acceleration observations. | Input forces/angles remain complete; bounds and accuracy are stated. |

Suggestions involving contradictory documentation, concealed requirements,
unreliable tools, live changes, huge irrelevant documents or resource starvation
were excluded. Claims about proprietary model capabilities, prices or unreleased
systems are not used to justify scientific difficulty. Raw browser exports and
personal sidebars are not distributed.

The idea-check concerns are addressed by the canonical input contract: exact
alpha quantities and tooth convention; contact-parameter units; separate alert
and planning limits; two production scenarios instead of an undefined confidence
interval; exact null semantics and numerical allowances; a three-column CSV and
four-key JSON; a second numerical implementation; generated physical targets;
and complete wrong-science controls. Grading concerns final results, not the
estimation algorithm or a required sequence of tool use.

The scientific sources in `../provenance/SOURCES.md` motivate nonlinear gear
stiffness/contact modelling and condition monitoring. They do not establish the
simulated fatigue coefficients or maintenance prices, which belong to the
explicit experimental qualification and policy.

Input archive SHA-256 values (for traceability only):

- Trajectories: `bd4685ae3602e1d0957f22f0fdd9fecfcadd37d7fdfd5922e0a258dcef367fdd`.
- Saved discussion: `8371936c462faededa85d9be9f1c91ff234fe406968165f8f441eeed216916e6`.
- Saved search: `78642f5308ebbc29350ee84e313c9f254d2def84573efed4c6992ba2a9f153c6`.
