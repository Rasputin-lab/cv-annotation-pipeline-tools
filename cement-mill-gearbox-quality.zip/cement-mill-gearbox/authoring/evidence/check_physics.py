#!/usr/bin/env python3
"""Physical structure, independent forward integration and healthy-case checks."""
import os
os.environ.setdefault('OPENBLAS_NUM_THREADS','1');os.environ.setdefault('OMP_NUM_THREADS','1')
import json,subprocess,sys,tempfile,time
from pathlib import Path
import numpy as np
import pandas as pd
from scipy.integrate import solve_ivp
from scipy import signal
from support import ROOT,manifest,folder_for,load,save,hashes

def main():
    ref=load('reference_physics',ROOT/'solution/solve_gearbox.py');gen=load('generator_physics',ROOT/'authoring/provenance/generate_cases.py');grader=load('grader_physics',ROOT/'tests/test_gearbox_condition.py')
    report={'scope':'Authoring physical checks; numerical convergence and local sensitivity are evidence on these controlled inputs, not a proof of global uniqueness.','cases':{}}
    for name,case in manifest().items():
        cfg=np.array(case['model_vector']);params=np.array(case['parameters']);teeth=np.array(case['tooth_indices'],dtype=np.int64);states=np.array(case['expected']['losses'])
        mass=np.array([[1,cfg[2]],[cfg[2],cfg[3]]]);eigen=np.linalg.eigvalsh(mass)
        assert min(eigen)>0 and min(cfg[4:10])>0
        # For fixed input angle the contact force is the derivative of a
        # nonnegative potential: half*k*((1-alpha W)*drive^2+eta*coast^2).
        deadband=[]
        for sign in [-.5,0.,.5]:
            out=ref.rhs(sign*params[0],sign*params[1],0.,0.,0.,0.,0.,.45,.45,*teeth,*params,*cfg[:11])
            deadband.extend(out[4:6])
        assert np.max(abs(np.array(deadband)))==0.
        z1,r=cfg[:2];z3=round(z1/r);assert abs(z3*r-z1)<1e-12
        assert ref.pulse(0.,np.pi*1.55/z1)==1. and ref.pulse(np.pi*1.55/z1,np.pi*1.55/z1)<1e-25
        assert abs(ref.pulse(.02,np.pi*1.55/z1)-ref.pulse(.02+2*np.pi,np.pi*1.55/z1))<1e-12
        assert case['future_force_moment_max']<5.
        ex=ref.read_experiment(folder_for(name));selected=np.flatnonzero(ex['groups']==6);theta=ex['theta'][selected];drive=ex['drive'][selected];levels=np.repeat(states[-1][None,:],len(selected),axis=0)
        def prediction(p,a):
            out,_=ref.simulation(theta,drive,a,p,teeth,cfg,ex['dt'],2)
            return signal.lfilter(ex['b'],ex['a'],np.c_[np.zeros(len(out)),out],axis=1)[:,100:]
        baseline=prediction(params,levels);columns=[]
        # Unit perturbations are the declared grading allowances.
        scales=np.array([3/500,3/500,.018,.018,.008,.008]);allparams=np.r_[params,states[-1]]
        for j,scale in enumerate(scales):
            plus=allparams.copy();minus=allparams.copy();plus[j]+=scale*.01;minus[j]-=scale*.01
            p=prediction(plus[:4],np.repeat(plus[4:][None,:],len(selected),axis=0));m=prediction(minus[:4],np.repeat(minus[4:][None,:],len(selected),axis=0))
            columns.append(((p-m)/.02).ravel())
        J=np.array(columns).T;singular=np.linalg.svd(J,compute_uv=False)/np.sqrt(len(J));rank=int(np.linalg.matrix_rank(J))
        assert rank==6
        gains=np.array(case['sensor_gain']);spatial=np.outer(gains,[1.,cfg[-1]]);assert np.linalg.matrix_rank(spatial)==1
        forces=[]
        raw=pd.read_csv(folder_for(name)/'vibration_windows.csv');chosen=raw[raw.record_id==int(ex['records'].iloc[selected[-1]].record_id)]
        nodes=chosen.input_angle_rad.to_numpy()[None,:];u=chosen[['force1_N','force2_N']].to_numpy()[None,:,:]/100000.
        for steps in [2,4,8]:
            th,uu=gen.array_inputs(nodes,u,steps);out,_=ref.simulation(th,uu,levels[:1],params,teeth,cfg,gen.OMEGA/(gen.FS*steps),steps);forces.append(out[0])
        convergence={'rk4_2_vs_8_rms_g':float(np.sqrt(np.mean((forces[0]-forces[2])**2))*max(abs(gains))),'rk4_4_vs_8_rms_g':float(np.sqrt(np.mean((forces[1]-forces[2])**2))*max(abs(gains)))}
        # The comparison is force-scaled g before accelerance; sharp contact
        # transitions are allowed, and inverse fits have separate target tests.
        convergence['measurement_noise_standard_deviation_g']=.00016
        assert convergence['rk4_4_vs_8_rms_g']<convergence['rk4_2_vs_8_rms_g']
        assert convergence['rk4_2_vs_8_rms_g']<2*.00016
        intensities=[]
        for resolution in [48,72,96]:intensities.append(ref.intensity(states[-1],params,teeth,cfg,950.,.35,resolution))
        settle5=ref.intensity(states[-1],params,teeth,cfg,950.,.35,96,5,3)
        intensity_check={'48':intensities[0].tolist(),'72':intensities[1].tolist(),'96':intensities[2].tolist(),'relative_48_vs_96':float(np.max(abs(intensities[0]-intensities[2])/intensities[2])),'settle3_vs5_abs':float(np.max(abs(settle5-intensities[2])))}
        assert intensity_check['relative_48_vs_96']<.012
        report['cases'][name]={'mass_eigenvalues':eigen.tolist(),'contact_potential_nonnegative':True,'backlash_deadband_zero':True,'mesh_fundamentals_coincide':True,'spatial_calibration_rank':1,'local_sensitivity_rank':rank,'allowance_scaled_singular_rms':singular.tolist(),'noise_rms_in_same_normalized_channel':ex['noise'],'force_qualification_max':case['future_force_moment_max'],'integration':convergence,'future_intensity':intensity_check}
        # One independently implemented adaptive forward calculation. It uses
        # the original piecewise-linear recorded inputs, not solver RHS code.
        if name=='unit_B':
            times=chosen.time_s.to_numpy();angles=nodes[0];force=u[0];inv=np.linalg.inv(mass);a1,a2=states[-1];b1,b2,eta1,eta2=params
            def contact(q,th):
                pin=np.array([th,r*th]);Z=np.array([z1,z3]);delta=(pin-2*np.pi*teeth/Z+np.pi)%(2*np.pi)-np.pi;width=np.pi*1.55/Z
                window=np.where(abs(delta)<width,np.cos(np.pi*delta/(2*width))**2,0.)
                stiffness=np.array([cfg[4]*(1+.18*np.cos(z1*th)+.035*np.cos(2*z1*th)),cfg[5]*(1+.16*np.cos(z1*th+cfg[10])+.045*np.cos(2*z1*th+2*cfg[10]))])
                return stiffness*((1-np.array([a1,a2])*window)*np.maximum(q-np.array([b1,b2]),0)+np.array([eta1,eta2])*np.minimum(q+np.array([b1,b2]),0))
            def derivative(tau,y):
                t=tau/gen.OMEGA;th=np.interp(t,times,angles);f=np.array([np.interp(t,times,force[:,j]) for j in range(2)])
                acceleration=inv@(f-cfg[6:8]*y[2:]-cfg[8:10]*y[:2]-contact(y[:2],th))
                return np.r_[y[2:],acceleration]
            begin=time.monotonic();sol=solve_ivp(derivative,[0.,times[-1]*gen.OMEGA],np.zeros(4),method='DOP853',t_eval=times*gen.OMEGA,rtol=2e-8,atol=2e-10,max_step=.35)
            assert sol.success
            force_adaptive=np.array([contact(sol.y[:2,i],angles[i])@[1.,cfg[-1]] for i in range(len(times))])[1:]
            error=float(np.sqrt(np.mean((force_adaptive-forces[-1])**2))*max(abs(gains)))
            assert error<.00002
            report['independent_adaptive_forward']={'unit':'unit_B','method':'independently coded force law + scipy DOP853','seconds':time.monotonic()-begin,'rms_difference_g_force_scaled':error,'passed':True}
        print('physical checks',name,'PASS',flush=True)
    # This extra healthy experiment is not included in the scored suite. Its
    # private truth is removed before either full solver is launched.
    with tempfile.TemporaryDirectory() as tmp:
        root=Path(tmp);case=gen.generate(root,'H',2026102409,(0,0),False);folder=root/'tests/held_out/unit_H';(folder/'truth.json').unlink();(folder/'README.txt').write_bytes((ROOT/'authoring/provenance/DATA_README.md').read_bytes())
        checks={}
        for label,source in [('reference',ROOT/'solution/solve_gearbox.py'),('independent',Path(__file__).with_name('independent_solver.py'))]:
            out=root/label;begin=time.monotonic();p=subprocess.run([sys.executable,str(source),str(folder),str(out)],capture_output=True,text=True,timeout=300)
            assert p.returncode==0,(label,p.stderr)
            result=grader.grade_files(folder,out,case['expected']);checks[label]={'seconds':time.monotonic()-begin,'grade':result,'stdout':p.stdout};assert result['passed'],checks[label]
        report['healthy_control']={'seed':2026102409,'truth_removed_from_input':True,'not_a_graded_unit':True,'methods':checks}
    report['source_sha256']=hashes([ROOT/'solution/solve_gearbox.py',Path(__file__).with_name('independent_solver.py'),ROOT/'authoring/provenance/simulator.py',ROOT/'authoring/provenance/generate_cases.py',Path(__file__)])
    report['passed']=True;save(Path(__file__).with_name('physical_checks.json'),report);print('physical checks PASS',flush=True)
if __name__=='__main__':main()
