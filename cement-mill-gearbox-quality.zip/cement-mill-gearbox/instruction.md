Develop a reusable assessment for the synthetic cement-mill gearbox experiment in
`/root/data/unit_A`. Read `/root/data/unit_A/README.txt` for the mechanical model,
measurement units, output schemas, forecast conditioning and numerical allowances.

Locate the disturbed pinion teeth and estimate their stiffness losses at each
operating observation, together with the unknown contact properties. Forecast
the first diagnostic alert under each supplied production scenario. Select the
lowest-cost maintenance job that respects the planning ceiling in every scenario,
accounting for the replacement properties and their effect on the coupled gearbox.

Submit `/logs/artifacts/solve_gearbox.py`. It must run as:

```text
python /logs/artifacts/solve_gearbox.py INPUT_DIRECTORY OUTPUT_DIRECTORY
```

Create the output directory and write `gearbox_condition_assessment.csv` and
`summary.json` using exactly the data README schemas. The script will run offline,
unchanged, on six unseen complete directories with the same schema. Use each
directory's own inputs. Finish within 300 seconds per experiment. Python, NumPy,
SciPy, pandas and Numba are installed. Include any additional implementation in
the submitted script.

You have 14400 seconds to complete this task. Do not cheat by using online solutions or hints specific to this task.
