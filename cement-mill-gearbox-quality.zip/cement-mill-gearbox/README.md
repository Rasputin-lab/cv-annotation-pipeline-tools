# Cement Mill Gearbox

Task name: `cement-mill-gearbox`.

## Difficulty

Machinery diagnostic specialists and reliability engineers use forced-response
measurements to identify gear contact damage and decide which components need
maintenance before production continues. This task combines that inverse
mechanical assessment with a conditional maintenance decision.

The measurements observe calibrated mixtures of internal mesh reactions, while
the internal deflections are unobserved. The two meshes share a carrier order.
Local tooth losses, backlash and unequal drive/coast stiffness affect the same
response. Low-speed loaded commissioning and high-speed light-load observations
provide different information because the contact branch changes. One or both
pinions may be disturbed, with tooth events that can coincide in time. Identifying
a single spectral amplitude or attributing every change to a single defect does
not resolve the coupled mechanical state.

The maintenance calculation depends on that diagnosis. Root loading depends on
both pinion states and operating duty. Replacing one pinion changes its loss,
clearance and flank properties, which can change the remaining pinion's loading.
A job must remain admissible under each supplied production scenario and must
meet a cost objective. The hard work for humans is selecting and checking a
consistent mechanical interpretation across these steps. For agents, locally
plausible simplifications can fit part of the experiment while making an incorrect
counterfactual prediction. The difficulty comes from this physical coupling and
partial observation, with complete specifications and a stable offline runtime.

## Scope and scored quantities

All records are simulated, including sensor calibration and fatigue qualification.
The reduced two-coordinate contact dynamics follow conventional time-varying gear
stiffness and backlash modelling. The exact fatigue correlation is qualified by
the supplied simulated test data. No universal gear fatigue law, measured plant
history, crack depth or unconditional failure life is claimed. The alert and
planning limits are stated maintenance-policy choices.

The output is a three-column CSV of the two fractional stiffness losses at each
observation, plus a four-key JSON summary: pinion tooth indices, physical contact
parameters, conditional diagnostic times and the selected maintenance job with
its worst-case peak loss. Tooth-index, force-sign and angle conventions, null
semantics, units, thresholds and numerical allowances are fixed in every input
README. The scenario envelope is explicitly distinguished from a statistical
confidence interval. See [scientific sources](authoring/provenance/SOURCES.md).

## Reference solution

`solution/solve_gearbox.py` calibrates the acquisition response and fits the
partially observed mechanical response. It profiles local tooth candidates,
recovers shared contact parameters and per-observation losses, infers fatigue
qualification coefficients, evaluates coupled future loading and compares the
candidate maintenance jobs. It uses a fourth-order mechanical integrator and
exposure integration over the future production segments.

The second numerical implementation, `authoring/evidence/independent_solver.py`,
uses separately coded contact evaluation and a third-order integrator, rational
response calibration, all three acceleration axes, nonlinear coordinate profiling,
robust qualification fitting and adaptive integration of future loss. Standard
file/schema parsing is shared text; it imports neither the reference nor the
generator at runtime. Its numerical core and inference/forecast implementations
provide the alternative-method check.

## Verification

The verifier runs the submitted script unprivileged on six unseen complete input
directories. All six must pass for binary reward 1. Every graded experiment has
a measurable local disturbance; separate healthy cases are authoring controls.
Targets are the simulator's independently generated physical states and
higher-resolution future calculations, not the reference's inferred answers.

It checks the zero-based pinion tooth indices, both loss trajectories, backlash
half-widths, coast/drive ratios, conditional alert times and their scenario
envelope, and the selected job's actual safety, cost and peak loss. It also
checks exact schemas, finite numbers, observation order and null semantics.
Different estimation and integration methods are accepted.

### Numerical allowances and their purpose

All error comparisons below are absolute. These are numerical error budgets for
this controlled synthetic experiment, not confidence intervals, manufacturing
tolerances or claims about accuracy on plant measurements. They allow noisy
inverse estimates and independently discretized mechanics to agree on the
assessed physical state and decision. They are deliberately wider than the
observed correct-method errors; they do not relax fault identification, censoring
or the true safety/cost decision.

| Quantity | Existing acceptance bound | What the allowance brackets |
| --- | --- | --- |
| Each observation's stiffness loss | 0.008 loss fraction | 0.8 percentage points for state-estimation error from acquisition/calibration noise and finite mechanical integration. This remains below the 0.03 current-loss detection scale; it cannot turn the measured positive losses into a healthy null. |
| Each backlash half-width | 3 micrometres | Clearance-estimation shifts between calibrated inverse fits and their contact discretizations. At the 500-micrometre displacement scale this is 0.006 normalized deflection, only 2% of the supplied 150-micrometre search span. |
| Each coast/drive stiffness ratio | 0.018 | Estimation and contact-switching integration error in a dimensionless flank property. It permits small numerical differences, rather than replacing an asymmetric contact branch with a materially different one. |
| Selected job's worst-case peak loss | 0.012 loss fraction | 1.2 percentage points for propagation of current-state/contact errors, fatigue qualification fitting, root-load interpolation and future integration. This budget is wider than the observation-loss budget because it concerns an evolved counterfactual trajectory. |
| Each finite diagnostic time and target envelope endpoint | 0.12 + 0.04*t_target hours | The 0.12-hour floor (7.2 minutes) allows absolute event-location/discretization error, including short forecasts; the 4% term allows accumulated propagation of inferred state, contact and fatigue-fit errors on longer forecasts. Here t_target is the corresponding independently generated crossing or endpoint, not the submitted time. |
| Finite forecast recomputed from the reported state | 0.08 + 0.03*t_check hours | A separate consistency budget for coarse private load-field interpolation, mechanical/growth integration and independent qualification fitting. Its 0.08-hour floor (4.8 minutes) and 3% term allow numerical disagreement while requiring the forecast to describe the submitted physical state. Here t_check is the recomputed time. |

The measurement standard deviation is 0.00016 g and the stated calibration
relative standard deviation is 0.0005. In the recorded physical checks, changing
mechanical integration from two to eight substeps changes the force trace by at
most 0.000139 g RMS after force-to-g scaling, before acquisition filtering.
Changing future-load integration from 48 to 96 steps per tooth changes the
checked intensities by at most 0.080% relative. These checks identify real sources
of numerical discrepancy; the complete inverse/forecast runs below measure
their combined effect. They do not imply a statistical coverage guarantee.

### Measured margins for correct methods

The following maxima are derived from all seven experiments, visible A and
held-out B-G, in `authoring/evidence/validation_results.json`, using generating
targets in `authoring/provenance/generation_manifest.json`. Both methods pass all
seven experiments (14/14 actual executions). Loss/contact errors are recorded
under each method's `grade.metrics`; peak and time errors compare its `summary`
with the corresponding physical targets. Consistency errors compare the summary
with `grade.metrics.reported_state_physics_forecast`.

Error values are rounded upward. The last column is the smallest unused fraction
of the applicable allowance over both methods and all comparisons, conservatively
rounded down. For time-dependent bounds, each individual error is divided by its
own allowance before taking that worst fraction; the largest absolute time
error need not be the comparison with the smallest relative margin.

| Checked quantity | Largest reference error | Largest independent-method error | Minimum unused allowance |
| --- | ---: | ---: | ---: |
| Loss fraction | 0.0021132 | 0.0016893 | 73.58% |
| Backlash half-width (micrometres) | 0.037220 | 0.101860 | 96.60% |
| Coast/drive ratio | 0.00024393 | 0.00014543 | 98.64% |
| Peak loss fraction | 0.00038464 | 0.00037749 | 96.79% |
| Target crossing/envelope time (hours) | 0.012132 | 0.018178 | 94.62% |
| Reported-state forecast difference (hours) | 0.00039232 | 0.00623520 | 96.00% |

Thus even the tightest observed margin, the reference loss fit in unit_E, leaves
at least 73.58% of its allowance unused (0.0058868 loss fraction). The independently
coded method has its own measured margins rather than being assumed equivalent
to the reference. The larger parameter/time margins are intentional numerical
guard bands, not free passes for different physics: the complete symmetric-coast
ablation in `authoring/evidence/scientific_controls.json` has unit_B errors of
about 0.09856 loss, 54.95 micrometres backlash and 0.29180 coast ratio, exceeding
the respective unchanged bounds. Every documented wrong-science control fails
the full suite. These are local authoring results, not model-probe solve rates.

### Reported-state forecast consistency and exact decision checks

After the other output checks pass, `tests/physics.py` independently recomputes
the no-repair scenario forecasts using the submitted current losses, tooth
indices and contact parameters, and fatigue coefficients fitted from that
input's qualification data. It imports no submitted or reference solver code.
The call uses `build_fields(spacing=0.06, resolution=48)` and a growth step no
larger than 0.025 operating hours. The nominal 0.06 grid request is rounded to
eight intervals over 0-0.45: nine nodes with actual spacing 0.05625. This is
coarser than the reference's 0.045 grid and the generating target's 0.025 grid.
The submitted finite time must agree within `0.08 + 0.03*t_check` hours. This
additional check prevents a forecast inconsistent with its own reported state
from passing just because separate fields happen to be near target values.

Null versus finite crossings must agree exactly with both target and consistency
semantics. Each `earliest`/`latest` endpoint must first match the min/max/censoring
operation on the submitted scenario times within 1e-6 hours; this is an arithmetic
rounding check, not an additional integration allowance. Tooth indices must match
the stated phase/sign convention exactly. A selected job must remain strictly
below the 0.36 planning ceiling in every supplied scenario and be cost-minimal
among the truly admissible candidates within 1e-6 cost_units. The peak-loss
allowance cannot make an unsafe or needlessly expensive job acceptable.

### Executed container isolation

`authoring/evidence/container_validation.json` records `passed: true` for eight
fresh offline Docker trials: reference rewards 1,1,1; no-change rewards 0,0,0;
independent-solver reward 1; private-answer/reward-tampering control reward 0.
The correct solvers exit successfully and pass all six graded inputs. The file
records image identifiers, unchanged source hashes and actual run results.

Each trial used `--network=none`, 2 CPUs and 8192 MB. Submitted code during
held-out evaluation and the isolation probes ran as UID 65534;
all six private-truth reads and the protected reward-directory write returned
PermissionError. `tests/test.sh` initializes a literal-zero reward, makes a
private readable copy of the single solver artifact, removes truth files from
input copies, applies the 300-second per-case limit and collects outputs using
that same unprivileged identity. The private tests, original expected states
and reward directory stay inaccessible. These executed local checks are distinct
from platform Quality, Easiness, Difficulty and Run Audit results, which require
a fresh platform submission.

## Reproduction and evidence

`authoring/provenance/generate_cases.py` generates the visible and unseen
experiments and independent physical targets. `simulator.py` contains its forward
mechanics; `qualification.py` computes its future targets. The generation manifest
records parameters, seeds, qualification bounds and expected decisions.

Fresh numerical validation, semantic regression checks, physical convergence
checks, complete wrong-science controls and the isolated runtime status are recorded
under `authoring/evidence/`; see its `AUDIT.md`. These are local authoring checks.
The revised task still requires its own platform reviews and model probes.

From the task root with the Dockerfile dependency versions:

```sh
python authoring/provenance/generate_cases.py
python authoring/evidence/run_evidence.py
python authoring/evidence/check_semantics.py
python authoring/evidence/check_physics.py
python authoring/evidence/scientific_controls.py
python authoring/evidence/validate_containers.py /tmp/gearbox-runtime --build
```

Build the agent with `environment/` as context and the verifier with `tests/` as
context. Only visible inputs enter the agent image. File purposes, source hashes
and input provenance are recorded in `authoring/provenance/PROVENANCE.md` and its
checksum inventory. The submitted artifact remains one reusable Python script.
