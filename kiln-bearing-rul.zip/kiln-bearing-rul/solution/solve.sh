#!/bin/bash
set -euo pipefail
# Oracle entry point: places the reference solver at the path the verifier
# expects (matches task.toml `artifacts`), then self-checks it runs on the
# one agent-visible instance.
mkdir -p /logs/artifacts
cp /solution/solve_bearing.py /logs/artifacts/solve_bearing.py
chmod 644 /logs/artifacts/solve_bearing.py
python3 /logs/artifacts/solve_bearing.py /root/data/unit_A >/dev/null
echo "oracle solver staged at /logs/artifacts/solve_bearing.py"
