#!/usr/bin/env python3
"""Conditional inspection/operation assessment with joint physical explanations."""
import os
os.environ.setdefault('OPENBLAS_NUM_THREADS','1')
os.environ.setdefault('OMP_NUM_THREADS','1')
import csv,json,math,sys,time
from pathlib import Path
import numpy as np
from numba import njit
from scipy.optimize import minimize
from scipy.stats import qmc

GX,GW=np.polynomial.legendre.leggauss(20)

@njit
def baseline_time(a,b,B,m):
    u=1.-m/2.
    return (b**u-a**u)/(u*B)

@njit
def time_between(a,b,Z,kappa,B,m,p):
    if b<=a:return 0.
    cut=min(b,Z/(1+kappa))
    if cut<=a or p==0.:return baseline_time(a,b,B,m)
    total=0.;mid=(a+cut)/2;half=(cut-a)/2
    for j in range(len(GX)):
        x=mid+half*GX[j]
        total+=GW[j]*x**(-m/2)*((Z-x)/(kappa*x))**p
    total*=half/B
    if cut<b:total+=baseline_time(cut,b,B,m)
    return total

@njit
def advance(a,Z,dt,B,m,p,kappa,cap):
    if dt<=0:return a,Z
    Z=max(Z,a*(1+kappa))
    if p==0 or a>=Z/(1+kappa):
        u=1-m/2;v=a**u+u*B*dt
        result=cap if v<=0 else min(cap,v**(1/u))
        return result,max(Z,result*(1+kappa))
    exit_a=Z/(1+kappa);t_exit=time_between(a,exit_a,Z,kappa,B,m,p)
    if dt>=t_exit:
        u=1-m/2;v=exit_a**u+u*B*(dt-t_exit)
        result=cap if v<=0 else min(cap,v**(1/u))
    else:
        lo=a;hi=min(exit_a,cap)
        # Bracketed Newton inversion of the positive crack-advance integral.
        x=a+(hi-a)*min(.99,dt/max(t_exit,1e-300))
        for j in range(18):
            value=time_between(a,x,Z,kappa,B,m,p)-dt
            if abs(value)<1e-10*(1+dt):break
            if value>0:hi=x
            else:lo=x
            derivative=x**(-m/2)*((Z-x)/(kappa*x))**p/B
            trial=x-value/derivative
            x=trial if lo<trial<hi else (lo+hi)/2
        result=min(cap,x)
    return result,max(Z,result*(1+kappa))

@njit
def coefficients(params,row,constants):
    # params: initial crack mm, log(v_ref [m/cycle]), m, gamma, residual MPa, shape, NDE bias mm.
    a,lv,m,g,r,p,bias=params
    Y,kref,yield_stress,alpha,cycles_per_kiln_rpm,serviceK,maxa=constants
    peak=row[3]+r;delta=row[3]-row[2]
    equivalent=delta**g*peak**(1-g)
    B=cycles_per_kiln_rpm*row[1]*math.exp(lv)*1000*(Y*math.sqrt(math.pi*.001)*equivalent/kref)**m
    kappa=Y**2*peak**2/(alpha*yield_stress**2)
    critical=min(maxa,1000/math.pi*(serviceK/(Y*peak))**2)
    return B,kappa,critical

@njit
def historical(params,rows,constants,kind):
    a=params[0];Z=a;pred=np.empty(len(rows));p=params[5] if kind else 0.
    for i in range(len(rows)):
        B,kappa,_=coefficients(params,rows[i],constants)
        a,Z=advance(a,Z,rows[i,0],B,params[2],p,kappa,8.)
        pred[i]=a+params[6]
    return pred,a,Z

def load_unit(path):
    p=Path(path);s=json.loads((p/'bearing_spec.json').read_text())
    def read(name):
        with (p/name).open() as f:return list(csv.DictReader(f))
    hist=read('history.csv');coupon=read('coupon_growth.csv');cal=read('depth_calibration.csv');plans={}
    for row in read('future_duty.csv'):plans.setdefault(row['plan_id'],[]).append(row)
    for rows in plans.values():rows.sort(key=lambda r:int(r['block_index']))
    return s,hist,coupon,cal,plans


class Model:
    def __init__(self,path,kind):
        self.s,h,c,cal,plans=load_unit(path);self.kind=kind;s=self.s
        self.labels=sorted(plans);self.plans=plans
        cols=['duration_hours','kiln_rpm','stress_min_mpa','stress_max_mpa']
        self.h=np.array([[float(r[k]) for k in cols] for r in h]);self.lo=np.array([float(r['reading_lower_mm']) for r in h]);self.hi=np.array([float(r['reading_upper_mm']) for r in h])
        self.c=np.array([[float(r[k]) for k in ['delta_k_mpa_sqrt_m','stress_ratio','rate_lower_m_per_cycle','rate_upper_m_per_cycle']] for r in c])
        self.cal=np.array([[float(r[k]) for k in ['certified_depth_mm','reading_lower_mm','reading_upper_mm']] for r in cal])
        self.f={k:np.array([[float(r[x]) for x in cols] for r in v]) for k,v in plans.items()}
        g=s['bearing_geometry'];mat=s['material'];geo=s['crack_geometry']
        frequency=60*g['kiln_tyre_diameter_m']/g['support_roller_diameter_m']*g['rolling_elements']/2*(1-g['element_diameter_mm']/g['pitch_diameter_mm']*math.cos(math.radians(g['contact_angle_deg'])))
        self.constants=np.array([geo['mode_I_factor'],mat['reference_delta_k_mpa_sqrt_m'],mat['yield_strength_mpa'],mat['plastic_zone_denominator'],frequency,mat['service_k_mpa_sqrt_m'],geo['maximum_assessed_crack_mm']])
        keys=['initial_crack_mm','reference_growth_m_per_cycle','paris_exponent','walker_gamma','residual_stress_mpa','wheeler_exponent','depth_bias_mm']
        bounds=np.array([s['bounds'][k] for k in keys],float);bounds[1]=np.log(bounds[1])
        self.lower=bounds[:,0];self.span=bounds[:,1]-bounds[:,0];self.bounds=[(0.,1.)]*7
        if not kind:self.bounds[5]=(.5,.5)
        self.cache={};self.starts=[];self.action_cache={};self.margin_cache={}
        self.actions={}
        self.H=float(s["shutdown_hours"])
        for a in json.loads((Path(path)/"inspection_options.json").read_text())["actions"]:
            item=dict(a);item["rows"]=np.array([[float(r[k]) for k in cols] for r in a["blocks"]],float).reshape((-1,4))
            item["elapsed"]=sum(float(r["duration_hours"]) for r in a["blocks"])+float(a["downtime_hours"])
            item["tonnes"]=sum(float(r["duration_hours"])*float(r["production_tonnes_per_hour"]) for r in a["blocks"])
            self.actions[a["action_id"]]=item
    def theta(self,x):return self.lower+self.span*x
    def history(self,x):
        key=tuple(x)
        if key not in self.cache:
            if len(self.cache)>100:self.cache.clear()
            self.cache[key]=historical(self.theta(x),self.h,self.constants,self.kind)
        return self.cache[key]
    def constraints(self,x):
        t=self.theta(x);pred,_,_=self.history(x);c=self.c
        logs=t[1]+t[2]*(np.log(c[:,0]/self.constants[1])-(1-t[3])*np.log1p(-c[:,1]))
        calibration=self.cal[:,0]+t[6]
        limits=np.minimum(self.constants[6],1000/np.pi*(self.constants[5]/(self.constants[0]*(self.h[:,3]+t[4])))**2)
        limits=np.where(self.h[:,0]>0,limits,self.constants[6])
        return np.r_[(pred-self.lo)/.01,(self.hi-pred)/.01,logs-np.log(c[:,2]),np.log(c[:,3])-logs,(calibration-self.cal[:,1])/.01,(self.cal[:,2]-calibration)/.01,(limits-pred+t[6])/.01]
    def fit(self,n=12):
        c=self.c
        A=np.column_stack([np.ones(len(c)),np.log(c[:,0]/self.constants[1]),-np.log1p(-c[:,1])])
        fitted=np.linalg.lstsq(A,(np.log(c[:,2])+np.log(c[:,3]))/2,rcond=None)[0]
        gamma=1-fitted[2]/max(fitted[1],1.)
        bias=np.mean((self.cal[:,1]+self.cal[:,2])/2-self.cal[:,0])
        theta=(self.lower+self.lower+self.span)/2
        theta[:4]=[float((self.lo[0]+self.hi[0])/2-bias),fitted[0],fitted[1],gamma];theta[6]=bias
        center=np.clip((theta-self.lower)/self.span,.001,.999)
        starts=[center]
        for point in qmc.Halton(3,scramble=False).random(n+1)[1:]:
            x=center.copy();x[4]=point[0];x[5]=point[1];x[6]=np.clip(center[6]+(point[2]-.5)*.2,0,1);starts.append(x)
        results=[];best=1e100
        for x in starts:
            if not self.kind:x[5]=.5
            result=minimize(lambda z:np.sum(np.minimum(self.constraints(z),0.)**2),x,bounds=self.bounds,method='SLSQP',options={'maxiter':200,'ftol':1e-15})
            bad=max(0.,-float(np.min(self.constraints(result.x))));best=min(best,bad)
            if bad<3e-7:results.append(result.x)
        self.starts=results
        return results,best

    def prefix(self,x,aid):
        key=(aid,tuple(x))
        if key not in self.action_cache:
            if len(self.action_cache)>600:self.action_cache.clear()
            _,a,Z=self.history(x)
            self.action_cache[key]=run_prefix(self.theta(x),self.actions[aid]['rows'],self.constants,self.kind,a,Z)
        return self.action_cache[key]
    def clearance(self,x,aid,plan):
        key=(aid,plan,tuple(x))
        if key not in self.margin_cache:
            if len(self.margin_cache)>1200:self.margin_cache.clear()
            a,Z,margin=self.prefix(x,aid)
            if plan!='STOP':
                margin=min(margin,run_horizon(self.theta(x),self.f[plan],self.constants,self.kind,a,Z,self.H-self.actions[aid]['elapsed']))
            self.margin_cache[key]=float(margin)
        return self.margin_cache[key]
    def observation(self,x,aid):
        a,_,_=self.prefix(x,aid)
        return a+(self.theta(x)[6] if self.actions[aid]['measurement']['bias_mode']=='shared' else 0.)


@njit
def run_prefix(theta,rows,constants,kind,a,Z):
    margin=constants[6]-a;p=theta[5] if kind else 0.
    for row in rows:
        if row[0]<=0:continue
        B,k,limit=coefficients(theta,row,constants)
        margin=min(margin,limit-a)
        a,Z=advance(a,Z,row[0],B,theta[2],p,k,8.)
        margin=min(margin,limit-a)
    return a,Z,margin


@njit
def run_horizon(theta,rows,constants,kind,a,Z,horizon):
    margin=constants[6]-a;elapsed=0.;p=theta[5] if kind else 0.
    while elapsed<horizon:
        for row in rows:
            if row[0]<=0:continue
            duration=min(row[0],horizon-elapsed)
            if duration<=0:return margin
            B,k,limit=coefficients(theta,row,constants)
            margin=min(margin,limit-a)
            a,Z=advance(a,Z,duration,B,theta[2],p,k,8.)
            margin=min(margin,limit-a);elapsed+=duration
    return margin


def spread(points,count=10):
    result=[]
    for p in points:
        if not any(np.linalg.norm(p-q)<1e-6 for q in result):result.append(np.array(p))
    if len(result)<=count:return result
    chosen=[result[0]]
    while len(chosen)<count:
        chosen.append(max(result,key=lambda x:min(np.linalg.norm(x-z) for z in chosen)))
    return chosen


class Domain:
    def __init__(self,model,aid=None,record=None):
        self.model=model;self.aid=aid;self.record=record;self.points=[];self.best_violation=1e99;self.saved={}
        for p in model.starts:
            v=max(0.,-float(min(self.constraints(p))));self.best_violation=min(v,self.best_violation)
            if v<=3e-7:self.points.append(p.copy())
        if record is not None:
            for start in spread(model.starts,8):
                result=minimize(lambda x:float(np.sum(np.minimum(self.constraints(x),0.)**2)),start,method='SLSQP',bounds=model.bounds,options={'maxiter':200,'ftol':1e-15})
                violation=max(0.,-float(min(self.constraints(result.x))));self.best_violation=min(self.best_violation,violation)
                if violation<=3e-7:self.points.append(result.x.copy())
            if not self.points:
                # Confirm an apparently empty intersection with a Phase-I
                # common-slack problem; squared penalties flatten near zero.
                for start in spread(model.starts,8):
                    slack=max(0.,-float(min(self.constraints(start))))
                    opt=minimize(lambda y:y[-1],np.r_[start,slack+1e-8],
                        method='SLSQP',bounds=model.bounds+[(0.,None)],
                        constraints={'type':'ineq','fun':lambda y:self.constraints(y[:-1])+y[-1]},
                        options={'maxiter':220,'ftol':1e-12,'eps':7e-7})
                    candidate=opt.x[:-1];violation=max(0.,-float(min(self.constraints(candidate))))
                    self.best_violation=min(self.best_violation,violation)
                    if violation<=3e-7:self.points.append(candidate.copy())
        self.points=spread(self.points,12)
    def constraints(self,x):
        prior=self.model.constraints(x)
        if self.record is None:return prior
        value=self.model.observation(x,self.aid);e=float(self.model.actions[self.aid]['measurement']['absolute_error_mm'])
        return np.r_[prior,(value+e-self.record['lower_mm'])/.01,(self.record['upper_mm']-value+e)/.01]
    def witness(self,x,margin=None):
        return {'parameters':self.model.theta(x).tolist(),'normalized':np.asarray(x).tolist(),'constraint_violation':max(0.,-float(min(self.constraints(x)))),'clearance_mm':margin}
    def optimize(self,aid,plan,maximize=False,full=False):
        key=(aid,plan,maximize,full)
        if key in self.saved:return self.saved[key]
        if not self.points:raise ValueError('Empty conditional domain')
        sign=-1. if maximize else 1.;fun=lambda x:self.model.clearance(x,aid,plan)
        best=min(self.points,key=lambda x:sign*fun(x)).copy();best_value=fun(best);searched=0
        # A negative feasible point disproves universal safety; a positive one
        # proves existential safety. Otherwise search the full conditional set.
        decisive=lambda v:v>5e-7 if maximize else v<-5e-7
        if full or not decisive(best_value):
            starts=spread([best]+self.points,8)
            for start in starts:
                opt=minimize(lambda x:sign*fun(x),start,method='SLSQP',bounds=self.model.bounds,constraints={'type':'ineq','fun':self.constraints},options={'maxiter':180,'ftol':1e-12,'eps':7e-7})
                searched+=1
                if min(self.constraints(opt.x))>=-3e-7:
                    v=fun(opt.x)
                    if sign*v<sign*best_value:best=opt.x.copy();best_value=v
                    self.points=spread([best]+self.points+[opt.x.copy()],16)
                if not full and decisive(best_value):break
        answer=(float(best_value),{'witness':self.witness(best,float(best_value)),'search_starts':searched,'maximize':maximize,'action':aid,'plan':plan})
        # Cache only existential safety witnesses or counterexamples to
        # universal safety. Search-based absence claims must be revisited
        # after later queries enrich the joint feasible witness pool.
        if decisive(best_value):self.saved[key]=answer
        return answer


def production(model,aid,plan):
    action=model.actions[aid];value=action['tonnes']
    if plan=='STOP':return value
    remaining=model.H-action['elapsed'];rows=model.plans[plan];period=sum(float(r['duration_hours']) for r in rows)
    n=int(remaining//period);left=remaining-n*period
    value+=n*sum(float(r['duration_hours'])*float(r['production_tonnes_per_hour']) for r in rows)
    for row in rows:
        duration=min(left,float(row['duration_hours']));value+=duration*float(row['production_tonnes_per_hour']);left-=duration
        if left<=0:break
    return float(value)


def solve_with_diagnostics(path,starts=12,full_truth=True):
    begin=time.monotonic();models={};diagnostics={'models':{},'actions':{}};ambiguities=[]
    for kind,name in [(0,'walker'),(1,'wheeler')]:
        model=Model(path,kind);points,bad=model.fit(starts)
        diagnostics['models'][name]={'feasible_starts':len(points),'smallest_constraint_violation':bad}
        if points:models[name]=model
    if not models:
        out={'supported_models':[],'assessments':{},'recommended_action':'UNSUPPORTED'}
        diagnostics['truth']={'supported_models':[],'actions':{},'optimal_regret_tonnes':None,'acceptable_actions':[]};diagnostics['seconds']=time.monotonic()-begin
        return out,diagnostics
    example=next(iter(models.values()));original={k:Domain(v) for k,v in models.items()};actions={};assessments={}
    alternatives=sorted([(production(example,a,p),a,p) for a in example.actions for p in ['STOP']+example.labels],key=lambda v:(-v[0],v[1],v[2]))
    for aid,action in example.actions.items():
        di={'prefix':{},'branches':{}};admissible=True
        for name,domain in original.items():
            value,detail=domain.optimize(aid,'STOP');di['prefix'][name]=detail
            if abs(value)<5e-7:ambiguities.append(['prefix',aid,name,value])
            if value<=0:admissible=False
        if not admissible:
            assessments[aid]={'admissible':False,'policy':{},'worst_regret_tonnes':None};actions[aid]={'admissible':False,'branches':{},'optimal_regret_tonnes':None};diagnostics['actions'][aid]=di;continue
        policy={};branches={};regrets=[]
        bins=action['measurement']['bins'] if action['measurement'] is not None else [None]
        for record in bins:
            bid=record['bin_id'] if record is not None else 'unobserved';domains={};bd={'support':{},'continuations':{},'counterfactuals':[]}
            for name,model in models.items():
                domain=original[name] if record is None else Domain(model,aid,record)
                bd['support'][name]={'best_violation':domain.best_violation,'feasible_points':len(domain.points),'witness':domain.witness(domain.points[0]) if domain.points else None}
                if domain.points:domains[name]=domain
            if not domains:
                policy[bid]={'possible_models':[],'plan':'UNREACHABLE','clairvoyant_tonnes':None}
                branches[bid]={'possible_models':[],'safe_plans':[],'clairvoyant_tonnes':None,'production_by_plan':{}};di['branches'][bid]=bd;continue
            available=sorted(['STOP']+example.labels,key=lambda p:(-production(example,aid,p),p));safe=[]
            for plan in available:
                checks={};okay=True
                for name,domain in domains.items():
                    value,detail=domain.optimize(aid,plan);checks[name]=detail
                    if abs(value)<5e-7:ambiguities.append(['continuation',aid,bid,plan,name,value])
                    if value<=0:okay=False;break
                bd['continuations'][plan]=checks
                if okay:safe.append(plan)
                if safe and not full_truth:break
            if not safe:raise RuntimeError('Admissible prefix must permit STOP')
            chosen=safe[0];opportunity=None
            for tonnes,other_action,other_plan in alternatives:
                checks={};possible=False
                for name,domain in domains.items():
                    value,detail=domain.optimize(other_action,other_plan,True);checks[name]=detail
                    if abs(value)<5e-7:ambiguities.append(['counterfactual',aid,bid,other_action,other_plan,name,value])
                    if value>0:possible=True;break
                bd['counterfactuals'].append({'action':other_action,'plan':other_plan,'tonnes':tonnes,'checks':checks,'possible':possible})
                if possible:opportunity=tonnes;break
            if opportunity is None:raise RuntimeError('No safe clairvoyant strategy for reachable branch')
            q=production(example,aid,chosen);regret=opportunity-q
            if regret<-.001:raise RuntimeError('Counterfactual opportunity cannot be less than safe policy output')
            policy[bid]={'possible_models':sorted(domains),'plan':chosen,'clairvoyant_tonnes':opportunity}
            branches[bid]={'possible_models':sorted(domains),'safe_plans':safe,'clairvoyant_tonnes':opportunity,'production_by_plan':{p:production(example,aid,p) for p in available}}
            regrets.append(max(0.,regret));di['branches'][bid]=bd
        if not regrets:raise RuntimeError('Measurement bins do not cover the admissible states')
        optimum=max(regrets)
        assessments[aid]={'admissible':True,'policy':policy,'worst_regret_tonnes':optimum};actions[aid]={'admissible':True,'branches':branches,'optimal_regret_tonnes':optimum};diagnostics['actions'][aid]=di
    valid=[a for a in actions if actions[a]['admissible']];best=min(valid,key=lambda a:(actions[a]['optimal_regret_tonnes'],a));optimum=actions[best]['optimal_regret_tonnes']
    diagnostics['truth']={'supported_models':sorted(models),'actions':actions,'optimal_regret_tonnes':optimum,'acceptable_actions':[a for a in valid if actions[a]['optimal_regret_tonnes']<=optimum+1.]}
    diagnostics['ambiguities']=ambiguities;diagnostics['seconds']=time.monotonic()-begin
    return {'supported_models':sorted(models),'assessments':assessments,'recommended_action':best},diagnostics


def solve_unit(path):return solve_with_diagnostics(path,full_truth=False)[0]
if __name__=='__main__':print(json.dumps(solve_unit(sys.argv[1]),allow_nan=False))
