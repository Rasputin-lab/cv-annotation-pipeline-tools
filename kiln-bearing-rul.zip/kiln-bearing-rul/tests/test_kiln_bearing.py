"""Offline grading of conditional, robust inspection and operating policies."""
import json
import math
import os
from pathlib import Path

TONNE_TOLERANCE = 1.0
UNIT_NAMES = tuple(f"unit_{letter}" for letter in "BCDEFG")


def _number(value):
    if not isinstance(value, (float, int)) or isinstance(value, bool):
        return False
    try:
        return math.isfinite(value)
    except (OverflowError, ValueError):
        return False


def _models(value, expected):
    return (isinstance(value, list) and all(isinstance(item, str) for item in value)
            and sorted(value) == sorted(expected))


def _near(value, expected):
    return _number(value) and value >= 0 and abs(value - expected) <= TONNE_TOLERANCE


def grade_prediction(truth, prediction):
    """Check policies semantically; accept every safe policy attaining the optimum.

    Truth stores the complete safe-plan set and deterministic production for each
    reachable branch, rather than prescribing one author-selected policy.
    """
    reasons, details = [], {}
    if not isinstance(prediction, dict):
        return {"passed": False, "reasons": ["output is not an object"], "actions": {}}
    if not _models(prediction.get("supported_models"), truth["supported_models"]):
        reasons.append("original model compatibility is incorrect")
    assessments = prediction.get("assessments")
    if not isinstance(assessments, dict):
        assessments = {}
        reasons.append("assessments must be an object")
    if not truth["supported_models"]:
        if assessments or prediction.get("recommended_action") != "UNSUPPORTED":
            reasons.append("an unsupported campaign cannot justify a policy")
        return {"passed": not reasons, "reasons": reasons, "actions": {}}
    if set(assessments) != set(truth["actions"]):
        reasons.append("assess every listed action and no other action")

    for action_id, target in truth["actions"].items():
        failures = []
        supplied = assessments.get(action_id)
        if not isinstance(supplied, dict):
            reasons.append(f"{action_id}: assessment is missing or not an object")
            details[action_id] = {"passed": False, "reasons": ["invalid assessment"]}
            continue
        if not {"admissible", "policy", "worst_regret_tonnes"}.issubset(supplied):
            failures.append("assessment fields are missing")
        if supplied.get("admissible") is not target["admissible"]:
            failures.append("prefix admissibility is incorrect")
        policy = supplied.get("policy")
        if not isinstance(policy, dict):
            failures.append("policy must be an object")
            policy = {}
        if not target["admissible"]:
            if policy or supplied.get("worst_regret_tonnes") is not None:
                failures.append("an inadmissible action requires an empty policy and null regret")
            details[action_id] = {"passed": not failures, "reasons": failures,
                                  "attained_regret_tonnes": None}
            reasons.extend(f"{action_id}: {item}" for item in failures)
            continue

        if set(policy) != set(target["branches"]):
            failures.append("report every outcome branch and no other branch")
        branch_details, branch_regrets = {}, []
        choices_valid = True
        for bin_id, branch in target["branches"].items():
            errors = []
            report = policy.get(bin_id)
            if not isinstance(report, dict):
                errors.append("branch is missing or not an object")
                report = {}
            if not {"possible_models", "plan", "clairvoyant_tonnes"}.issubset(report):
                errors.append("branch fields are missing")
            if not _models(report.get("possible_models"), branch["possible_models"]):
                errors.append("conditional model compatibility is incorrect")
            if not branch["possible_models"]:
                if report.get("plan") != "UNREACHABLE" or report.get("clairvoyant_tonnes") is not None:
                    errors.append("an impossible outcome requires UNREACHABLE and null opportunity")
            else:
                if not _near(report.get("clairvoyant_tonnes"), branch["clairvoyant_tonnes"]):
                    errors.append("clairvoyant opportunity is incorrect")
                plan = report.get("plan")
                if not isinstance(plan, str) or plan not in branch["safe_plans"]:
                    errors.append("chosen plan is not safe for the complete conditional set")
                    choices_valid = False
                else:
                    # Compute regret from truth, never from the submitted opportunity.
                    branch_regrets.append(branch["clairvoyant_tonnes"] - branch["production_by_plan"][plan])
            branch_details[bin_id] = {"passed": not errors, "reasons": errors}
            failures.extend(f"{bin_id}: {item}" for item in errors)

        attained = max(0.0, max(branch_regrets)) if choices_valid and branch_regrets else None
        if attained is None:
            failures.append("the reported choices do not define a safe policy")
        else:
            if not _near(supplied.get("worst_regret_tonnes"), attained):
                failures.append("reported regret does not match the chosen policy")
            if abs(attained - target["optimal_regret_tonnes"]) > TONNE_TOLERANCE:
                failures.append("policy does not attain this action's minimum worst regret")
        details[action_id] = {"passed": not failures, "reasons": failures,
                              "attained_regret_tonnes": attained,
                              "optimal_regret_tonnes": target["optimal_regret_tonnes"],
                              "branches": branch_details}
        reasons.extend(f"{action_id}: {item}" for item in failures)

    recommendation = prediction.get("recommended_action")
    recommendation_ok = isinstance(recommendation, str) and recommendation in truth["acceptable_actions"]
    if not recommendation_ok:
        reasons.append("recommendation is not a globally regret-optimal admissible action")
    elif (details.get(recommendation, {}).get("attained_regret_tonnes") is None
          or details[recommendation]["attained_regret_tonnes"] > truth["optimal_regret_tonnes"] + TONNE_TOLERANCE):
        # Do not accumulate an action-tie allowance and a policy-tie allowance.
        reasons.append("recommended policy exceeds the global regret tolerance")
        recommendation_ok = False
    return {"passed": not reasons, "reasons": reasons, "actions": details,
            "recommendation_passed": recommendation_ok}


def test_conditional_inspection_policies():
    tests_root = Path(__file__).resolve().parent
    predictions = Path(os.environ.get("KILN_PREDICTION_DIR", "/root/agent_output"))
    results_dir = Path("/root/results")
    results_dir.mkdir(parents=True, exist_ok=True)
    rows = []
    for unit in UNIT_NAMES:
        truth = json.loads((tests_root / "held_out" / unit / "truth.json").read_text())
        try:
            prediction = json.loads((predictions / f"{unit}.json").read_text())
            row = grade_prediction(truth, prediction)
        except (OSError, ValueError, TypeError) as exc:
            row = {"passed": False, "reasons": [f"unreadable output: {type(exc).__name__}"], "actions": {}}
        rows.append({"unit": unit, **row})
    n_pass = sum(row["passed"] for row in rows)
    reward = 1 if n_pass == len(UNIT_NAMES) else 0
    metrics = {"n_pass": n_pass, "n_total": len(UNIT_NAMES), "fraction_passed": n_pass / len(UNIT_NAMES),
               "reward": reward, "per_unit": rows}
    (results_dir / "metrics.json").write_text(json.dumps(metrics, indent=2) + "\n")
    verifier = Path("/logs/verifier")
    verifier.mkdir(parents=True, exist_ok=True)
    if reward == 1:
        (verifier / "reward.txt").write_text("1\n")
    else:
        (verifier / "reward.txt").write_text("0\n")
    assert reward == 1, json.dumps({"passed": n_pass, "required": len(UNIT_NAMES),
                                  "failures": {row["unit"]: row["reasons"] for row in rows if not row["passed"]}})
