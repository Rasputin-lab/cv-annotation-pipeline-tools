#!/bin/bash
set -uo pipefail
mkdir -p /root/agent_output /root/results /logs/verifier /logs/artifacts

# Lock down /logs/verifier before any agent code runs, so a compromised
# solve_bearing.py can't write its own reward.txt later in this script.
chmod 700 /logs/verifier

# Lock down /tests -- in particular tests/held_out/*/truth.json, the answer
# key -- to root-only access, before any agent code runs. The Dockerfile
# already does this at image build time, but that alone is not sufficient:
# some harnesses bind-mount /tests at container start rather than relying
# on what was baked into the image, which would silently undo a
# build-time-only chmod. This runtime chmod is the actual enforcement
# point and does not depend on how /tests got there.
chmod -R go-rwx /tests
chmod 700 /tests

# The agent's solver MUST run as a non-root, unprivileged user with no read
# access to /tests -- that is what makes the truth.json lockdown above
# meaningful. If this image cannot provide that (no `nobody` user, or no
# `runuser` to drop to it), fail closed: do not fall back to running the
# agent's code as root, which would make the chmod above pointless (root
# ignores file permissions) and hand the agent the answer key outright.
if ! id nobody >/dev/null 2>&1 || ! command -v runuser >/dev/null 2>&1 || ! command -v pkill >/dev/null 2>&1; then
  echo "FATAL: cannot isolate agent execution (need 'nobody' user, 'runuser' and 'pkill';" >&2
  echo "see tests/Dockerfile). Refusing to run agent code as root." >&2
  echo 0 > /logs/verifier/reward.txt
  exit 1
fi
AGENT_USER="nobody"
HAVE_SETSID=0
command -v setsid >/dev/null 2>&1 && HAVE_SETSID=1

# Artifact export can normalize owner/group modes. Give the unprivileged
# process its own readable copy without granting it access to sealed tests
# or depending on traversal permissions in the artifact transport path.
SOLVER_SANDBOX="$(mktemp -d)"
if [ -f /logs/artifacts/solve_bearing.py ]; then
  cp /logs/artifacts/solve_bearing.py "$SOLVER_SANDBOX/solve_bearing.py"
fi
chown -R "$AGENT_USER" "$SOLVER_SANDBOX"
chmod -R u+rwX,go-rwx "$SOLVER_SANDBOX"

for unit in unit_B unit_C unit_D unit_E unit_F unit_G; do
  # Copy this unit into a scratch directory with truth.json stripped out.
  # This is defense in depth on top of the /tests lockdown above, not a
  # substitute for it: even if the lockdown above were ever misconfigured,
  # the agent process still would not find truth.json in the one directory
  # it's actually pointed at.
  SANDBOX="$(mktemp -d)"
  cp -r "/tests/held_out/${unit}/." "$SANDBOX/"
  rm -f "$SANDBOX/truth.json"
  chown -R "$AGENT_USER" "$SANDBOX"
  chmod -R u+rwX,go-rwx "$SANDBOX"
  # nobody can read/traverse its own scratch copy (owner bits above) but
  # nothing else on the filesystem, including the real /tests -- that part
  # was already locked down before this loop even started.

  OUT_FILE="$(mktemp)"
  # Keep execution diagnostics in the sealed verifier directory so a
  # numerical failure can be distinguished from a process or memory error.
  ERR_FILE="/logs/verifier/${unit}.stderr.log"
  RUN_CMD="python3 $SOLVER_SANDBOX/solve_bearing.py $SANDBOX"
  if [ "$HAVE_SETSID" -eq 1 ]; then
    setsid timeout -k 5 180 runuser -u "$AGENT_USER" -- bash -c "$RUN_CMD" > "$OUT_FILE" 2> "$ERR_FILE"
  else
    timeout -k 5 180 runuser -u "$AGENT_USER" -- bash -c "$RUN_CMD" > "$OUT_FILE" 2> "$ERR_FILE"
  fi
  STATUS=$?
  printf '%s\n' "$STATUS" > "/logs/verifier/${unit}.exit_code.txt"

  # Nothing the agent's process started (including a background/daemonized
  # child) survives past its own turn, so it cannot keep running after its
  # output has been captured and try to interfere with a later unit.
  pkill -9 -u "$AGENT_USER" 2>/dev/null || true

  if [ "$STATUS" -eq 0 ] && [ -s "$OUT_FILE" ]; then
    cp "$OUT_FILE" "/root/agent_output/${unit}.json"
  else
    echo '{}' > "/root/agent_output/${unit}.json"
  fi

  rm -rf "$SANDBOX" "$OUT_FILE"
done
rm -rf "$SOLVER_SANDBOX"

pytest --ctrf /logs/verifier/ctrf.json /tests/test_kiln_bearing.py -rA
PYTEST_STATUS=$?

# Guarantee a reward on every code path, including a pytest collection
# error or an unhandled exception that occurred before the test body
# could write /logs/verifier/reward.txt itself.
if [ ! -s /logs/verifier/reward.txt ]; then
  echo "0" > /logs/verifier/reward.txt
fi

exit "$PYTEST_STATUS"
