Choose an inspection and operating policy for a cracked kiln-support bearing outer ring through its scheduled shutdown. Determine which qualified crack-growth models remain consistent with the measurements, then account for what a future inspection could reveal. The decision objective is minimum worst-case production regret under the physical safety constraints in the data README.

The inputs are in `/root/data/unit_A/`:

- `bearing_spec.json`: geometry, material limits, parameter bounds and shutdown time.
- `history.csv`: ordered operating blocks and bounded crack-depth readings.
- `coupon_growth.csv`: material growth measurements.
- `depth_calibration.csv`: calibration measurements from the historical instrument.
- `future_duty.csv`: repeating operating plans and production rates.
- `inspection_options.json`: permitted initial schedules, downtime and possible inspection outcomes.
- `README.md`: physical models, measurement conventions and complete decision definitions. Every evaluated unit includes it.

Create `/logs/artifacts/solve_bearing.py` as a self-contained script that runs with:

    python3 /logs/artifacts/solve_bearing.py <unit_directory>

Print one JSON object and no other stdout text. Its structure is:

    {"supported_models":["walker","wheeler"],"assessments":{"A0":{"admissible":true,"policy":{"unobserved":{"possible_models":["walker","wheeler"],"plan":"P0","clairvoyant_tonnes":1200.0}},"worst_regret_tonnes":200.0}},"recommended_action":"A0"}

The identifiers and numbers above are examples. Report every supported model and assess every supplied action. An admissible action has a prefix safe for every originally compatible explanation. For each of its reported-outcome branches, give the compatible models, a plan safe for that complete conditional set, and the largest production opportunity available to a fully informed decision-maker in that set. Include all listed actions when computing that opportunity, subject to their physical safety for the same explanation.

Report a regret-optimal policy for each admissible action, its attained worst regret, and a globally optimal `recommended_action`. Alternative equally good policies are accepted. `STOP` ends operation after the prefix; its production includes the prefix. An impossible branch requires empty `possible_models`, plan `UNREACHABLE` and null `clairvoyant_tonnes`. An inadmissible action requires an empty `policy` and null `worst_regret_tonnes`. If neither model fits, return `{"supported_models":[],"assessments":{},"recommended_action":"UNSUPPORTED"}`.

Evaluation uses six unseen units with the same files and conventions. All six must pass. It checks model support, conditional support, prefix admissibility, policy safety, opportunity, regret and the recommendation. Reported production quantities and optimal-policy ties have a 1-tonne allowance, as defined in the README.

Read only the supplied unit directory and work unchanged with its local values. No particular numerical method is required. The offline Python 3.11 verifier provides NumPy 2.4.4, SciPy 1.17.1 and Numba 0.65.1, allowing 180 seconds per invocation.

You have 28800 seconds to complete this task. Do not cheat by using online solutions or hints specific to this task.
