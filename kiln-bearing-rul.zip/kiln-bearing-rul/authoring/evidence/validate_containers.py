import hashlib,json,pathlib,subprocess,time,sys
base=pathlib.Path(sys.argv[1]).resolve();base.mkdir(parents=True,exist_ok=True)
bundle=pathlib.Path(__file__).resolve().parents[2]
out=base/'container-runs-final';out.mkdir(exist_ok=True)
verifier_image='kiln-rul-verifier:policy-20261013'
agent_image='kiln-rul-agent:policy-20261013'
docker=['env','-u','DOCKER_HOST','-u','DOCKER_CONTEXT','-u','DOCKER_TLS','-u','DOCKER_TLS_VERIFY','-u','DOCKER_CERT_PATH','docker','--host=unix:///var/run/docker.sock']
sources=['solution/solve_bearing.py','solution/solve.sh','authoring/evidence/independent_solver.py','authoring/evidence/self_cheat_read_truth_direct.py','tests/test.sh','tests/test_kiln_bearing.py','tests/Dockerfile','environment/Dockerfile','authoring/provenance/generate_data.py']
source_hashes={rel:hashlib.sha256((bundle/rel).read_bytes()).hexdigest() for rel in sources}
# Check actual filesystem denials separately from reward. The revised harness also retains per-unit stderr and exit codes.
audit_code='''import json,os,pathlib
records=[]
for name in ('unit_B','unit_C','unit_D','unit_E','unit_F','unit_G'):
 p=pathlib.Path('/tests/held_out')/name/'truth.json'
 try:
  with p.open() as f:f.read(1)
  outcome='readable'
 except Exception as e:outcome=type(e).__name__
 records.append({'unit':name,'truth_read_outcome':outcome})
try:
 with open('/logs/verifier/isolation_probe_write.txt','w') as f:f.write('probe')
 write='writable'
except Exception as e:write=type(e).__name__
print(json.dumps({'uid':os.getuid(),'truth_access':records,'verifier_log_write_outcome':write}))
'''
script=base/'isolation_audit.py';script.write_text(audit_code);script.chmod(0o644)
trials=json.loads((out/"runtime_report.json").read_text()) if (out/"runtime_report.json").exists() else []
for route,attempts in [('oracle',3),('nop',3),('independent',1),('direct_truth_probe',1)]:
 for attempt in range(1,attempts+1):
  if any(r['route']==route and r['attempt']==attempt for r in trials):continue
  trial=out/f'{route}-{attempt}';trial.mkdir(exist_ok=True)
  logs=trial/'logs';logs.mkdir(exist_ok=True)
  if route!='nop':
   source=bundle/({'oracle':'solution/solve_bearing.py','independent':'authoring/evidence/independent_solver.py','direct_truth_probe':'authoring/evidence/self_cheat_read_truth_direct.py'}[route])
   staged=trial/'solution';staged.mkdir(exist_ok=True)
   (staged/'solve_bearing.py').write_bytes(source.read_bytes())
   (staged/'solve.sh').write_bytes((bundle/'solution/solve.sh').read_bytes())
   stage=subprocess.run(docker+['run','--rm','--network=none','--cpus=2','--memory=8192m','-v',f'{staged}:/solution:ro','-v',f'{logs}:/logs',agent_image,'bash','-c','bash /solution/solve.sh && chmod 600 /logs/artifacts/solve_bearing.py'],text=True,capture_output=True,timeout=180)
   (trial/'staging.log').write_text(stage.stdout+stage.stderr)
   if stage.returncode:raise RuntimeError(f'{route} staging failed: '+stage.stderr)
  command='''bash /tests/test.sh
status=$?
runuser -u nobody -- python3 /tmp/isolation_audit.py
python3 -c 'import json,pathlib,platform; print("BUNDLE_RUNTIME_RESULT="+json.dumps({"reward":pathlib.Path("/logs/verifier/reward.txt").read_text(),"metrics":json.loads(pathlib.Path("/root/results/metrics.json").read_text()),"python":platform.python_version(),"memory_limit_bytes":pathlib.Path("/sys/fs/cgroup/memory.max").read_text().strip(),"unit_exit_codes":{u:int(pathlib.Path("/logs/verifier/"+u+".exit_code.txt").read_text()) for u in ("unit_B","unit_C","unit_D","unit_E","unit_F","unit_G")}}))'
exit "$status"
'''
  start=time.monotonic()
  run=subprocess.run(docker+['run','--rm','--network=none','--cpus=2','--memory=8192m','-v',f'{logs}:/logs','-v',f'{script}:/tmp/isolation_audit.py:ro',verifier_image,'bash','-c',command],text=True,capture_output=True,timeout=1200)
  (trial/'runtime.log').write_text(run.stdout+run.stderr)
  result=next((json.loads(line.split('=',1)[1]) for line in run.stdout.splitlines() if line.startswith('BUNDLE_RUNTIME_RESULT=')),None)
  audit=next((json.loads(line) for line in run.stdout.splitlines() if line.startswith('{"uid":')),None)
  record={'route':route,'attempt':attempt,'exit_code':run.returncode,'seconds':time.monotonic()-start,'result':result,'isolation_permission_audit':audit}
  trials.append(record)
  (out/'runtime_report.json').write_text(json.dumps(trials,indent=2)+'\n')
  print(json.dumps({k:v for k,v in record.items() if k not in ('result','isolation_permission_audit')}|{'reward':result['reward'] if result else None,'n_pass':result['metrics'].get('n_pass') if result else None,'permission_denials_verified': bool(audit and all(r['truth_read_outcome']=='PermissionError' for r in audit['truth_access']) and audit['verifier_log_write_outcome']=='PermissionError')}),flush=True)
  expected=0 if route in ('nop','direct_truth_probe') else 1
  if result is None or float(result['reward'])!=expected:raise RuntimeError('Unexpected runtime reward for '+route)
  assert result['memory_limit_bytes']==str(8192*1024*1024)
  assert audit and audit['uid']!=0 and all(r['truth_read_outcome']=='PermissionError' for r in audit['truth_access']) and audit['verifier_log_write_outcome']=='PermissionError'
after={rel:hashlib.sha256((bundle/rel).read_bytes()).hexdigest() for rel in sources}
assert source_hashes==after,'sources changed during runtime tests'
report={'scope':'Fresh actual solution/solve.sh staging on the newly built Ubuntu agent image and actual offline tests/test.sh on the separate verifier image; no remote agent probe or platform gate claimed. Builds use the shipped dependency pins and current data; any managed-proxy CA mounts are temporary and are not image layers.','verifier_image':verifier_image,'agent_image':agent_image,'artifact_transport_test':'Artifact chmod0600 after staging; tests/test.sh makes an unprivileged readable private scratch copy.','network_mode':'none','source_sha256':source_hashes,'source_unchanged_during_run':True,'trials':trials}
(bundle/'authoring/evidence/container_validation.json').write_text(json.dumps(report,indent=2)+'\n')
probe=next(r for r in trials if r['route']=='direct_truth_probe')
(bundle/'authoring/evidence/self_cheat_read_truth_direct_metrics.json').write_text(json.dumps(probe['result']['metrics'],indent=2)+'\n')
(bundle/'authoring/evidence/self_cheat_read_truth_direct_reward.txt').write_text(probe['result']['reward'].strip()+'\n')
