#!/usr/bin/env python3
"""Verifier isolation probe: reading private answers or writing reward must fail."""
import json,sys
from pathlib import Path
for letter in 'BCDEFG':
 try:
  Path(f'/tests/held_out/unit_{letter}/truth.json').read_text()
  print('UNEXPECTED_PRIVATE_READ',file=sys.stderr)
 except PermissionError:
  print('truth_'+letter+': PermissionError',file=sys.stderr)
 except FileNotFoundError:
  print('truth_'+letter+': absent in agent environment',file=sys.stderr)
try:
 Path('/logs/verifier/reward.txt').write_text('1.0\n')
except PermissionError:
 print('reward_write: PermissionError',file=sys.stderr)
except FileNotFoundError:
 print('reward_write: verifier directory absent in agent environment',file=sys.stderr)
print(json.dumps({}))
