#!/usr/bin/env python3
"""Audit observation-bin support and numerical separation in the shipped data.

Numerical multistart evidence, not a proof that the projection is connected or
that a local search has globally exhausted the parameter set. Branch support is
checked separately against all joint constraints, not inferred from extrema.
"""
import os
os.environ.setdefault('OPENBLAS_NUM_THREADS','1')
import argparse,hashlib,importlib.util,json,sys,time
from pathlib import Path
import numpy as np
from scipy.optimize import minimize

ROOT=Path(__file__).resolve().parents[2]
SOURCE=Path(__file__).with_name('independent_solver.py')
spec=importlib.util.spec_from_file_location('independent_branch_audit',SOURCE)
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('--data-root',type=Path,help='Optional flat directory containing unit_A through unit_G')
parser.add_argument('--output',type=Path,default=Path(__file__).with_name('branch_margins.json'))
parser.add_argument('--units',default='ABCDEFG')
parser.add_argument('--warning-width-mm',type=float,default=.0003)
args=parser.parse_args();OUTPUT=args.output;LETTERS=args.units;FLAG_WIDTH_MM=args.warning_width_mm
OUTPUT.parent.mkdir(parents=True,exist_ok=True)
def unit_path(letter):
 return args.data_root/('unit_'+letter) if args.data_root else ROOT/('environment/data' if letter=='A' else 'tests/held_out')/('unit_'+letter)
def input_hashes():
 return {letter+'/'+p.name:hashlib.sha256(p.read_bytes()).hexdigest() for letter in LETTERS
         for p in sorted(unit_path(letter).iterdir()) if p.is_file() and p.name!='truth.json'}
data_hashes=input_hashes()
report={'audit_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'independent_source_sha256':hashlib.sha256(SOURCE.read_bytes()).hexdigest(),
 'input_sha256':data_hashes,'sliver_warning_width_mm':FLAG_WIDTH_MM,'units':{},
 'qualification':'Independent constrained multistart observation extrema and direct joint branch feasibility. Extrema do not establish connectedness or mathematical global completeness.'}
started=time.monotonic()

for letter in LETTERS:
 path=unit_path(letter);unit={'models':{},'branches':[],'warnings':[]}
 for kind,name in [(0,'walker'),(1,'wheeler')]:
  model=m.Assessment(path,kind);bad=model.fit(count=24)
  md={'supported':bool(model.seeds),'smallest_prior_violation':float(bad),'feasible_starts':len(model.seeds),'actions':{}}
  unit['models'][name]=md
  if not model.seeds:continue
  for aid,action in model.actions.items():
   measurement=action['measurement']
   if measurement is None:continue
   def observation(x):
    depth,_,_=model.prefix(x,aid)
    return depth+(model.theta(x)[6] if measurement['bias_mode']=='shared' else 0.)
   extrema={}
   for sign,label in [(1.,'minimum'),(-1.,'maximum')]:
    points=m.diverse(model.seeds,12);winner=min(points,key=lambda z:sign*observation(z));best=observation(winner);statuses=[]
    for initial in points:
     opt=minimize(lambda z:sign*observation(z),initial,method='SLSQP',bounds=model.bounds,constraints={'type':'ineq','fun':model.constraints},options={'maxiter':250,'ftol':1e-12,'eps':1e-7})
     statuses.append(int(opt.status))
     if min(model.constraints(opt.x))>=-m.FEASIBILITY_TOL:
      value=observation(opt.x)
      if sign*value<sign*best:winner=opt.x.copy();best=value
    extrema[label]={'centre_mm':float(best),'parameters':model.theta(winner).tolist(),'normalized':np.asarray(winner).tolist(),'constraint_violation':max(0.,-float(min(model.constraints(winner)))),'optimizer_statuses':statuses}
   low=extrema['minimum']['centre_mm']-measurement['absolute_error_mm'];high=extrema['maximum']['centre_mm']+measurement['absolute_error_mm']
   md['actions'][aid]={'bias_mode':measurement['bias_mode'],'extrema':extrema,'attainable_reading_outer_interval_mm':[low,high]}
   for b in measurement['bins']:
    domain=m.ConditionalDomain(model,aid,b);supported=bool(domain.points)
    overlap=min(float(b['upper_mm']),high)-max(float(b['lower_mm']),low)
    item={'model':name,'action':aid,'bin':b['bin_id'],'jointly_reachable':supported,'smallest_branch_violation':domain.best_violation,'projection_overlap_mm':float(overlap),'sliver':supported and overlap<FLAG_WIDTH_MM}
    if domain.points:item['witness']=domain.witness(domain.points[0],model.clearance(domain.points[0],aid,'STOP'))
    if item['sliver']:unit['warnings'].append({'type':'narrow_bin_support',**item})
    if overlap<0 and supported:unit['warnings'].append({'type':'extrema_missed_feasible_branch',**item})
    if overlap>FLAG_WIDTH_MM and not supported:unit['warnings'].append({'type':'projection_overlap_but_no_joint_witness','note':'May reflect disconnected projection or a feasibility search miss.',**item})
    unit['branches'].append(item)
 report['units']['unit_'+letter]=unit;report['seconds']=time.monotonic()-started
 OUTPUT.write_text(json.dumps(report,indent=2)+'\n')
 print('unit_'+letter,'supported',[k for k,v in unit['models'].items() if v['supported']],'warnings',[(v['type'],v['model'],v['action'],v['bin']) for v in unit['warnings']],flush=True)
report['source_unchanged_during_audit']=hashlib.sha256(SOURCE.read_bytes()).hexdigest()==report['independent_source_sha256']
report['warnings_count']=sum(len(v['warnings']) for v in report['units'].values())
report['data_unchanged_during_audit']=input_hashes()==data_hashes
report['passed']=report['warnings_count']==0 and report['source_unchanged_during_audit'] and report['data_unchanged_during_audit']
OUTPUT.write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'seconds':report['seconds'],'warnings':report['warnings_count'],'source_unchanged':report['source_unchanged_during_audit']}),flush=True)

if not report['passed']:raise SystemExit(1)
