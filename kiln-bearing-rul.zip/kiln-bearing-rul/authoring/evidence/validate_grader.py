#!/usr/bin/env python3
"""Semantic policy-grading checks, including alternative optima and malformed outputs."""
import copy
import importlib.util
import json
from pathlib import Path

base = Path(__file__).resolve().parents[2]
spec = importlib.util.spec_from_file_location('grader', base/'tests/test_kiln_bearing.py')
g = importlib.util.module_from_spec(spec)
spec.loader.exec_module(g)


def branch(models, clair, production):
    return {'possible_models': models, 'clairvoyant_tonnes': clair,
            'safe_plans': list(production), 'production_by_plan': production}

truth = {
    'supported_models': ['walker','wheeler'],
    'actions': {
        'DIRECT': {'admissible': True, 'optimal_regret_tonnes': 30., 'branches': {
            'unobserved': branch(['walker','wheeler'],100.,{'STOP':0.,'P70':70.})}},
        'INSPECT': {'admissible': True, 'optimal_regret_tonnes': 20., 'branches': {
            # STOP retains sixty tonnes produced by the prefix.
            'low': branch(['walker'],80.,{'STOP':60.,'P70':70.}),
            'high': branch(['wheeler'],100.,{'STOP':60.,'P80':80.}),
            'empty': branch([],None,{})}},
        'NEARTIE': {'admissible': True, 'optimal_regret_tonnes': 20.75, 'branches': {
            'middle': branch(['walker','wheeler'],100.,{'STOP':60.,'BEST':79.25,'LOCAL_TIE':78.5})}},
        'INADMISSIBLE': {'admissible': False, 'optimal_regret_tonnes': None, 'branches': {}},
    },
    'optimal_regret_tonnes':20., 'acceptable_actions':['INSPECT','NEARTIE'],
}


def report(models, plan, clair):
    return {'possible_models':models, 'plan':plan, 'clairvoyant_tonnes':clair}

prediction = {
    'supported_models':['walker','wheeler'],
    'assessments': {
        'DIRECT':{'admissible':True,'policy':{'unobserved':report(['walker','wheeler'],'P70',100.)},'worst_regret_tonnes':30.},
        'INSPECT':{'admissible':True,'policy':{
            'low':report(['walker'],'P70',80.),'high':report(['wheeler'],'P80',100.),
            'empty':report([],'UNREACHABLE',None)},'worst_regret_tonnes':20.},
        'NEARTIE':{'admissible':True,'policy':{'middle':report(['walker','wheeler'],'BEST',100.)},'worst_regret_tonnes':20.75},
        'INADMISSIBLE':{'admissible':False,'policy':{},'worst_regret_tonnes':None},
    },
    'recommended_action':'INSPECT',
}
results=[]


def check(name, expected, mutate=None, base_prediction=None, base_truth=None):
    p=copy.deepcopy(prediction if base_prediction is None else base_prediction)
    t=copy.deepcopy(truth if base_truth is None else base_truth)
    if mutate: mutate(p,t)
    result=g.grade_prediction(t,p)
    assert result['passed'] is expected, (name, result)
    results.append({'test':name,'expected_pass':expected,'actual_pass':result['passed']})


def put(path, value):
    def mutate(p,t):
        cursor=p
        for key in path[:-1]: cursor=cursor[key]
        cursor[path[-1]]=value
    return mutate

check('canonical optimum',True)
check('model ordering immaterial',True,put(['supported_models'],['wheeler','walker']))
check('alternative optimum with STOP prefix production',True,put(['assessments','INSPECT','policy','low','plan'],'STOP'))
check('recommended action within global one-tonne tie',True,put(['recommended_action'],'NEARTIE'))
check('reported scalar within allowance',True,put(['assessments','INSPECT','policy','low','clairvoyant_tonnes'],80.9))
check('reported scalar beyond allowance',False,put(['assessments','INSPECT','policy','low','clairvoyant_tonnes'],81.01))

def localtie(p,t):
    p['assessments']['NEARTIE']['policy']['middle']['plan']='LOCAL_TIE'
    p['assessments']['NEARTIE']['worst_regret_tonnes']=21.5
check('nonrecommended per-action tie allowed',True,localtie)
def doubled(p,t):
    localtie(p,t);p['recommended_action']='NEARTIE'
check('local and global tie allowances do not add',False,doubled)
check('wrong model set',False,put(['supported_models'],['walker']))
check('duplicate model names',False,put(['supported_models'],['walker','wheeler','walker']))
check('incorrect conditional support',False,put(['assessments','INSPECT','policy','low','possible_models'],['wheeler']))
check('unsafe plan rejected despite plausible regret',False,put(['assessments','INSPECT','policy','high','plan'],'P70'))
check('unknown plan rejected',False,put(['assessments','INSPECT','policy','high','plan'],'NEW'))
check('plan must be string',False,put(['assessments','INSPECT','policy','high','plan'],['P80']))
check('unreachable branch must be marked',False,put(['assessments','INSPECT','policy','empty','plan'],'STOP'))
check('unreachable opportunity must be null',False,put(['assessments','INSPECT','policy','empty','clairvoyant_tonnes'],0.))
check('admissibility requires actual boolean',False,put(['assessments','DIRECT','admissible'],1))
check('wrong admissibility rejected',False,put(['assessments','INADMISSIBLE','admissible'],True))
check('inadmissible action cannot report policy',False,put(['assessments','INADMISSIBLE','policy'],{'low':{}}))
check('inadmissible action must report null regret',False,put(['assessments','INADMISSIBLE','worst_regret_tonnes'],0.))
check('reported regret tied to true production',False,put(['assessments','INSPECT','worst_regret_tonnes'],0.))
check('nonoptimal global action rejected',False,put(['recommended_action'],'DIRECT'))
check('inadmissible recommendation rejected',False,put(['recommended_action'],'INADMISSIBLE'))
check('all action IDs required',False,lambda p,t:p['assessments'].pop('DIRECT'))
check('no extra action IDs',False,lambda p,t:p['assessments'].update({'EXTRA':{}}))
check('all bins required',False,lambda p,t:p['assessments']['INSPECT']['policy'].pop('empty'))
check('no extra bins',False,lambda p,t:p['assessments']['INSPECT']['policy'].update({'EXTRA':{}}))
check('all branch fields required',False,lambda p,t:p['assessments']['INSPECT']['policy']['low'].pop('plan'))
check('all assessment fields required',False,lambda p,t:p['assessments']['INADMISSIBLE'].pop('policy'))
for name,value in [('NaN',float('nan')),('infinity',float('inf')),('negative',-1.),('boolean',True),('huge integer',10**1000),('string','80')]:
    check(name+' numeric rejection',False,put(['assessments','INSPECT','policy','low','clairvoyant_tonnes'],value))
for value in [[],None,{},False,'object']:
    check('malformed top level '+repr(value),False,base_prediction=value if value is not None else False)
for value in [[],None,True,'object']:
    check('malformed assessment '+repr(value),False,put(['assessments','DIRECT'],value))
    check('malformed branch '+repr(value),False,put(['assessments','INSPECT','policy','low'],value))
unsupported_truth={'supported_models':[],'actions':{},'acceptable_actions':[],'optimal_regret_tonnes':None}
unsupported={'supported_models':[],'assessments':{},'recommended_action':'UNSUPPORTED'}
check('unsupported campaign',True,base_truth=unsupported_truth,base_prediction=unsupported)
check('unsupported campaign cannot recommend action',False,put(['recommended_action'],'DIRECT'),base_truth=unsupported_truth,base_prediction=unsupported)
check('unsupported campaign must report assessments object',False,lambda p,t:p.pop('assessments'),base_truth=unsupported_truth,base_prediction=unsupported)
(Path(__file__).with_name('grader_semantic_results.json')).write_text(json.dumps({'passed':len(results),'failed':0,'tests':results},indent=2)+'\n')
print(json.dumps({'passed':len(results),'failed':0}))
