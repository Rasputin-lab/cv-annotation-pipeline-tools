#!/usr/bin/env python3
"""Reproduce semantic and physical controls for inspection-policy grading.

The first three controls receive the exact compatible models, admissibility,
conditional safe-plan sets and opportunities. They isolate decisions rather
than failures to fit the data. The physical controls reuse the reference's
unchanged historical inference and alter one future assumption. None is a
reconstruction of an agent trajectory or an estimate of an agent solve rate.

Run from any directory, for example:
  python authoring/evidence/run_ablations.py --output /tmp/ablations.json
Optional --data-root and --truth-root accept directories containing unit_B,
... unit_G; they make candidate calibration reproducible before promotion.
"""
import argparse
import copy
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import time

os.environ.setdefault("OPENBLAS_NUM_THREADS", "1")
os.environ.setdefault("OMP_NUM_THREADS", "1")

ROOT = Path(__file__).resolve().parents[2]
ORACLE_CONTROLS = (
    "same_prefix_open_loop",
    "unconditioned_clairvoyant",
    "always_stop",
)
PHYSICAL_CONTROLS = ("forget_future_memory", "shared_as_recalibrated")
DESCRIPTIONS = {
    "same_prefix_open_loop": (
        "Exact original and conditional support, safety and opportunity; one "
        "maximum-production continuation safe across all reachable outcomes "
        "of each unchanged prefix action. Regret and recommendation are recomputed."
    ),
    "unconditioned_clairvoyant": (
        "Exact conditional support and safest maximum-production continuation; "
        "the opportunity in every branch is replaced by the unobserved prior "
        "opportunity, discarding the same-specimen conditional intersection."
    ),
    "always_stop": (
        "Exact original/conditional support, prefix admissibility and opportunity; "
        "STOP in every reachable branch, with correct regret arithmetic."
    ),
    "forget_future_memory": (
        "Unchanged historical inference; reset the plastic-zone memory to the "
        "current crack at the entrance of every positive-time proposed prefix "
        "and continuation block. Recompute observations, safety and opportunity."
    ),
    "shared_as_recalibrated": (
        "Unchanged historical inference and future propagation; omit the "
        "historical common bias from shared-instrument future reading centers. "
        "The supplied error and bin bounds remain unchanged."
    ),
}


def load_module(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


def read_json(path):
    return json.loads(Path(path).read_text())


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def validate_truth(truth, unit):
    required = {"supported_models", "actions", "optimal_regret_tonnes", "acceptable_actions"}
    if not isinstance(truth, dict) or not required.issubset(truth):
        raise ValueError(f"{unit}: policy truth is absent; do not run against the old life-envelope truth")
    for aid, action in truth["actions"].items():
        if not action["admissible"]:
            continue
        for bid, branch in action["branches"].items():
            if branch["possible_models"]:
                if "STOP" not in branch["safe_plans"]:
                    raise ValueError(f"{unit}/{aid}/{bid}: admissible reachable branch must permit STOP")
                if not set(branch["safe_plans"]).issubset(branch["production_by_plan"]):
                    raise ValueError(f"{unit}/{aid}/{bid}: incomplete production table")


def recompute_regrets(prediction, truth):
    """Use a control's declared opportunities and actual deterministic output."""
    if not truth["supported_models"]:
        return prediction
    regrets = {}
    for aid, assessment in prediction["assessments"].items():
        if not assessment["admissible"]:
            continue
        branch_regrets = []
        for bid, report in assessment["policy"].items():
            if report["possible_models"]:
                production = truth["actions"][aid]["branches"][bid]["production_by_plan"][report["plan"]]
                branch_regrets.append(report["clairvoyant_tonnes"] - production)
        if not branch_regrets:
            raise ValueError(f"{aid}: bins do not cover any compatible explanation")
        regret = max(0.0, max(branch_regrets))
        assessment["worst_regret_tonnes"] = regret
        regrets[aid] = regret
    prediction["recommended_action"] = min(regrets, key=lambda aid: (regrets[aid], aid))
    return prediction


def oracle_prediction(truth):
    if not truth["supported_models"]:
        return {"supported_models": [], "assessments": {}, "recommended_action": "UNSUPPORTED"}
    output = {"supported_models": truth["supported_models"].copy(), "assessments": {}}
    for aid, action in truth["actions"].items():
        assessment = {"admissible": action["admissible"], "policy": {}, "worst_regret_tonnes": None}
        output["assessments"][aid] = assessment
        if not action["admissible"]:
            continue
        for bid, branch in action["branches"].items():
            if not branch["possible_models"]:
                report = {"possible_models": [], "plan": "UNREACHABLE", "clairvoyant_tonnes": None}
            else:
                plan = min(branch["safe_plans"], key=lambda p: (-branch["production_by_plan"][p], p))
                report = {"possible_models": branch["possible_models"].copy(), "plan": plan,
                          "clairvoyant_tonnes": branch["clairvoyant_tonnes"]}
            assessment["policy"][bid] = report
    return recompute_regrets(output, truth)


def oracle_control(control, truth, actions):
    prediction = oracle_prediction(truth)
    if not truth["supported_models"]:
        return prediction
    if control == "unconditioned_clairvoyant":
        direct = [a["action_id"] for a in actions if a["measurement"] is None]
        if len(direct) != 1:
            raise ValueError("A unique no-inspection action is required")
        prior = truth["actions"][direct[0]]["branches"]["unobserved"]["clairvoyant_tonnes"]
        for assessment in prediction["assessments"].values():
            for report in assessment["policy"].values():
                if report["possible_models"]:
                    report["clairvoyant_tonnes"] = prior
    else:
        for aid, assessment in prediction["assessments"].items():
            if not assessment["admissible"]:
                continue
            branches = [b for b in truth["actions"][aid]["branches"].values() if b["possible_models"]]
            if control == "always_stop":
                plan = "STOP"
            elif control == "same_prefix_open_loop":
                intersection = set.intersection(*(set(b["safe_plans"]) for b in branches))
                # Output for a given action and plan cannot depend on the bin.
                for candidate in intersection:
                    tonnes = [b["production_by_plan"][candidate] for b in branches]
                    if max(tonnes) - min(tonnes) > 1e-7:
                        raise ValueError("Production was incorrectly conditioned on a reading")
                plan = min(intersection, key=lambda p: (-branches[0]["production_by_plan"][p], p))
            else:
                raise ValueError(control)
            for report in assessment["policy"].values():
                if report["possible_models"]:
                    report["plan"] = plan
    return recompute_regrets(prediction, truth)


def decision_contrasts(truth, actions):
    """Quantify information benefit with the physical prefix held fixed."""
    if not truth["supported_models"]:
        return {"supported": False}
    open_loop = oracle_control("same_prefix_open_loop", truth, actions)
    baseline = oracle_prediction(truth)
    rows = {}
    for aid, action in truth["actions"].items():
        if not action["admissible"]:
            continue
        reachable = {bid: b for bid, b in action["branches"].items() if b["possible_models"]}
        open_regret = open_loop["assessments"][aid]["worst_regret_tonnes"]
        adaptive_regret = action["optimal_regret_tonnes"]
        q = [b["clairvoyant_tonnes"] for b in reachable.values()]
        rows[aid] = {
            "reachable_branches": list(reachable),
            "oracle_branch_plans": {bid: baseline["assessments"][aid]["policy"][bid]["plan"] for bid in reachable},
            "open_loop_plan": next(iter(open_loop["assessments"][aid]["policy"][bid]["plan"] for bid in reachable)),
            "adaptive_regret_tonnes": adaptive_regret,
            "open_loop_regret_tonnes": open_regret,
            "same_prefix_information_benefit_tonnes": open_regret - adaptive_regret,
            "conditional_opportunity_spread_tonnes": max(q) - min(q),
        }
    best_open = min(row["open_loop_regret_tonnes"] for row in rows.values())
    return {"supported": True, "actions": rows,
            "best_open_loop_regret_tonnes": best_open,
            "best_adaptive_regret_tonnes": truth["optimal_regret_tonnes"],
            "global_information_benefit_tonnes": best_open - truth["optimal_regret_tonnes"]}


def physical_worker(args):
    """Separate interpreter prevents one physical mutation affecting another."""
    ref = load_module(args.reference, "ablation_reference")
    if args.control == "shared_as_recalibrated":
        def observation(self, x, aid):
            a, _, _ = self.prefix(x, aid)
            return a
        ref.Model.observation = observation
    elif args.control == "forget_future_memory":
        def prefix(theta, rows, constants, kind, a, zone):
            margin = constants[6] - a
            exponent = theta[5] if kind else 0.0
            for row in rows:
                if row[0] <= 0:
                    continue
                rate, kappa, limit = ref.coefficients(theta, row, constants)
                margin = min(margin, limit - a)
                a, zone = ref.advance(a, a, row[0], rate, theta[2], exponent, kappa, 8.0)
                margin = min(margin, limit - a)
            return a, zone, margin

        def horizon(theta, rows, constants, kind, a, zone, remaining):
            margin = constants[6] - a
            elapsed = 0.0
            exponent = theta[5] if kind else 0.0
            while elapsed < remaining:
                for row in rows:
                    if row[0] <= 0:
                        continue
                    duration = min(row[0], remaining - elapsed)
                    if duration <= 0:
                        return margin
                    rate, kappa, limit = ref.coefficients(theta, row, constants)
                    margin = min(margin, limit - a)
                    a, zone = ref.advance(a, a, duration, rate, theta[2], exponent, kappa, 8.0)
                    margin = min(margin, limit - a)
                    elapsed += duration
            return margin
        ref.run_prefix = prefix
        ref.run_horizon = horizon
    else:
        raise ValueError(args.control)
    prediction, diagnostics = ref.solve_with_diagnostics(args.unit_path, starts=args.starts, full_truth=False)
    result = {"prediction": prediction,
              "original_inference": diagnostics["models"],
              "near_boundary_queries": diagnostics.get("ambiguities", []),
              "solver_seconds": diagnostics["seconds"]}
    Path(args.worker_output).write_text(json.dumps(result, indent=2, allow_nan=False) + "\n")


def run_physical(control, unit_path, args):
    started = time.monotonic()
    with tempfile.TemporaryDirectory(prefix="kiln-ablation-") as temp:
        target = Path(temp) / "prediction.json"
        command = [sys.executable, str(Path(__file__).resolve()), "--worker", "--control", control,
                   "--reference", str(args.reference), "--unit-path", str(unit_path),
                   "--worker-output", str(target), "--starts", str(args.starts)]
        try:
            process = subprocess.run(command, capture_output=True, text=True, timeout=args.timeout)
        except subprocess.TimeoutExpired:
            return {"execution_status": "timeout", "timeout_seconds": args.timeout,
                    "seconds": time.monotonic() - started, "grade": None}
        if process.returncode != 0:
            return {"execution_status": "error", "exit_code": process.returncode,
                    "stderr_tail": process.stderr[-6000:], "grade": None,
                    "seconds": time.monotonic() - started}
        result = read_json(target)
        result.update(execution_status="completed", seconds=time.monotonic() - started)
        return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--bundle", type=Path, default=ROOT)
    parser.add_argument("--data-root", type=Path)
    parser.add_argument("--truth-root", type=Path)
    parser.add_argument("--output", type=Path)
    parser.add_argument("--units", nargs="+", default=[f"unit_{c}" for c in "BCDEFG"])
    parser.add_argument("--controls", nargs="+", choices=ORACLE_CONTROLS + PHYSICAL_CONTROLS,
                        default=list(ORACLE_CONTROLS + PHYSICAL_CONTROLS))
    parser.add_argument("--starts", type=int, default=12)
    parser.add_argument("--timeout", type=float, default=600)
    parser.add_argument("--reference", type=Path)
    parser.add_argument("--worker", action="store_true", help=argparse.SUPPRESS)
    parser.add_argument("--control", choices=PHYSICAL_CONTROLS, help=argparse.SUPPRESS)
    parser.add_argument("--unit-path", type=Path, help=argparse.SUPPRESS)
    parser.add_argument("--worker-output", type=Path, help=argparse.SUPPRESS)
    args = parser.parse_args()
    args.bundle = args.bundle.resolve()
    args.reference = (args.reference or args.bundle / "solution/solve_bearing.py").resolve()
    if args.worker:
        physical_worker(args)
        return
    if args.output is None:
        parser.error("--output is required; choose the evidence report destination explicitly")
    if args.starts < 1 or args.timeout <= 0:
        parser.error("starts and timeout must be positive")
    data_root = (args.data_root or args.bundle / "tests/held_out").resolve()
    truth_root = (args.truth_root or data_root).resolve()
    grader_path = args.bundle / "tests/test_kiln_bearing.py"
    grader = load_module(grader_path, "ablation_grader")
    cases = {}
    for unit in args.units:
        truth = read_json(truth_root / unit / "truth.json")
        validate_truth(truth, unit)
        actions = read_json(data_root / unit / "inspection_options.json")["actions"]
        oracle = oracle_prediction(truth)
        grade = grader.grade_prediction(truth, oracle)
        if not grade["passed"]:
            raise ValueError(f"{unit}: exact safe-plan oracle must pass before controls: {grade['reasons']}")
        cases[unit] = (truth, actions)
    result = {
        "purpose": "Scientific decision ablations; not agent probes or trajectory replays",
        "settings": {"starts": args.starts, "per_physical_control_timeout_seconds": args.timeout},
        "source_sha256": {"run_ablations.py": digest(__file__), "solve_bearing.py": digest(args.reference),
                          "test_kiln_bearing.py": digest(grader_path)},
        "input_sha256": {unit: {p.name: digest(p) for p in sorted((data_root / unit).iterdir())
                                if p.is_file() and p.suffix in (".csv", ".json")}
                         for unit in args.units},
        "truth_sha256": {unit: digest(truth_root / unit / "truth.json") for unit in args.units},
        "oracle_self_check": {unit: True for unit in args.units},
        "decision_contrasts": {unit: decision_contrasts(*cases[unit]) for unit in args.units},
        "controls": {},
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    for control in args.controls:
        rows = {}
        for unit, (truth, actions) in cases.items():
            if control in ORACLE_CONTROLS:
                record = {"execution_status": "completed", "prediction": oracle_control(control, truth, actions)}
            else:
                record = run_physical(control, data_root / unit, args)
            if record["execution_status"] == "completed":
                record["grade"] = grader.grade_prediction(truth, record["prediction"])
                record["original_support_preserved"] = sorted(record["prediction"]["supported_models"]) == sorted(truth["supported_models"])
                # An infrastructure error or a changed original support is not
                # evidence that the intended future assumption discriminates.
                record["interpretable_scientific_control"] = record["original_support_preserved"]
            else:
                record["interpretable_scientific_control"] = False
            rows[unit] = record
            print(f"{control} {unit}: " + (str(record["grade"]["passed"]) if record.get("grade") is not None else record["execution_status"]), flush=True)
        complete = all(row["execution_status"] == "completed" for row in rows.values())
        n_pass = sum(bool(row.get("grade", {}) and row["grade"]["passed"]) for row in rows.values())
        result["controls"][control] = {
            "description": DESCRIPTIONS[control], "per_unit": rows,
            "completed": complete, "n_pass": n_pass, "n_total": len(rows),
            "binary_reward": float(n_pass == len(rows)) if complete else None,
            "n_interpretable_scientific_failures": sum(row["interpretable_scientific_control"] and not row["grade"]["passed"] for row in rows.values()),
        }
        args.output.write_text(json.dumps(result, indent=2, allow_nan=False) + "\n")


if __name__ == "__main__":
    main()
