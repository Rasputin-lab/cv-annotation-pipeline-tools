#!/usr/bin/env python3
"""Recompute complete policy assessments and compare independent numerical methods."""
import argparse,hashlib,importlib.util,json,os,time
from pathlib import Path
os.environ.setdefault('OPENBLAS_NUM_THREADS','1')
os.environ.setdefault('OMP_NUM_THREADS','1')
ROOT=Path(__file__).resolve().parents[2]
def module(name,path):
 spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def same_truth(left,right):
 errors=[]
 if left['supported_models']!=right['supported_models']:errors.append('original support')
 if set(left['actions'])!=set(right['actions']):return ['action set']
 for aid,a in left['actions'].items():
  b=right['actions'][aid]
  if a['admissible']!=b['admissible']:errors.append(aid+': prefix admissibility');continue
  if not a['admissible']:continue
  if set(a['branches'])!=set(b['branches']):errors.append(aid+': branch set');continue
  for bid,x in a['branches'].items():
   y=b['branches'][bid]
   for field in ['possible_models','safe_plans']:
    if sorted(x[field])!=sorted(y[field]):errors.append(aid+'/'+bid+': '+field)
   for field in ['clairvoyant_tonnes']:
    if x[field]!=y[field] and (x[field] is None or y[field] is None or abs(x[field]-y[field])>1e-6):errors.append(aid+'/'+bid+': '+field)
   if x['production_by_plan']!=y['production_by_plan']:errors.append(aid+'/'+bid+': production')
  if abs(a['optimal_regret_tonnes']-b['optimal_regret_tonnes'])>1e-6:errors.append(aid+': regret')
 if left['optimal_regret_tonnes']!=right['optimal_regret_tonnes']:
  if left['optimal_regret_tonnes'] is None or right['optimal_regret_tonnes'] is None or abs(left['optimal_regret_tonnes']-right['optimal_regret_tonnes'])>1e-6:errors.append('global regret')
 if set(left['acceptable_actions'])!=set(right['acceptable_actions']):errors.append('optimal action set')
 return errors

def main():
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--data-root',type=Path);p.add_argument('--output',type=Path,default=Path(__file__).with_name('fixed_assessments.json'));p.add_argument('--write-truth',action='store_true');p.add_argument('--units',default='ABCDEFG');p.add_argument('--reference-starts',type=int,default=12);a=p.parse_args()
 refpath=ROOT/'solution/solve_bearing.py';indpath=Path(__file__).with_name('independent_solver.py');gradepath=ROOT/'tests/test_kiln_bearing.py'
 ref=module('reference',refpath);ind=module('independent',indpath);gr=module('grader',gradepath)
 out={'purpose':'Independent numerical validation, not a global optimization certificate or frontier-agent probe','source_sha256':{str(x.relative_to(ROOT)):digest(x) for x in [Path(__file__),refpath,indpath,gradepath]},'units':{}}
 for letter in a.units:
  name='unit_'+letter;path=a.data_root/name if a.data_root else ROOT/('environment/data' if letter=='A' else 'tests/held_out')/name
  print('Checking',name,flush=True)
  pred,diag=ref.solve_with_diagnostics(path,starts=a.reference_starts,full_truth=True)
  independent,other=ind.solve_unit_with_diagnostics(path,full_truth=True)
  truth=diag['truth'];errors=same_truth(truth,other['truth']);rg=gr.grade_prediction(truth,pred);ig=gr.grade_prediction(truth,independent)
  row={'input_sha256':{q.name:digest(q) for q in sorted(path.iterdir()) if q.is_file() and q.name!='truth.json'},'reference':{'prediction':pred,'diagnostics':diag},'independent':{'prediction':independent,'diagnostics':other},'truth_differences':errors,'reference_grade':rg,'independent_grade':ig}
  row['passed']=not errors and rg['passed'] and ig['passed'] and not diag['ambiguities'] and not other['ambiguities'];out['units'][name]=row
  if a.write_truth and row['passed'] and letter!='A':(path/'truth.json').write_text(json.dumps(truth,indent=2)+'\n')
  out['passed']=all(v['passed'] for v in out['units'].values());a.output.parent.mkdir(parents=True,exist_ok=True);a.output.write_text(json.dumps(out,indent=2,allow_nan=False)+'\n')
  print(name,row['passed'],'reference seconds',round(diag['seconds'],2),'independent seconds',round(other['seconds'],2),'differences',errors,flush=True)
 if not out['passed']:raise SystemExit(1)
if __name__=='__main__':main()
