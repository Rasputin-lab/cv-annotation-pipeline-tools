#!/usr/bin/env python3
"""Independent conditional inspection-policy assessment.

Imports no reference, target, or generator. Physical propagation uses adaptive
RK4 in log crack depth, independently initialized constrained inference, and
actual/counterfactual intersection searches over a common specimen vector.
"""
import os
os.environ.setdefault('OPENBLAS_NUM_THREADS','1')
import csv,json,math,sys,time
from pathlib import Path
import numpy as np
from numba import njit
from scipy.optimize import minimize
from scipy.stats import qmc

@njit
def slope(u,Z,k,B,m,p):
 a=math.exp(min(u,5.));ratio=1.
 if p>0 and a*(1+k)<Z:ratio=(k*a/(Z-a))**p
 return B*a**(m/2-1)*ratio

@njit
def rkstep(u,dt,Z,k,B,m,p):
 k1=slope(u,Z,k,B,m,p);k2=slope(u+dt*k1/2,Z,k,B,m,p);k3=slope(u+dt*k2/2,Z,k,B,m,p);k4=slope(u+dt*k3,Z,k,B,m,p)
 return u+dt*(k1+2*k2+2*k3+k4)/6

@njit
def integrate(a,Z,dt,k,B,m,p,limit,tol=2e-10):
 if dt<=0:return a,Z,0.,False
 Z=max(Z,a*(1+k))
 if a>=limit:return a,Z,0.,True
 u=math.log(a);elapsed=0.;h=max(dt/4,1e-8)
 for it in range(3000):
  if elapsed>=dt-1e-13:return math.exp(u),max(Z,math.exp(u)*(1+k)),dt,False
  a=math.exp(u);velocity=slope(u,Z,k,B,m,p)
  if limit-a<2e-10:
   extra=(math.log(limit)-u)/max(velocity,1e-300)
   if elapsed+extra<=dt:return limit,max(Z,limit*(1+k)),elapsed+extra,True
  h=min(h,dt-elapsed,.8*(math.log(limit)-u)/max(velocity,1e-300))
  if h<1e-13:return min(limit,a),max(Z,a*(1+k)),elapsed,a>=limit-1e-9
  one=rkstep(u,h,Z,k,B,m,p);half=rkstep(u,h/2,Z,k,B,m,p);two=rkstep(half,h/2,Z,k,B,m,p)
  err=abs(two-one)/15
  if err<=tol:
   u=two+(two-one)/15;elapsed+=h
  factor=2. if err==0 else min(2.,max(.2,.9*(tol/err)**.2))
  h*=factor
 raise RuntimeError("Adaptive crack integrator exhausted its step budget")

@njit
def dynamics(t,row,c):
 a,logv,m,g,res,p,bias=t
 Y,Kref,yieldstress,alpha,count,limitK,maxa=c
 Kmax_factor=Y*(row[3]+res)*math.sqrt(math.pi*.001)
 R=(row[2]+res)/(row[3]+res)
 B=1000*math.exp(logv)*count*row[1]*(Kmax_factor*(1-R)**g/Kref)**m
 zone=Kmax_factor*Kmax_factor/(alpha*math.pi*.001*yieldstress*yieldstress)
 failure=min(maxa,(limitK/Kmax_factor)**2)
 return B,zone,failure

@njit
def history(t,rows,c,kind):
 a=t[0];Z=a;out=np.empty(len(rows));shape=t[5] if kind else 0.
 for j in range(len(rows)):
  # A zero-duration initial row is a reading, not an applied load.
  if rows[j,0]>0:
   B,k,_=dynamics(t,rows[j],c)
   a,Z,elapsed,hit=integrate(a,Z,rows[j,0],k,B,t[2],shape,8.)
  out[j]=a+t[6]
 return out,a,Z

@njit
def margin_at(t,rows,c,kind,a,Z,horizon):
 hours=0.;shape=t[5] if kind else 0.;margin=c[6]-a
 for repeat in range(10000):
  for j in range(len(rows)):
   if hours>=horizon:return margin
   if rows[j,0]<=0:continue
   B,k,limit=dynamics(t,rows[j],c);margin=min(margin,limit-a)
   duration=min(rows[j,0],horizon-hours)
   a,Z,elapsed,hit=integrate(a,Z,duration,k,B,t[2],shape,8.)
   hours+=duration;margin=min(margin,limit-a)
 raise RuntimeError("Future-duty propagation exhausted its repeat budget")


@njit
def prefix_state(t,rows,c,kind,a,Z):
 """One ordered prefix, without repeating it; inspection causes no growth."""
 shape=t[5] if kind else 0.;margin=c[6]-a
 for j in range(len(rows)):
  if rows[j,0]<=0:continue
  B,k,limit=dynamics(t,rows[j],c);margin=min(margin,limit-a)
  a,Z,elapsed,hit=integrate(a,Z,rows[j,0],k,B,t[2],shape,8.)
  margin=min(margin,limit-a)
 return a,Z,margin


FEASIBILITY_TOL=4e-7
SAFETY_AMBIGUITY_MM=3e-7
SEARCH_STARTS=7


class Assessment:
 def __init__(self,path,kind):
  p=Path(path);self.s=json.loads((p/'bearing_spec.json').read_text());self.kind=kind
  def read(name):
   with (p/name).open() as f:return list(csv.DictReader(f))
  def array(rows,cols):return np.array([[float(r[k]) for k in cols] for r in rows])
  h=read('history.csv');cols=['duration_hours','kiln_rpm','stress_min_mpa','stress_max_mpa'];self.h=array(h,cols);self.intervals=array(h,['reading_lower_mm','reading_upper_mm'])
  self.coupon=array(read('coupon_growth.csv'),['delta_k_mpa_sqrt_m','stress_ratio','rate_lower_m_per_cycle','rate_upper_m_per_cycle'])
  self.cal=array(read('depth_calibration.csv'),['certified_depth_mm','reading_lower_mm','reading_upper_mm'])
  self.plans={}
  for row in read('future_duty.csv'):self.plans.setdefault(row['plan_id'],[]).append(row)
  for rows in self.plans.values():rows.sort(key=lambda r:int(r['block_index']))
  self.future={k:array(v,cols) for k,v in self.plans.items()}
  g=self.s['bearing_geometry'];geo=self.s['crack_geometry'];mat=self.s['material']
  ratio=.5*(1-g['element_diameter_mm']/g['pitch_diameter_mm']*math.cos(g['contact_angle_deg']*math.pi/180))
  count=60*g['rolling_elements']*ratio*g['kiln_tyre_diameter_m']/g['support_roller_diameter_m']
  self.constants=np.array([geo['mode_I_factor'],mat['reference_delta_k_mpa_sqrt_m'],mat['yield_strength_mpa'],mat['plastic_zone_denominator'],count,mat['service_k_mpa_sqrt_m'],geo['maximum_assessed_crack_mm']])
  keys=['initial_crack_mm','reference_growth_m_per_cycle','paris_exponent','walker_gamma','residual_stress_mpa','wheeler_exponent','depth_bias_mm'];bounds=np.array([self.s['bounds'][k] for k in keys],float);bounds[1]=np.log(bounds[1]);self.low=bounds[:,0];self.width=bounds[:,1]-bounds[:,0]
  self.bounds=[(0.,1.)]*7
  if not kind:self.bounds[5]=(.5,.5)
  self.cache={};self.seeds=[];self.prefix_cache={};self.strategy_cache={}
  self.actions={}
  for action in json.loads((p/'inspection_options.json').read_text())['actions']:
   aid=action['action_id'];item=dict(action)
   item['rows']=array(action['blocks'],cols).reshape((-1,4))
   item['elapsed']=sum(float(r['duration_hours']) for r in action['blocks'])+float(action['downtime_hours'])
   item['prefix_tonnes']=sum(float(r['duration_hours'])*float(r['production_tonnes_per_hour']) for r in action['blocks'])
   self.actions[aid]=item
  self.H=float(self.s['shutdown_hours'])
 def theta(self,x):return self.low+x*self.width
 def propagate(self,x):
  key=tuple(x)
  if key not in self.cache:
   if len(self.cache)>100:self.cache.clear()
   self.cache[key]=history(self.theta(x),self.h,self.constants,self.kind)
  return self.cache[key]
 def constraints(self,x):
  t=self.theta(x);a,_,_=self.propagate(x);c=self.coupon
  growth=t[1]+t[2]*(np.log(c[:,0]/self.constants[1])-(1-t[3])*np.log1p(-c[:,1]))
  bias_read=self.cal[:,0]+t[6]
  # The campaign continued running through every observed block. Crack growth
  # is monotone within a fixed-load block, so its endpoint also checks its peak
  # service allowance. Subtract the shared measurement bias before testing.
  physical_depth=a-t[6]
  historical_limits=np.array([dynamics(t,row,self.constants)[2] if row[0]>0 else self.constants[6] for row in self.h])
  return np.r_[(a-self.intervals[:,0])/.01,(self.intervals[:,1]-a)/.01,growth-np.log(c[:,2]),np.log(c[:,3])-growth,(bias_read-self.cal[:,1])/.01,(self.cal[:,2]-bias_read)/.01,(historical_limits-physical_depth)/.01]
 def fit(self,count=16):
  c=self.coupon
  regressors=np.array([[1.,math.log(row[0]/self.constants[1]),-math.log1p(-row[1])] for row in c])
  beta=np.linalg.lstsq(regressors,np.log(np.sqrt(c[:,2]*c[:,3])),rcond=None)[0]
  bias=np.median((self.cal[:,1]+self.cal[:,2])/2-self.cal[:,0]);theta=(self.low+self.low+self.width)/2
  theta[0]=np.mean(self.intervals[0])-bias;theta[1:4]=[beta[0],beta[1],1-beta[2]/beta[1]];theta[6]=bias
  guess=np.clip((theta-self.low)/self.width,.001,.999);points=qmc.Sobol(3,scramble=True,seed=827).random_base2(int(math.ceil(math.log2(count))))
  best=1e99
  for point in points:
   x=guess.copy();x[4:6]=point[:2];x[6]=np.clip(x[6]+.15*(point[2]-.5),0,1)
   if not self.kind:x[5]=.5
   opt=minimize(lambda z:np.dot(np.minimum(self.constraints(z),0),np.minimum(self.constraints(z),0)),x,method='SLSQP',bounds=self.bounds,options={'maxiter':230,'ftol':1e-15})
   violation=max(0.,-float(min(self.constraints(opt.x))));best=min(best,violation)
   if violation<4e-7:self.seeds.append(opt.x)
  return best

 def prefix(self,x,aid):
  key=(aid,tuple(x))
  if key not in self.prefix_cache:
   if len(self.prefix_cache)>320:self.prefix_cache.clear()
   _,a,Z=self.propagate(x)
   self.prefix_cache[key]=prefix_state(self.theta(x),self.actions[aid]['rows'],self.constants,self.kind,a,Z)
  return self.prefix_cache[key]

 def clearance(self,x,aid,plan):
  key=(aid,plan,tuple(x))
  if key not in self.strategy_cache:
   if len(self.strategy_cache)>320:self.strategy_cache.clear()
   a,Z,margin=self.prefix(x,aid)
   if plan!='STOP':
    margin=min(margin,margin_at(self.theta(x),self.future[plan],self.constants,self.kind,a,Z,self.H-self.actions[aid]['elapsed']))
   self.strategy_cache[key]=float(margin)
  return self.strategy_cache[key]

 def conditional_constraints(self,x,aid,bin_record):
  prior=self.constraints(x)
  if bin_record is None:return prior
  action=self.actions[aid];measurement=action['measurement']
  a,_,_=self.prefix(x,aid)
  centre=a+(self.theta(x)[6] if measurement['bias_mode']=='shared' else 0.)
  err=float(measurement['absolute_error_mm'])
  return np.r_[prior,(centre+err-float(bin_record['lower_mm']))/.01,(float(bin_record['upper_mm'])-centre+err)/.01]


def diverse(points,limit):
 """Retain spread in normalized physical coordinates, not just last fits."""
 if not points:return []
 unique=[]
 for point in points:
  z=np.asarray(point,float)
  if not any(np.linalg.norm(z-p)<1e-5 for p in unique):unique.append(z.copy())
 if len(unique)<=limit:return unique
 chosen=[unique[0]]
 for _ in range(limit-1):
  chosen.append(max(unique,key=lambda z:min(float(np.linalg.norm(z-p)) for p in chosen)))
 return chosen


class ConditionalDomain:
 """An original or inspection-conditioned joint explanation set."""
 def __init__(self,model,aid=None,bin_record=None):
  self.model=model;self.aid=aid;self.bin=bin_record;self.points=[];self.best_violation=float('inf');self.searches=[]
  self.fun=(model.constraints if aid is None or bin_record is None else lambda x:model.conditional_constraints(x,aid,bin_record))
  for x in model.seeds:
   violation=max(0.,-float(min(self.fun(x))));self.best_violation=min(self.best_violation,violation)
   if violation<=FEASIBILITY_TOL:self.points.append(x.copy())
  if bin_record is not None:
   # Restore the complete branch constraints, even if one original fit happens
   # to lie in the bin. Extra starts keep distinct physical explanations alive.
   for x in diverse(model.seeds,SEARCH_STARTS):
    result=minimize(lambda z:float(np.dot(np.minimum(self.fun(z),0),np.minimum(self.fun(z),0))),x,method='SLSQP',bounds=model.bounds,options={'maxiter':160,'ftol':1e-15,'eps':5e-7})
    violation=max(0.,-float(min(self.fun(result.x))));self.best_violation=min(self.best_violation,violation)
    if violation<=FEASIBILITY_TOL:self.points.append(result.x.copy())
   if not self.points:
    # A squared violation objective becomes almost flat near a narrow feasible
    # intersection. Solve a distinct Phase-I problem before declaring a bin
    # unreachable: minimize one nonnegative slack on ALL joint constraints.
    # A zero-slack point is checked against the original, unrelaxed bounds.
    for x in diverse(model.seeds,SEARCH_STARTS):
     slack=max(0.,-float(min(self.fun(x))))
     result=minimize(lambda y:float(y[-1]),np.r_[x,slack+1e-8],
      method='SLSQP',bounds=model.bounds+[(0.,None)],
      constraints={'type':'ineq','fun':lambda y:self.fun(y[:-1])+y[-1]},
      options={'maxiter':250,'ftol':1e-12,'eps':1e-7})
     candidate=result.x[:-1]
     violation=max(0.,-float(min(self.fun(candidate))));self.best_violation=min(self.best_violation,violation)
     if violation<=FEASIBILITY_TOL:self.points.append(candidate.copy())
  self.points=diverse(self.points,14)

 def witness(self,x,margin):
  return {'theta':self.model.theta(x).tolist(),'normalized_coordinates':np.asarray(x).tolist(),'clearance_mm':float(margin),'max_constraint_violation':max(0.,-float(min(self.fun(x))))}

 def extremum(self,aid,plan,maximize=False):
  """Search clearance. One strict positive/negative witness can prove an
  existential success/universal failure; the opposite outcome needs all starts.
  This is reproducible multistart numerical evidence, not a global certificate.
  """
  if not self.points:raise ValueError('Cannot optimize an empty branch')
  fn=lambda x:self.model.clearance(x,aid,plan)
  sign=-1. if maximize else 1.
  candidates=list(self.points);vals=[fn(x) for x in candidates]
  index=min(range(len(vals)),key=lambda j:sign*vals[j]);winner=candidates[index];best=vals[index]
  conclusive=(best>SAFETY_AMBIGUITY_MM if maximize else best<-SAFETY_AMBIGUITY_MM)
  attempts=0;statuses=[]
  if not conclusive:
   ordered=sorted(candidates,key=lambda z:sign*fn(z))
   starts=diverse([ordered[0]]+candidates,SEARCH_STARTS)
   for initial in starts:
    opt=minimize(lambda z:sign*fn(z),initial,method='SLSQP',bounds=self.model.bounds,constraints={'type':'ineq','fun':self.fun},options={'maxiter':180,'ftol':8e-12,'eps':5e-7})
    attempts+=1;statuses.append(int(opt.status))
    if min(self.fun(opt.x))>=-FEASIBILITY_TOL:
     value=fn(opt.x)
     if sign*value<sign*best:winner=opt.x.copy();best=value
     candidates.append(opt.x.copy())
    if (best>SAFETY_AMBIGUITY_MM if maximize else best<-SAFETY_AMBIGUITY_MM):break
  self.points=diverse([winner]+candidates,16)
  result={'maximize':bool(maximize),'action':aid,'plan':plan,'witness':self.witness(winner,best),'optimizer_attempts':attempts,'optimizer_statuses':statuses,'near_safety_boundary':abs(best)<=SAFETY_AMBIGUITY_MM}
  self.searches.append(result)
  return float(best),result


def produced(model,aid,plan):
 action=model.actions[aid];total=action['prefix_tonnes']
 if plan=='STOP':return float(total)
 horizon=model.H-action['elapsed'];rows=model.plans[plan]
 period=sum(float(r['duration_hours']) for r in rows)
 full=int(horizon//period);left=horizon-full*period
 total+=full*sum(float(r['duration_hours'])*float(r['production_tonnes_per_hour']) for r in rows)
 for row in rows:
  h=min(left,float(row['duration_hours']));total+=h*float(row['production_tonnes_per_hour']);left-=h
  if left<=0:break
 return float(total)


def solve_unit_with_diagnostics(path,full_truth=False):
 begin=time.monotonic();models={};diags={};ambiguities=[]
 for kind,name in [(0,'walker'),(1,'wheeler')]:
  model=Assessment(path,kind);bad=model.fit()
  diags[name]={'best_violation':bad,'feasible_starts':len(model.seeds)}
  if model.seeds:models[name]=model
 if not models:
  diagnostics={'seconds':time.monotonic()-begin,'models':diags,'ambiguities':[]}
  if full_truth:diagnostics['truth']={'supported_models':[],'actions':{},'optimal_regret_tonnes':None,'acceptable_actions':[]}
  return {'supported_models':[],'assessments':{},'recommended_action':'UNSUPPORTED'},diagnostics
 exemplar=next(iter(models.values()))
 originals={name:ConditionalDomain(m) for name,m in models.items()}
 alternatives=sorted([(produced(exemplar,aid,p),aid,p) for aid in exemplar.actions for p in ['STOP']+sorted(exemplar.plans)],key=lambda item:(-item[0],item[1],item[2]))
 assessments={};action_diags={};truth_actions={}
 for aid,action in exemplar.actions.items():
  detail={'prefix':{},'branches':{}};admissible=True
  for name,domain in originals.items():
   value,result=domain.extremum(aid,'STOP')
   detail['prefix'][name]=result
   if abs(value)<=SAFETY_AMBIGUITY_MM:ambiguities.append({'type':'prefix_safety','action':aid,'model':name,'margin_mm':value})
   if value<=0:admissible=False
  if not admissible:
   assessments[aid]={'admissible':False,'policy':{},'worst_regret_tonnes':None};action_diags[aid]=detail
   truth_actions[aid]={'admissible':False,'branches':{},'optimal_regret_tonnes':None}
   continue
  bins=action['measurement']['bins'] if action['measurement'] is not None else [None]
  policy={};regrets=[];truth_branches={}
  for record in bins:
   bid=record['bin_id'] if record is not None else 'unobserved'
   domains={};branch_detail={'support':{},'continuation_checks':{},'comparator_checks':[]}
   for name,local in models.items():
    domain=ConditionalDomain(local,aid,record) if record is not None else originals[name]
    branch_detail['support'][name]={'best_violation':domain.best_violation,'feasible_starts':len(domain.points),'witness':domain.witness(domain.points[0],local.clearance(domain.points[0],aid,'STOP')) if domain.points else None}
    if domain.points:domains[name]=domain
   if not domains:
    policy[bid]={'possible_models':[],'plan':'UNREACHABLE','clairvoyant_tonnes':None};detail['branches'][bid]=branch_detail
    truth_branches[bid]={'possible_models':[],'safe_plans':[],'clairvoyant_tonnes':None,'production_by_plan':{}}
    continue
   ordered=sorted(['STOP']+list(exemplar.plans),key=lambda p:(-produced(exemplar,aid,p),p))
   chosen=None;safe_plans=[]
   for plan in ordered:
    safe=True;checks={}
    for name,domain in domains.items():
     value,result=domain.extremum(aid,plan);checks[name]=result
     if abs(value)<=SAFETY_AMBIGUITY_MM:ambiguities.append({'type':'branch_safety','action':aid,'bin':bid,'plan':plan,'model':name,'margin_mm':value})
     if value<=0:safe=False;break
    branch_detail['continuation_checks'][plan]=checks
    if safe:
     safe_plans.append(plan)
     if chosen is None:chosen=plan
     if not full_truth:break
   if chosen is None:raise RuntimeError('An admissible prefix must allow immediate STOP')
   opportunity=None;opportunity_witness=None
   for tonnes,other_action,other_plan in alternatives:
    found=False;check={'action':other_action,'plan':other_plan,'production_tonnes':tonnes,'models':{}}
    for name,domain in domains.items():
     value,result=domain.extremum(other_action,other_plan,maximize=True);check['models'][name]=result
     if abs(value)<=SAFETY_AMBIGUITY_MM:ambiguities.append({'type':'comparator_intersection','action':aid,'bin':bid,'counterfactual_action':other_action,'counterfactual_plan':other_plan,'model':name,'margin_mm':value})
     if value>0:found=True;opportunity_witness={'model':name,**result};break
    branch_detail['comparator_checks'].append(check)
    if found:opportunity=tonnes;break
   if opportunity is None:raise RuntimeError('No feasible clairvoyant alternative, despite feasible branch')
   actual=produced(exemplar,aid,chosen);regret=opportunity-actual
   if regret<-1e-5:raise RuntimeError('Clairvoyant opportunity smaller than a universally safe chosen policy')
   policy[bid]={'possible_models':sorted(domains),'plan':chosen,'clairvoyant_tonnes':float(opportunity)}
   truth_branches[bid]={'possible_models':sorted(domains),'safe_plans':sorted(safe_plans),'clairvoyant_tonnes':float(opportunity),'production_by_plan':{p:produced(exemplar,aid,p) for p in ordered}}
   regrets.append(max(0.,regret));branch_detail['chosen_production_tonnes']=actual;branch_detail['regret_tonnes']=float(regret);branch_detail['opportunity_witness']=opportunity_witness
   detail['branches'][bid]=branch_detail
  if not regrets:raise RuntimeError('Supplied measurement bins do not cover the compatible action states')
  assessments[aid]={'admissible':True,'policy':policy,'worst_regret_tonnes':float(max(regrets))};action_diags[aid]=detail
  truth_actions[aid]={'admissible':True,'branches':truth_branches,'optimal_regret_tonnes':float(max(regrets))}
 best=min((a for a in assessments if assessments[a]['admissible']),key=lambda a:(assessments[a]['worst_regret_tonnes'],a))
 output={'supported_models':sorted(models),'assessments':assessments,'recommended_action':best}
 diagnostics={'models':diags,'actions':action_diags,'seconds':time.monotonic()-begin,'ambiguities':ambiguities,'numerical_method':'Independent log-depth adaptive RK4 and deterministic Sobol-initialized SLSQP; multistart evidence, not a global-optimality proof.'}
 if full_truth:
  optimum=assessments[best]['worst_regret_tonnes']
  diagnostics['truth']={'supported_models':sorted(models),'actions':truth_actions,'optimal_regret_tonnes':optimum,'acceptable_actions':sorted(a for a,t in truth_actions.items() if t['admissible'] and t['optimal_regret_tonnes']<=optimum+1.)}
 return output,diagnostics


def solve_unit(path):return solve_unit_with_diagnostics(path)[0]


if __name__=='__main__':print(json.dumps(solve_unit(sys.argv[1]),allow_nan=False))
