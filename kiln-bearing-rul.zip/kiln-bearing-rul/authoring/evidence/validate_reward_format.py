#!/usr/bin/env python3
"""Validate literal binary reward writes without repeating physical searches.

Historical evidence is retained byte for byte. Saved predictions are graded with
the current implementation, and its complete writer is exercised in temporary
output directories. No synthetic inputs, private targets or solver are changed.
"""
import ast
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import runpy
import sys
import tempfile

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parents[2]
EVIDENCE = ROOT / "authoring/evidence"
OLD_GRADER_SHA256 = "aa26538994818e27ce5216a36ad679fb6bdbe589d5c010631acadfa25c8cd493"
UNCHANGED_GRADING_PREFIX_SHA256 = "6ad2ffa0a0d33ed1e4e60c89a521f856fb732e7753f81ee56bcbe9fee2779d24"
HISTORICAL_REPORTS = (
    "fixed_assessments.json", "search_stability.json", "ablation_results.json",
    "opportunity_control.json", "container_validation.json",
    "scientific_validation.json", "branch_margins.json",
    "grader_semantic_results.json", "self_cheat_read_truth_direct_metrics.json",
    "self_cheat_read_truth_direct_reward.txt",
)


def sha256(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read_report(name):
    return json.loads((EVIDENCE / name).read_text())


def dump_ast(node):
    return ast.dump(node, include_attributes=False)


def main():
    before = {name: sha256(EVIDENCE / name) for name in HISTORICAL_REPORTS}
    grader_path = ROOT / "tests/test_kiln_bearing.py"
    grader_bytes = grader_path.read_bytes()
    prefix = grader_bytes.split(b"def test_conditional_inspection_policies():", 1)[0]
    prefix_hash = hashlib.sha256(prefix).hexdigest()
    assert prefix_hash == UNCHANGED_GRADING_PREFIX_SHA256, "scientific grading prefix changed"

    tree = ast.parse(grader_bytes.decode())
    entry = next(node for node in tree.body if isinstance(node, ast.FunctionDef)
                 and node.name == "test_conditional_inspection_policies")
    expected_assignment = ast.parse("reward = 1 if n_pass == len(UNIT_NAMES) else 0").body[0]
    assignments = [node for node in entry.body if isinstance(node, ast.Assign)
                   and any(isinstance(target, ast.Name) and target.id == "reward"
                           for target in node.targets)]
    assert len(assignments) == 1 and dump_ast(assignments[0]) == dump_ast(expected_assignment)
    expected_writer = ast.parse(
        'if reward == 1:\n'
        '    (verifier / "reward.txt").write_text("1\\n")\n'
        'else:\n'
        '    (verifier / "reward.txt").write_text("0\\n")\n'
    ).body[0]
    branches = [node for node in entry.body if isinstance(node, ast.If)
                and dump_ast(node) == dump_ast(expected_writer)]
    assert len(branches) == 1, "reward writer must have two explicit literal branches"
    reward_calls = [node for node in ast.walk(entry) if isinstance(node, ast.Call)
                    and isinstance(node.func, ast.Attribute) and node.func.attr == "write_text"
                    and isinstance(node.func.value, ast.BinOp)
                    and isinstance(node.func.value.right, ast.Constant)
                    and node.func.value.right.value == "reward.txt"]
    assert len(reward_calls) == 2
    assert sorted(node.args[0].value for node in reward_calls) == ["0\n", "1\n"]

    spec = importlib.util.spec_from_file_location("current_reward_grader", grader_path)
    grader = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(grader)
    fixed = read_report("fixed_assessments.json")
    truth_by_unit = {}
    truth_hashes = {}
    for unit, row in fixed["units"].items():
        truth = row["reference"]["diagnostics"]["truth"]
        if unit in grader.UNIT_NAMES:
            path = ROOT / "tests/held_out" / unit / "truth.json"
            assert json.loads(path.read_text()) == truth, (unit, "private target differs")
            truth_hashes[str(path.relative_to(ROOT))] = sha256(path)
        truth_by_unit[unit] = truth

    input_hashes = {}
    for unit in truth_by_unit:
        directory = (ROOT / "environment/data" / unit if unit == "unit_A"
                     else ROOT / "tests/held_out" / unit)
        for path in sorted(directory.iterdir()):
            if path.is_file() and path.name != "truth.json":
                input_hashes[str(path.relative_to(ROOT))] = sha256(path)

    checks = []

    def regrade(label, unit, prediction, expected, truth=None):
        actual = grader.grade_prediction(truth_by_unit[unit] if truth is None else truth, prediction)
        assert actual == expected, (label, unit, "saved semantic grade changed", actual, expected)
        checks.append({"record": label, "unit": unit, "passed": actual["passed"],
                       "complete_saved_grade_matches": True})

    for unit, row in fixed["units"].items():
        for implementation in ("reference", "independent"):
            regrade("fixed/" + implementation, unit, row[implementation]["prediction"],
                    row[implementation + "_grade"])

    search = read_report("search_stability.json")
    for unit, row in search["units"].items():
        regrade("additional_seed/independent", unit, row["prediction"],
                row["comparison"]["alternate_prediction_reference_grade"])
        regrade("additional_seed/reference_on_independent_truth", unit,
                fixed["units"][unit]["reference"]["prediction"],
                row["comparison"]["reference_prediction_alternate_grade"],
                row["diagnostics"]["truth"])

    ablations = read_report("ablation_results.json")
    for control, rows in ablations["controls"].items():
        for unit, row in rows["per_unit"].items():
            assert row["execution_status"] == "completed", (control, unit)
            regrade("ablation/" + control, unit, row["prediction"], row["grade"])

    opportunity = read_report("opportunity_control.json")
    for unit, row in opportunity["units"].items():
        for name in ("oracle_baseline", "unchanged_reference", "control"):
            if name + "_prediction" in row:
                regrade("opportunity/" + name, unit, row[name + "_prediction"], row[name + "_grade"])

    # This producer deterministically rewrites the existing report. Confirm the
    # complete 51-case result is byte-identical rather than updating provenance.
    runpy.run_path(str(EVIDENCE / "validate_grader.py"), run_name="__main__")
    semantic = read_report("grader_semantic_results.json")
    assert semantic["passed"] == 51 and semantic["failed"] == 0
    assert sha256(EVIDENCE / "grader_semantic_results.json") == before["grader_semantic_results.json"]

    writer_results = []
    old_path = grader.Path
    env_key = "KILN_PREDICTION_DIR"
    old_prediction_directory = os.environ.get(env_key)
    with tempfile.TemporaryDirectory(prefix="kiln-reward-write-") as temporary:
        temporary_root = Path(temporary)
        try:
            for name, expected_passes in (("all_correct", 6), ("one_incorrect", 5), ("all_incorrect", 0)):
                case = temporary_root / name
                predictions = case / "predictions"
                predictions.mkdir(parents=True)
                for index, unit in enumerate(grader.UNIT_NAMES):
                    prediction = fixed["units"][unit]["reference"]["prediction"]
                    if name == "all_incorrect" or (name == "one_incorrect" and index == 0):
                        prediction = {}
                    (predictions / (unit + ".json")).write_text(json.dumps(prediction) + "\n")

                # Only output roots are redirected. __file__, private answers,
                # all reads and the complete grading entry point stay intact.
                def redirected_path(value, *args):
                    if str(value) == "/root/results":
                        return case / "results"
                    if str(value) == "/logs/verifier":
                        return case / "verifier"
                    return old_path(value, *args)

                grader.Path = redirected_path
                os.environ[env_key] = str(predictions)
                assertion_raised = False
                try:
                    grader.test_conditional_inspection_policies()
                except AssertionError:
                    assertion_raised = True
                reward_bytes = (case / "verifier/reward.txt").read_bytes()
                metrics = json.loads((case / "results/metrics.json").read_text())
                expected_reward = 1 if expected_passes == len(grader.UNIT_NAMES) else 0
                assert reward_bytes == (b"1\n" if expected_reward == 1 else b"0\n"), name
                assert metrics["n_pass"] == expected_passes and metrics["n_total"] == 6, name
                assert type(metrics["reward"]) is int and metrics["reward"] == expected_reward, name
                assert assertion_raised is (expected_reward == 0), name
                writer_results.append({"case": name, "n_pass": expected_passes,
                                       "reward": expected_reward,
                                       "reward_file_hex": reward_bytes.hex(),
                                       "reward_file_text": reward_bytes.decode(),
                                       "failure_assertion_raised": assertion_raised,
                                       "passed": True})
        finally:
            grader.Path = old_path
            if old_prediction_directory is None:
                os.environ.pop(env_key, None)
            else:
                os.environ[env_key] = old_prediction_directory

    recorded_historical_hashes = {}
    for name in HISTORICAL_REPORTS[:5]:
        data = read_report(name)
        if name == "search_stability.json":
            recorded_hash = data["grader_sha256"]
        else:
            recorded_hash = next(value for key, value in data["source_sha256"].items()
                                 if key.endswith("test_kiln_bearing.py"))
        assert recorded_hash == OLD_GRADER_SHA256, (name, "historical grader provenance changed")
        recorded_historical_hashes[name] = recorded_hash

    after = {name: sha256(EVIDENCE / name) for name in HISTORICAL_REPORTS}
    assert before == after, "historical evidence changed"
    for relative, digest in {**input_hashes, **truth_hashes}.items():
        assert sha256(ROOT / relative) == digest, (relative, "scientific input or target changed")
    assert grader_path.read_bytes() == grader_bytes, "grader changed during validation"
    report = {
        "scope": "Literal binary reward-output validation and replay of saved predictions. No physical inference, Docker run or platform probe is repeated or claimed.",
        "validation_source_sha256": sha256(Path(__file__)),
        "historical_grader_sha256": OLD_GRADER_SHA256,
        "current_grader_sha256": sha256(grader_path),
        "unchanged_grading_prefix_sha256": prefix_hash,
        "unchanged_scientific_grading_prefix": True,
        "literal_assignment_and_binary_write_branches_verified": True,
        "historical_report_sha256": before,
        "historical_recorded_grader_sha256": recorded_historical_hashes,
        "historical_reports_unchanged": True,
        "input_sha256": input_hashes,
        "truth_sha256": truth_hashes,
        "scientific_inputs_and_targets_unchanged": True,
        "saved_prediction_checks": checks,
        "n_saved_prediction_checks": len(checks),
        "all_saved_grades_match": True,
        "semantic_checks": {"passed": semantic["passed"], "failed": semantic["failed"],
                            "report_byte_identical": True},
        "complete_writer_checks": writer_results,
        "output_path_redirects": {"/root/results": "temporary case/results", "/logs/verifier": "temporary case/verifier"},
        "passed": True,
    }
    output = EVIDENCE / "reward_write_validation.json"
    output.write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps({"passed": True, "saved_prediction_checks": len(checks),
                      "semantic_checks": semantic["passed"], "complete_writer_checks": len(writer_results),
                      "current_grader_sha256": report["current_grader_sha256"]}))


if __name__ == "__main__":
    main()
