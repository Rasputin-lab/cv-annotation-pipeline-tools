#!/usr/bin/env python3
"""Recheck fixed assessments with an independent Sobol seed and more starts.

The independent solver is run before the fixed report is read. The comparison
report supplies neither parameters nor optimization seeds. Agreement provides
numerical search-stability evidence, not a mathematical global certificate.
"""
import os
os.environ.setdefault('OPENBLAS_NUM_THREADS','1')
os.environ.setdefault('OMP_NUM_THREADS','1')
import argparse,hashlib,importlib.util,json,math,time
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2]
SOURCE=Path(__file__).with_name('independent_solver.py')
INPUTS=('bearing_spec.json','coupon_growth.csv','depth_calibration.csv','future_duty.csv','history.csv','inspection_options.json')

def module(name,path):
    spec=importlib.util.spec_from_file_location(name,path)
    result=importlib.util.module_from_spec(spec);spec.loader.exec_module(result)
    return result

def digest(path):return hashlib.sha256(path.read_bytes()).hexdigest()

def differences(left,right,path=''):
    if isinstance(left,dict):
        if not isinstance(right,dict):return [path+': different value types']
        errors=[]
        for key,value in left.items():
            if key not in right:errors.append(path+'/'+key+': missing key')
            else:errors.extend(differences(value,right[key],path+'/'+key))
        return errors
    if isinstance(left,list) and path.rsplit('/',1)[-1] in ('supported_models','possible_models','safe_plans','acceptable_actions'):
        return [] if isinstance(right,list) and sorted(left)==sorted(right) else [f'{path}: different set members']
    if isinstance(left,(int,float)) and not isinstance(left,bool):
        same=isinstance(right,(int,float)) and not isinstance(right,bool) and math.isclose(left,right,abs_tol=1e-6,rel_tol=1e-11)
        return [] if same else [f'{path}: {left!r} != {right!r}']
    return [] if left==right else [f'{path}: {left!r} != {right!r}']

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--data-root',type=Path)
    parser.add_argument('--assessments',type=Path,default=Path(__file__).with_name('fixed_assessments.json'))
    parser.add_argument('--output',type=Path,default=Path(__file__).with_name('search_stability.json'))
    parser.add_argument('--units',default='ABCDEFG')
    parser.add_argument('--sobol-seed',type=int,default=1907)
    parser.add_argument('--search-starts',type=int,default=14)
    parser.add_argument('--fit-count',type=int,default=32)
    args=parser.parse_args();args.output.parent.mkdir(parents=True,exist_ok=True)
    def data_path(letter):
        return args.data_root/('unit_'+letter) if args.data_root else ROOT/('environment/data' if letter=='A' else 'tests/held_out')/('unit_'+letter)
    def hashes():return {'unit_'+letter+'/'+name:digest(data_path(letter)/name) for letter in args.units for name in INPUTS}
    model=module('independent_stability',SOURCE)
    sobol=model.qmc.Sobol
    def configured_sobol(*positional,**keywords):
        keywords['seed']=args.sobol_seed
        return sobol(*positional,**keywords)
    model.qmc.Sobol=configured_sobol;model.SEARCH_STARTS=args.search_starts
    fit=model.Assessment.fit
    def configured_fit(self,count=16):return fit(self,count=args.fit_count)
    model.Assessment.fit=configured_fit
    source_sha=digest(SOURCE);input_sha=hashes();start=time.monotonic()
    report={'purpose':__doc__,'independent_source_sha256':source_sha,
            'validation_source_sha256':digest(Path(__file__)),
            'configuration':{'sobol_seed':args.sobol_seed,'search_starts':args.search_starts,'fit_count':args.fit_count},
            'input_sha256':input_sha,'units':{}}
    for letter in args.units:
        print('Checking unit_'+letter,flush=True)
        t=time.monotonic();pred,diag=model.solve_unit_with_diagnostics(data_path(letter),full_truth=True)
        report['units']['unit_'+letter]={'prediction':pred,'diagnostics':diag,'wall_seconds':time.monotonic()-t}
        args.output.write_text(json.dumps(report,indent=2,allow_nan=False)+'\n')
        print(letter,'models',pred['supported_models'],'action',pred['recommended_action'],'seconds',round(time.monotonic()-t,2),'ambiguities',len(diag['ambiguities']),flush=True)
    # Read the comparison only after all independent searches have finished.
    fixed=json.loads(args.assessments.read_text())['units']
    grader_path=ROOT/'tests/test_kiln_bearing.py';grader=module('stability_grader',grader_path)
    report['assessments_sha256']=digest(args.assessments);report['grader_sha256']=digest(grader_path)
    for name,row in report['units'].items():
        reference=fixed[name]['reference'];target=reference['diagnostics']['truth']
        checks={'truth_differences':differences(row['diagnostics']['truth'],target),
                'alternate_prediction_reference_grade':grader.grade_prediction(target,row['prediction']),
                'reference_prediction_alternate_grade':grader.grade_prediction(row['diagnostics']['truth'],reference['prediction'])}
        checks['passed']=not checks['truth_differences'] and checks['alternate_prediction_reference_grade']['passed'] and checks['reference_prediction_alternate_grade']['passed'] and not row['diagnostics']['ambiguities']
        row['comparison']=checks
    report['input_data_unchanged_during_search']=hashes()==input_sha
    report['independent_source_unchanged_during_search']=digest(SOURCE)==source_sha
    report['seconds']=time.monotonic()-start
    report['passed']=all(row['comparison']['passed'] for row in report['units'].values()) and report['input_data_unchanged_during_search'] and report['independent_source_unchanged_during_search']
    args.output.write_text(json.dumps(report,indent=2,allow_nan=False)+'\n')
    print(json.dumps({key:value for key,value in report.items() if key not in ['units','input_sha256','purpose']},indent=2),flush=True)
    if not report['passed']:raise SystemExit(1)
if __name__=='__main__':main()
