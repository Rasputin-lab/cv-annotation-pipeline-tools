#!/usr/bin/env python3
"""Audit the distinction between robustly admissible and counterfactually safe.

The deliberately wrong control removes globally inadmissible initial actions
from the full-information comparator. Such an action can still be physically
safe for a particular compatible specimen, so this restriction is invalid.

Exact original support, actual-action admissibility, conditional support and
universally safe continuation plans are supplied to the control. Only its
opportunity accounting is wrong. This is an authored scientific ablation, not
an agent probe, a trajectory replay, or a solve-rate estimate.

Run from any directory:
  python authoring/evidence/audit_opportunity.py --output /tmp/opportunity.json
"""
import argparse
import copy
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import sys
import time

os.environ.setdefault("OPENBLAS_NUM_THREADS", "1")
os.environ.setdefault("OMP_NUM_THREADS", "1")
ROOT = Path(__file__).resolve().parents[2]


def load_module(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def diagnostic_evidence(diagnostics):
    """Retain feasibility/counterexample witnesses, including rejected options."""
    return {
        "models": diagnostics["models"],
        "prefix_checks": {aid: record["prefix"]
                          for aid, record in diagnostics["actions"].items()},
        "branch_checks": {
            aid: {bid: {"support": branch["support"],
                        "counterfactuals": branch["counterfactuals"]}
                  for bid, branch in record["branches"].items()}
            for aid, record in diagnostics["actions"].items()
        },
        "near_boundary_queries": diagnostics.get("ambiguities", []),
        "solver_seconds": diagnostics["seconds"],
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--bundle", type=Path, default=ROOT)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--starts", type=int, default=12)
    args = parser.parse_args()
    root = args.bundle.resolve()
    if args.starts < 1:
        parser.error("starts must be positive")
    reference_path = root / "solution/solve_bearing.py"
    helpers_path = root / "authoring/evidence/run_ablations.py"
    grader_path = root / "tests/test_kiln_bearing.py"
    helpers = load_module(helpers_path, "opportunity_control_helpers")
    grader = load_module(grader_path, "opportunity_control_grader")
    reference = load_module(reference_path, "opportunity_control_reference")
    rows = {}
    began = time.monotonic()
    for letter in "BCDEFG":
        unit = f"unit_{letter}"
        directory = root / "tests/held_out" / unit
        truth = json.loads((directory / "truth.json").read_text())
        baseline = helpers.oracle_prediction(truth)
        baseline_grade = grader.grade_prediction(truth, baseline)
        assert baseline_grade["passed"], baseline_grade
        excluded = sorted(aid for aid, action in truth["actions"].items()
                          if not action["admissible"])
        record = {
            "excluded_counterfactual_actions": excluded,
            "oracle_baseline_prediction": baseline,
            "oracle_baseline_grade": baseline_grade,
            "input_sha256": {p.name: digest(p) for p in sorted(directory.iterdir())
                             if p.is_file() and p.suffix in (".json", ".csv")},
        }
        control = copy.deepcopy(baseline)
        if excluded:
            correct, correct_diagnostics = reference.solve_with_diagnostics(
                directory, starts=args.starts, full_truth=False)
            correct_grade = grader.grade_prediction(truth, correct)
            assert correct_grade["passed"], correct_grade
            record["unchanged_reference_prediction"] = correct
            record["unchanged_reference_grade"] = correct_grade
            record["unchanged_reference_evidence"] = diagnostic_evidence(correct_diagnostics)
            production = reference.production

            def restricted_production(model, aid, plan):
                # This is an exclusion sentinel for the descending alternative
                # search, not a physical claim of negative production. The
                # original actual action set and physical safety checks remain
                # untouched. An admissible direct STOP has zero output and is
                # safe, so the search terminates before a -1 alternative.
                return -1.0 if aid in excluded else production(model, aid, plan)

            reference.production = restricted_production
            try:
                restricted, restricted_diagnostics = reference.solve_with_diagnostics(
                    directory, starts=args.starts, full_truth=False)
            finally:
                reference.production = production
            assert restricted["supported_models"] == baseline["supported_models"]
            assert restricted["assessments"].keys() == baseline["assessments"].keys()
            differences = []
            for aid, assessment in control["assessments"].items():
                altered = restricted["assessments"][aid]
                assert altered["admissible"] == assessment["admissible"]
                if not assessment["admissible"]:
                    assert altered["policy"] == {}
                    continue
                assert altered["policy"].keys() == assessment["policy"].keys()
                for bid, branch in assessment["policy"].items():
                    other = altered["policy"][bid]
                    assert other["possible_models"] == branch["possible_models"]
                    if not branch["possible_models"]:
                        continue
                    assert other["clairvoyant_tonnes"] >= 0.0
                    evidence = restricted_diagnostics["actions"][aid]["branches"][bid]
                    assert all(item["action"] not in excluded and item["tonnes"] >= 0.0
                               for item in evidence["counterfactuals"])
                    actual = truth["actions"][aid]["branches"][bid]["production_by_plan"][branch["plan"]]
                    assert other["clairvoyant_tonnes"] >= actual - 1e-7
                    differences.append({
                        "action": aid, "branch": bid,
                        "correct_opportunity_tonnes": branch["clairvoyant_tonnes"],
                        "restricted_opportunity_tonnes": other["clairvoyant_tonnes"],
                        "understatement_tonnes": branch["clairvoyant_tonnes"] - other["clairvoyant_tonnes"],
                    })
                    # Keep every exact support and safe policy decision; change
                    # only the erroneous comparator and its consequent arithmetic.
                    branch["clairvoyant_tonnes"] = other["clairvoyant_tonnes"]
            helpers.recompute_regrets(control, truth)
            record["restricted_comparator_evidence"] = diagnostic_evidence(restricted_diagnostics)
            record["opportunity_differences"] = differences
            assert any(row["understatement_tonnes"] > 1.0 for row in differences)
        else:
            record["no_op_reason"] = (
                "Every listed action is globally admissible, so excluding "
                "globally inadmissible actions removes nothing. The control "
                "is algebraically identical to the exact oracle baseline."
            )
        record["control_prediction"] = control
        record["control_grade"] = grader.grade_prediction(truth, control)
        record["execution_status"] = "completed"
        record["interpretable_scientific_control"] = True
        if excluded:
            assert not record["control_grade"]["passed"]
        else:
            assert record["control_grade"]["passed"]
        rows[unit] = record
        print(f"{unit}: excluded={excluded}, control_pass={record['control_grade']['passed']}", flush=True)
    result = {
        "purpose": "Scientific counterfactual-opportunity ablation; not an agent probe",
        "control": "exclude_globally_inadmissible_counterfactuals",
        "description": __doc__,
        "method": {
            "oracle_aided": True,
            "unchanged": ["original model support", "actual action set and admissibility",
                          "conditional model support", "universally safe continuation choices"],
            "altered": "Only full-information opportunities, regret arithmetic and resulting recommendation",
            "exclusion_implementation": (
                "Temporarily rank globally inadmissible action/plan alternatives "
                "at -1.0, strictly below safe direct STOP at zero. This sentinel "
                "is never reported as physical production or accepted as the "
                "counterfactual opportunity. The restricted search is asserted "
                "never to reach a sentinel alternative."
            ),
            "numerical_scope": (
                "The unchanged reference uses multistart constrained numerical "
                "search. Witnesses establish feasible opportunities and unsafe "
                "specimens; search-based absence is not a formal global proof."
            ),
        },
        "settings": {"starts": args.starts},
        "source_sha256": {"audit_opportunity.py": digest(__file__),
                          "solve_bearing.py": digest(reference_path),
                          "run_ablations.py": digest(helpers_path),
                          "test_kiln_bearing.py": digest(grader_path)},
        "units": rows,
        "n_pass": sum(row["control_grade"]["passed"] for row in rows.values()),
        "n_total": len(rows),
        "binary_reward": float(all(row["control_grade"]["passed"] for row in rows.values())),
        "seconds": time.monotonic() - began,
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2, allow_nan=False) + "\n")


if __name__ == "__main__":
    main()
