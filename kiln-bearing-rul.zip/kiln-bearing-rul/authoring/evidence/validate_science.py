#!/usr/bin/env python3
"""Audit physical propagation against original-dimensional DOP853 integration.

Run from the unpacked authoring bundle after run_evidence.py. This checks
histories, permitted prefixes, future-duty block boundaries, zero-duration
records and service-limit classifications at independently obtained parameter
witnesses. It is a propagation audit, not a global inference certificate.
"""
import os
os.environ.setdefault("OPENBLAS_NUM_THREADS","1")
os.environ.setdefault("OMP_NUM_THREADS","1")
import argparse,csv,hashlib,importlib.util,json,math,time,sys
from pathlib import Path
import numpy as np
from scipy.integrate import solve_ivp

ROOT=Path(__file__).resolve().parents[2]
parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('--data-root',type=Path,help='Optional flat directory containing unit_A through unit_G')
parser.add_argument('--assessments',type=Path,default=Path(__file__).with_name('fixed_assessments.json'))
parser.add_argument('--manifest',type=Path,default=ROOT/'authoring/provenance/generation_manifest.json')
parser.add_argument('--output',type=Path,default=Path(__file__).with_name('scientific_validation.json'))
parser.add_argument('--ode-rtol',type=float,default=1e-12)
parser.add_argument('--ode-atol',type=float,default=1e-14)
parser.add_argument('--ode-step-divisions',type=int,default=24)
args=parser.parse_args()
ODE_OPTIONS={'rtol':args.ode_rtol,'atol':args.ode_atol,'div':args.ode_step_divisions}
INDEPENDENT_REPORT=args.assessments;OUTPUT=args.output
REF=Path(__file__).with_name('independent_solver.py')
GEN=ROOT/'authoring/provenance/generate_data.py'
QUAD=ROOT/'solution/solve_bearing.py'
def unit_path(name):
 return args.data_root/name if args.data_root else ROOT/('environment/data' if name=='unit_A' else 'tests/held_out')/name
def input_hashes():
 return {name+'/'+p.name:hashlib.sha256(p.read_bytes()).hexdigest()
         for name in ['unit_'+letter for letter in 'ABCDEFG']
         for p in sorted(unit_path(name).iterdir())
         if p.is_file() and p.name!='truth.json'}
def module(name,path):
 s=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
ref=module('independent_physics',REF);gen=module('dimensional_generator',GEN);quad=module('reference_physics',QUAD)
def advance(a,Z,dt,B,m,p,kappa,cap):
 result=ref.integrate(a,Z,dt,kappa,B,m,p,cap)
 return result[0],result[1]
ref.advance=advance
ref.coefficients=ref.dynamics
ref.run_prefix=ref.prefix_state
ref.run_horizon=ref.margin_at
source_hash=hashlib.sha256(REF.read_bytes()).hexdigest()
generator_hash=hashlib.sha256(GEN.read_bytes()).hexdigest()
reference_hash=hashlib.sha256(QUAD.read_bytes()).hexdigest()
manifest_hash=hashlib.sha256(args.manifest.read_bytes()).hexdigest()
assessment_hash=hashlib.sha256(INDEPENDENT_REPORT.read_bytes()).hexdigest()
data_hashes=input_hashes()
report={'audit_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'independent_sha256':source_hash,'generator_sha256':generator_hash,'reference_sha256':reference_hash,'manifest_sha256':manifest_hash,'assessments_sha256':assessment_hash,'data_sha256':data_hashes,'cases':[],'worst_horizon':{},
 'counts':{'step_comparisons':0,'safe_horizons':0,'stopped_unsafe_horizons':0,'zero_duration_checks':0},
 'max_abs_error':{'depth_mm':0.,'memory_mm':0.,'prefix_clearance_mm':0.,'horizon_clearance_mm':0.,'generator_history_state_mm':0.,'reference_depth_mm':0.,'reference_memory_mm':0.,'reference_prefix_clearance_mm':0.,'reference_horizon_clearance_mm':0.},
 'dimensional_integrator':{'method':'DOP853 with explicit retardation-release and service-limit events',**ODE_OPTIONS},
 'qualification':{'minimum_delta_k':1e99,'maximum_delta_k':0.,'maximum_service_utilization_safe_segment':0.},'failures':[]}
OUTPUT.parent.mkdir(parents=True,exist_ok=True)
start=time.time()

def metrics(spec,theta,row,a):
 Y=spec['crack_geometry']['mode_I_factor'];mat=spec['material'];peak=row[3]+theta[4]
 kmax=Y*peak*math.sqrt(math.pi*a/1000);dk=Y*(row[3]-row[2])*math.sqrt(math.pi*a/1000)
 crit=min(spec['crack_geometry']['maximum_assessed_crack_mm'],1000/math.pi*(mat['service_k_mpa_sqrt_m']/(Y*peak))**2)
 return kmax,dk,crit

def safe_guard(a,Z,dt,row,theta,spec,kind,rtol=None,atol=None,div=None):
 """Dimensional ODE split at release so a short retardation phase cannot be skipped."""
 rtol=ODE_OPTIONS['rtol'] if rtol is None else rtol
 atol=ODE_OPTIONS['atol'] if atol is None else atol
 div=ODE_OPTIONS['div'] if div is None else div
 if dt<=0:return a,Z,True,0.
 g=spec['bearing_geometry'];Y=spec['crack_geometry']['mode_I_factor'];mat=spec['material']
 cyc=60*row[1]*g['kiln_tyre_diameter_m']/g['support_roller_diameter_m']*g['rolling_elements']/2*(1-g['element_diameter_mm']/g['pitch_diameter_mm']*math.cos(math.radians(g['contact_angle_deg'])))
 peak=row[3]+theta[4];ratio=(row[2]+theta[4])/peak;kappa=Y*Y*peak*peak/(mat['plastic_zone_denominator']*mat['yield_strength_mpa']**2)
 limit=metrics(spec,theta,row,a)[2]
 if a>=limit:return a,Z,False,0.
 zone=max(Z,a*(1+kappa));release=zone/(1+kappa)
 elapsed=0.
 while elapsed<dt:
  retarded=bool(kind and a<release)
  target=min(limit,release) if retarded else limit
  def fun(_t,depth):
   crack=max(float(depth[0]),1e-12);kmax=Y*peak*math.sqrt(math.pi*crack/1000);delta=kmax*(1-ratio)
   slow=min(1.,(kappa*crack/max(zone-crack,1e-30))**theta[5]) if retarded else 1.
   return [1000*cyc*theta[1]*(delta/(mat['reference_delta_k_mpa_sqrt_m']*(1-ratio)**(1-theta[3])))**theta[2]*slow]
  def stop(_t,depth):return target-depth[0]
  stop.terminal=True;stop.direction=-1
  sol=solve_ivp(fun,(elapsed,dt),[a],method='DOP853',rtol=rtol,atol=atol,max_step=max(dt/div,1e-7),events=stop)
  if not sol.success:raise RuntimeError(sol.message)
  a=float(sol.y[0,-1]);elapsed=float(sol.t[-1])
  if len(sol.t_events[0]):
   a=target
   if target==limit:return a,max(zone,a*(1+kappa)),False,elapsed
  else:break
 return a,max(zone,a*(1+kappa)),True,elapsed

def step(a,Z,row,theta,spec,kind):
 dt=float(row[0]);end,zone,safe,elapsed=safe_guard(a,Z,dt,row,theta,spec,kind)
 if not safe:return end,zone,False

 if dt>0:
  for depth in [a,end]:
   km,dk,_=metrics(spec,theta,row,depth);q=report['qualification'];q['minimum_delta_k']=min(q['minimum_delta_k'],dk);q['maximum_delta_k']=max(q['maximum_delta_k'],dk)
   q['maximum_service_utilization_safe_segment']=max(q['maximum_service_utilization_safe_segment'],km/spec['material']['service_k_mpa_sqrt_m'])
   qrange=spec['material']['qualified_delta_k_range_mpa_sqrt_m']
   if not qrange[0]<=dk<=qrange[1]:report['failures'].append(['outside_delta_k',dk])
 return end,zone,True

def compare_step(ar,zr,aq,zq,ao,zo,row,theta,tr,model,kind):
 ga,gz=gen.ode_step(ao,zo,float(row[0]),row[1],row[2],row[3],theta,model.s,kind)
 ao,zo,safe=step(ao,zo,row,theta,model.s,kind)
 if not safe:return ar,zr,aq,zq,ao,zo,False
 report['max_abs_error']['generator_history_state_mm']=max(report['max_abs_error']['generator_history_state_mm'],abs(ga-ao),abs(gz-zo))
 qB,qk,_=quad.coefficients(tr,np.asarray(row),model.constants)
 aq,zq=quad.advance(aq,zq,float(row[0]),qB,tr[2],tr[5] if kind else 0.,qk,8.)
 report['max_abs_error']['reference_depth_mm']=max(report['max_abs_error']['reference_depth_mm'],abs(aq-ao))
 report['max_abs_error']['reference_memory_mm']=max(report['max_abs_error']['reference_memory_mm'],abs(zq-zo))
 B,k,_=ref.coefficients(tr,np.asarray(row),model.constants)
 ar,zr=ref.advance(ar,zr,float(row[0]),B,tr[2],tr[5] if kind else 0.,k,8.)
 report['counts']['step_comparisons']+=1
 for key,value in [('depth_mm',abs(ar-ao)),('memory_mm',abs(zr-zo))]:report['max_abs_error'][key]=max(report['max_abs_error'][key],value)
 return ar,zr,aq,zq,ao,zo,True

def ode_prefix(a,z,rows,theta,spec,kind):
 margin=spec['crack_geometry']['maximum_assessed_crack_mm']-a
 for row in rows:
  if row[0]<=0:continue
  limit=metrics(spec,theta,row,a)[2];margin=min(margin,limit-a)
  a,z,safe=step(a,z,row,theta,spec,kind)
  if not safe:return a,z,False,margin
  margin=min(margin,limit-a)
 return a,z,True,margin

def ode_horizon(a,z,rows,H,theta,spec,kind):
 elapsed=0.;margin=spec['crack_geometry']['maximum_assessed_crack_mm']-a
 while elapsed<H:
  for original in rows:
   row=original.copy();row[0]=min(row[0],H-elapsed)
   if row[0]<=0:return True,margin,a,z
   limit=metrics(spec,theta,row,a)[2];margin=min(margin,limit-a)
   a,z,safe=step(a,z,row,theta,spec,kind)
   if not safe:return False,margin,a,z
   margin=min(margin,limit-a);elapsed+=row[0]
 return True,margin,a,z

manifest=json.loads(args.manifest.read_text())
assessment_rows=json.loads(INDEPENDENT_REPORT.read_text())['units']
# Support both portable run_evidence output and the standalone validation driver.
independent={key.removeprefix('unit_'):row.get('independent',row) for key,row in assessment_rows.items()}
def witnesses(value):
 if isinstance(value,dict):
  if 'theta' in value and 'normalized_coordinates' in value:yield value
  for child in value.values():yield from witnesses(child)
 elif isinstance(value,list):
  for child in value:yield from witnesses(child)
for name,record in manifest.items():
 samples=[('generating',record['generating_model']=='wheeler',record['generating_parameters'])]
 diagnostic=independent[name[-1]]['diagnostics']
 for family in independent[name[-1]]['prediction']['supported_models']:
  pool=[]
  for ad in diagnostic['actions'].values():
   if family in ad.get('prefix',{}):pool.extend(witnesses(ad['prefix'][family]))
   for bd in ad.get('branches',{}).values():
    if family in bd.get('support',{}):pool.extend(witnesses(bd['support'][family]))
    for checks in bd.get('continuation_checks',{}).values():
     if family in checks:pool.extend(witnesses(checks[family]))
    for checks in bd.get('comparator_checks',[]):
     if family in checks.get('models',{}):pool.extend(witnesses(checks['models'][family]))
  chosen=[]
  for point in sorted(pool,key=lambda x:abs(x['clearance_mm'])):
   if all(np.linalg.norm(np.asarray(point['normalized_coordinates'])-np.asarray(q['normalized_coordinates']))>.08 for q in chosen):chosen.append(point)
   if len(chosen)==3:break
  for i,point in enumerate(chosen):
   raw=list(point['theta']);raw[1]=math.exp(raw[1]);samples.append((family+'_independent_witness_'+str(i),family=='wheeler',raw))
 for sample,kind,theta in samples:
  model=ref.Assessment(unit_path(name),int(kind));tr=np.asarray(theta,float).copy();tr[1]=math.log(tr[1]);a=z=theta[0];ar=zr=aq=zq=a
  case={'unit':name,'sample':sample,'kind':int(kind),'safe_horizons':0,'unsafe_horizons':0}
  # Deliberately high stress on a measurement-only row must change neither state.
  row=np.array([0.,2.4,90.,900.]);ga,gz=gen.ode_step(a,z,0.,row[1],row[2],row[3],theta,model.s,kind)
  B,k,_=ref.coefficients(tr,row,model.constants);ra,rz=ref.advance(a,z,0.,B,tr[2],tr[5] if kind else 0.,k,8.)
  report['counts']['zero_duration_checks']+=1
  if (ga,gz)!=(a,z):report['failures'].append([name,sample,'generator_zero_duration',ga-a,gz-z])
  if (ra,rz)!=(a,z):report['failures'].append([name,sample,'independent_zero_duration',ra-a,rz-z])
  qa,qz=quad.advance(a,z,0.,B,tr[2],tr[5] if kind else 0.,k,8.)
  if (qa,qz)!=(a,z):report['failures'].append([name,sample,'reference_zero_duration',qa-a,qz-z])
  for row in model.h:
   ar,zr,aq,zq,a,z,safe=compare_step(ar,zr,aq,zq,a,z,row,theta,tr,model,kind)
   if not safe:report['failures'].append([name,sample,'historical_service_failure']);break
  if not safe:continue
  for aid,action in model.actions.items():
   pa,pz,psafe,pmargin=ode_prefix(a,z,action['rows'],theta,model.s,kind)
   rpa,rpz,rpmargin=ref.run_prefix(tr,action['rows'],model.constants,int(kind),ar,zr)
   qpa,qpz,qpmargin=quad.run_prefix(tr,action['rows'],model.constants,int(kind),aq,zq)
   # A high-stress zero-duration row has no effect even at an endpoint.
   inert=np.array([[0.,2.4,90.,900.]])
   perturbed=np.vstack([inert,action['rows'],inert])
   za,zz,zm=ref.run_prefix(tr,perturbed,model.constants,int(kind),ar,zr)
   report['counts']['zero_duration_checks']+=1
   if max(abs(za-rpa),abs(zz-rpz),abs(zm-rpmargin))>1e-12:report['failures'].append([name,sample,aid,'independent_zero_prefix_load_applied'])
   qa,qz,qm=quad.run_prefix(tr,perturbed,model.constants,int(kind),aq,zq)
   if max(abs(qa-qpa),abs(qz-qpz),abs(qm-qpmargin))>1e-12:report['failures'].append([name,sample,aid,'reference_zero_prefix_load_applied'])
   if not psafe:
    if rpmargin>=0:report['failures'].append([name,sample,aid,'independent_prefix_unsafe_classification'])
    if qpmargin>=0:report['failures'].append([name,sample,aid,'reference_prefix_unsafe_classification'])
    continue
   for key,value in [('depth_mm',abs(pa-rpa)),('memory_mm',abs(pz-rpz)),('prefix_clearance_mm',abs(pmargin-rpmargin)),('reference_depth_mm',abs(pa-qpa)),('reference_memory_mm',abs(pz-qpz)),('reference_prefix_clearance_mm',abs(pmargin-qpmargin))]:report['max_abs_error'][key]=max(report['max_abs_error'][key],value)
   for plan,rows in model.future.items():
    first=rows[0,0];period=float(sum(rows[:,0]));remaining=model.H-action['elapsed']
    horizons=sorted(set([0.,first-1e-6,first,first+1e-6,period-1e-6,period,period+1e-6,min(remaining,period+first),remaining]))
    for H in horizons:
     osafe,omargin,_,_=ode_horizon(pa,pz,rows,H,theta,model.s,kind)
     rmargin=float(ref.run_horizon(tr,rows,model.constants,int(kind),rpa,rpz,H))
     qmargin=float(quad.run_horizon(tr,rows,model.constants,int(kind),qpa,qpz,H))
     zm=float(ref.run_horizon(tr,np.vstack([inert,rows,inert]),model.constants,int(kind),rpa,rpz,H))
     report['counts']['zero_duration_checks']+=1
     if abs(zm-rmargin)>1e-12:report['failures'].append([name,sample,aid,plan,H,'independent_zero_future_load_applied'])
     qm=float(quad.run_horizon(tr,np.vstack([inert,rows,inert]),model.constants,int(kind),qpa,qpz,H))
     if abs(qm-qmargin)>1e-12:report['failures'].append([name,sample,aid,plan,H,'reference_zero_future_load_applied'])
     if osafe:
      report['counts']['safe_horizons']+=1;case['safe_horizons']+=1
      if abs(omargin-rmargin)>report['max_abs_error']['horizon_clearance_mm']:
       report['worst_horizon']={'unit':name,'sample':sample,'kind':int(kind),'theta':theta,'action':aid,'plan':plan,'horizon':H,'ode_margin':omargin,'independent_margin':rmargin,'reference_margin':qmargin,'ode_prefix':[pa,pz],'independent_prefix':[rpa,rpz],'reference_prefix':[qpa,qpz]}
      report['max_abs_error']['horizon_clearance_mm']=max(report['max_abs_error']['horizon_clearance_mm'],abs(omargin-rmargin))
      report['max_abs_error']['reference_horizon_clearance_mm']=max(report['max_abs_error']['reference_horizon_clearance_mm'],abs(omargin-qmargin))
      if rmargin<0:report['failures'].append([name,sample,aid,plan,H,'independent_safe_classification'])
      if qmargin<0:report['failures'].append([name,sample,aid,plan,H,'reference_safe_classification'])
     else:
      report['counts']['stopped_unsafe_horizons']+=1;case['unsafe_horizons']+=1
      if rmargin>=0:report['failures'].append([name,sample,aid,plan,H,'independent_unsafe_classification'])
      if qmargin>=0:report['failures'].append([name,sample,aid,plan,H,'reference_unsafe_classification'])
  report['cases'].append(case)
  print(name,sample,'safe',case['safe_horizons'],'unsafe',case['unsafe_horizons'],flush=True)
  OUTPUT.write_text(json.dumps(report,indent=2)+'\n')
report['independent_unchanged_during_audit']=hashlib.sha256(REF.read_bytes()).hexdigest()==source_hash
report['reference_unchanged_during_audit']=hashlib.sha256(QUAD.read_bytes()).hexdigest()==reference_hash
report['generator_unchanged_during_audit']=hashlib.sha256(GEN.read_bytes()).hexdigest()==generator_hash
report['data_unchanged_during_audit']=input_hashes()==data_hashes
report['manifest_unchanged_during_audit']=hashlib.sha256(args.manifest.read_bytes()).hexdigest()==manifest_hash
report['assessments_unchanged_during_audit']=hashlib.sha256(INDEPENDENT_REPORT.read_bytes()).hexdigest()==assessment_hash
report['seconds']=time.time()-start
report['pass']=not report['failures'] and max(report['max_abs_error'].values())<2e-7 and report['independent_unchanged_during_audit'] and report['generator_unchanged_during_audit'] and report['reference_unchanged_during_audit'] and report['data_unchanged_during_audit'] and report['manifest_unchanged_during_audit'] and report['assessments_unchanged_during_audit']
OUTPUT.write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({k:v for k,v in report.items() if k not in ['cases','data_sha256']},indent=2),flush=True)

if not report['pass']:raise SystemExit(1)
