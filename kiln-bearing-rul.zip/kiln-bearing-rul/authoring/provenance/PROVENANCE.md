# File provenance and reproducibility

This catalogue covers the runnable task and the evidence supporting its scientific and numerical grading. Paths below are relative to the task root. Every numerical record is synthetic. No customer measurements or external agent conversations are included. Scientific references, physical qualification limits and measurement conventions are in `DATA_README.md` and every unit's copy of that document.

## Runtime task files

| File or group | Role |
| --- | --- |
| `instruction.md` | Agent-facing objective, inputs, artifact contract and evaluation conventions. |
| `task.toml` | Task identity, required author metadata, scientific explanations, artifact path and resource settings. |
| `README.md` | Difficulty, reference method, verification evidence and reproduction instructions for reviewers. |
| `environment/Dockerfile` | Agent image with pinned scientific packages and only the public example data. |
| `environment/data/unit_A/` | Complete public example, with the seven input files described below. |
| `solution/solve.sh` | Stages the reference artifact at the declared output path. |
| `solution/solve_bearing.py` | Reference inference and decision implementation using quadrature dynamics and multistart constrained optimization. |
| `tests/Dockerfile` | Separate offline verifier image, including the six private test units and the unprivileged execution tools. |
| `tests/test.sh` | Runs the artifact on private scratch copies of public unit inputs, records exit diagnostics, prevents answer/reward access and invokes grading. |
| `tests/test_kiln_bearing.py` | Semantic binary grader accepting any safe, equally optimal policy within the stated production allowance. |
| `tests/held_out/unit_B/` through `unit_G/` | Six complete graded units. Each has all seven public inputs and one private `truth.json`. |

The seven public inputs in every unit are `bearing_spec.json` (geometry, qualification, bounds and shutdown time), `history.csv` (ordered loads and bounded crack readings), `coupon_growth.csv` (material qualification measurements), `depth_calibration.csv` (historical instrument calibration), `future_duty.csv` (permitted operating plans), `inspection_options.json` (prefixes, downtime and outcome bins), and `README.md` (complete scientific and decision definitions). None depends on another unit's values. Each `truth.json` contains supported-model sets, admissibility, reachable branches, all safe plans, conditional opportunities and optimal regrets. It contains no required source-code implementation.

## Generation and fixed targets

| File in `authoring/provenance/` | Role |
| --- | --- |
| `generate_data.py` | Seeded synthetic campaign generator using a dimensional DOP853 ODE. It reads the two supporting files below and emits unit inputs and a generation manifest. |
| `policy_designs.json` | Fixed shutdown times, production schedules and inspection designs read by the generator. It contains design inputs, not grading targets. |
| `DATA_README.md` | Canonical data contract copied identically into all seven unit directories. |
| `generation_manifest.json` | Seeds, generating physical families, generating parameters and final states for physical reproduction checks. Its design hash refers to `policy_designs.json`. |
| `PROVENANCE.md` | This file catalogue. |
| `checksums.txt` | SHA-256 of every shipped file except itself, with paths relative to the task root. |

The generating physical family need not be the only family consistent with bounded measurements. Grading therefore does not compare a submission with the generating label or parameter vector. The full targets were computed from the joint compatible sets and checked against a separately implemented solver before being installed as private answers. Public inputs were regenerated in a separate directory and compared byte for byte with the shipped units.

## Numerical and scientific evidence

All files in this section are under `authoring/evidence/`. They are authoring/reviewer records and are excluded from both runtime image build contexts. The grader receives only the six private targets under `tests/held_out/`.

| Producer or implementation | Retained evidence and purpose |
| --- | --- |
| `independent_solver.py` | Separately reads the public inputs and uses adaptive log-depth RK4 propagation with Sobol initialization. Imports neither the reference, generator nor private answers. Used by the comparisons, margin audit and offline runtime validation. |
| `run_evidence.py` | `fixed_assessments.json`: complete reference and independent predictions, parameter witnesses, full safe-plan assessments, input/source hashes and reciprocal consistency checks across all seven units. |
| `validate_search.py` | `search_stability.json`: independent numerical checks with Sobol seed 1907, 14 search starts and 32 fitting starts. Full assessments agree with the reference. The report records that the saved solves were executed by a preliminary driver with the same configuration; this script is the portable reproducer. Its original execution-driver hash is historical provenance, not a missing runtime dependency. |
| `validate_science.py` | `scientific_validation.json`: dimensional DOP853 checks with explicit retardation-release events, qualification checks, zero-duration behavior and 3,326 safe/unsafe horizon comparisons. This audits propagation at retained witnesses, not global completeness of the inference search. |
| `audit_branch_margins.py` | `branch_margins.json`: independent reachable-observation interval checks and narrow-support warnings, with input/source hashes. This tests measurement-branch robustness rather than changing outcome-bin definitions. |
| `validate_grader.py` | `grader_semantic_results.json`: 51 checks of valid alternatives, unsafe choices, impossible branches, production accounting, malformed outputs and the non-stacking tie allowance. |
| `run_ablations.py` | `ablation_results.json`: five scientific controls, exact-inference baselines, per-unit outcomes and contrasts between adaptive and fixed policies. All controls fail the binary suite; their partial unit scores remain visible. |
| `audit_opportunity.py` | `opportunity_control.json`: an exact-inference control incorrectly removes globally inadmissible schedules from the same-specimen fully informed comparator. It fails unit B; the other five units are unchanged. Parameter witnesses show why an alternative unsafe for some specimens can still matter for another specimen. |
| `validate_containers.py` | `container_validation.json`: actual offline execution using the shipped staging and verifier scripts, source hashes, resource limits, exit codes, grading metrics and permission-denial audits. Three reference runs pass, three no-change runs fail, the independent implementation passes, and the answer-access control fails. |
| `self_cheat_read_truth_direct.py` | Negative control attempting sealed-answer/reward access. Its extracted result is in `self_cheat_read_truth_direct_metrics.json` and `self_cheat_read_truth_direct_reward.txt`; the permission audit in `container_validation.json` separately confirms the actual read/write denials. |
| `validate_reward_format.py` | `reward_write_validation.json`: checks explicit literal binary writes, executes the complete writer on six-pass, five-pass and zero-pass cases, repeats the 51 semantic checks and regrades 71 retained predictions. Records both grader hashes and verifies that earlier evidence and scientific inputs are unchanged. |

The reference and independent implementations use different physical propagation and initializations but both use SLSQP. Agreement, additional starts and retained feasible witnesses provide numerical evidence; they are not a mathematical global-optimization certificate. The dimensional audit provides a third propagation calculation. Scientific controls are authored omissions of specified reasoning, not replayed frontier-agent runs or estimates of Easiness/Difficulty probe success.

The final grader changes only the reward's representation and file-write branches: it writes literal `1\n` or `0\n` instead of formatting a floating-point variable. Historical source hashes in the original evidence describe the grader actually executed in those runs. They are preserved rather than relabeled. The reward-format report verifies the unchanged semantic-grader prefix, identical full grading results, unchanged targets and inputs, and the new writer's exact bytes. Its validation is the bridge from those original records to this delivered grader.

For reproducible runtime checks, first build the image tags documented in the root README and pass a new empty working directory to `validate_containers.py`. Reusing a directory resumes its saved trials. The script runs containers with networking disabled, two CPUs and 8192 MB. It checks an artifact whose transport permissions were changed to mode 0600, verifying that the harness supplies the unprivileged process a readable private copy without exposing private tests. Temporary managed-network certificates used during local image builds are not shipped or retained in image layers.

## Integrity

From the task root, `sha256sum -c authoring/provenance/checksums.txt` checks the delivered contents. Regenerating reports may change timings and therefore their hashes; regenerate the checksum manifest only after intentionally accepting those new results. Dependency caches, bytecode, raw trajectories, exploratory candidate datasets and build working directories are not part of the submission.
