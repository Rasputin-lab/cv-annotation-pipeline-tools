# Bearing-ring inspection and operating assessment

These are synthetic material tests and instrumented bearing-ring crack records. Assess opening-mode propagation of an existing long crack in a stationary outer ring. The stresses are calibrated local opening stresses from the structural assessment, not Hertz contact pressure. The geometry factor applies to this crack orientation and size range. Other damage modes are outside this assessment.

## Records and units

Every unit contains this README and six data files. `bearing_spec.json` supplies geometry, material limits, qualification bounds and hours until shutdown. `history.csv` lists successive operating blocks in chronological order; each depth reading is taken at the END of its block. Its first, zero-duration row is the initial inspection. `coupon_growth.csv` gives constant-amplitude material growth-rate intervals. `depth_calibration.csv` contains certified crack-depth standards measured with the same instrument setting as the historical inspections. `future_duty.csv` contains candidate operating plans, whose blocks repeat in `block_index` order. `inspection_options.json` supplies initial schedules and inspections. Plan and action identifiers carry no scientific information.

Depth is in mm, stress in MPa, stress intensity in MPa sqrt(m), growth rate in m/cycle, kiln speed in revolutions/minute and duration in hours. Measurement intervals and parameter bounds are inclusive. The service limits below are strict. Each unit concerns one specimen/material batch; no parameter is shared across units. Neither crack depth nor load-history memory resets between blocks or repeats. Every positive-duration block applies its stated stress cycle, including very short excursions. All required data and conventions are local.

## Material and mechanical qualification

Two established engineering model families are candidates: `walker` and `wheeler`. Neither is preselected. The applicable family or families must agree with the COMPLETE campaign, including the requirement that every historical operating block remained below the service limits. Qualification assumes a tensile residual stress constant over the assessed depth and no crack-face contact over the supplied stress cycles. Constant geometry and residual stress are local structural calibrations; they are not claims about all bearings.

The memoryless Paris–Walker family is

    da/dN = v_ref [DeltaK / (K_ref (1-R)^(1-gamma))]^m.

Here a is depth in metres, v_ref is the reference growth rate in m/cycle, m is the Paris exponent and gamma is the Walker coefficient. Coupon rates use their recorded DeltaK and R directly; residual stress is NOT added again to coupon stress ratios. Coupons and the component share v_ref, m and gamma. The admissible ranges of these and other unknowns are in `bounds`.

For a component load cycle, set

    Kmax = Y (stress_max + sigma_res) sqrt(pi*a)
    Kmin = Y (stress_min + sigma_res) sqrt(pi*a)
    DeltaK = Kmax - Kmin; R = Kmin/Kmax.

Y is the supplied mode-I geometry factor. The kiln tyre rolls without slip against the support roller. The outer ring is stationary. Each rolling-element passage across the crack supplies one cycle of the specified local stress range; cage rotation follows the conventional bearing geometry, with the listed contact angle. Derive passage cycles per hour from these mechanical quantities and the block's kiln RPM. RPM is not itself the number of fatigue cycles per hour.

The `wheeler` family multiplies the Walker rate by a plastic-zone retardation factor. Use the calibrated plane-strain convention

    r_p = Kmax^2 / (alpha*pi*yield_strength^2),

with alpha=`plastic_zone_denominator`; r_p is in metres when Kmax uses metres. Track Z, the furthest crack-tip plastic-zone boundary, in the same length unit as a. There is no prior overload memory at the initial inspection: Z=a initially. On entering every positive-duration load block, Z becomes max(Z, a+r_p). While a+r_p < Z, the growth multiplier is (r_p/(Z-a))^p, where p is `wheeler_exponent`. Otherwise the multiplier is 1. As the crack advances, Z never decreases and extends to a+r_p whenever that is larger. The same rule applies to all high-load excursions, including those in future duties. The `walker` family has multiplier 1 and no p-dependent constraint. An excursion can both advance a crack and retard its subsequent propagation. No overload life credit is justified merely because an excursion appears in the schedule.

These model conventions instantiate the Paris–Walker and Wheeler families for this synthetic qualification exercise. Wheeler's exponent is empirical and depends on material and spectrum; it is inferred here rather than transferred as a universal constant. This is a model-conditional damage-tolerance assessment, not field certification of an overload treatment.

## Metrology and compatibility

Every historical depth reading equals true depth plus ONE unknown campaign-constant offset `depth_bias_mm`. The calibration standards use the same offset: predicted reading = certified depth + offset. The lower/upper reading fields bound each observation after this common offset is applied. They are absolute measurement bounds, not standard deviations. Do not add a second row-specific systematic offset or fit independent specimen parameters to each row.

A model is supported if at least one parameter vector within all supplied bounds satisfies every coupon, calibration and historical interval simultaneously and keeps every historical block below the service limits. The zero-duration initial row is only a depth observation; it applies no load or overload-memory update. Parameters may differ between the candidate models. An inconclusive campaign can support both; report both rather than selecting the lower-residual fit. Recovering the parameter vector or model used by the data generator is not the assessment objective.

## Safety and the time horizon

Time zero for the decision is the final historical inspection. Let T be `shutdown_hours`. A trajectory is safe only while BOTH Kmax < `service_k_mpa_sqrt_m` and a < `maximum_assessed_crack_mm` throughout every operated block. The service K allowance is below fracture toughness; reaching that allowance ends the qualified assessment. Do not extrapolate to fast fracture or infer a larger limit from toughness.

Check the applicable peak stress at entrance to each positive-duration block and during its growth. A load increase can violate the allowance immediately without a depth discontinuity. At shutdown, assess the end of the block actually operated, but do not start another block whose entrance time equals T. The same convention applies at the end of a prefix. A stopped component accrues neither growth nor production. Historical compatibility also requires every historical operating block to have remained below these limits.

## Actions, measurements and conditional explanations

Each action contains `blocks`, `downtime_hours` and `measurement`. Operate its ordered prefix blocks once, then incur its inspection downtime. There are no load cycles, crack growth, production or residual-stress/memory relaxation during that brief downtime. The subsequent chosen plan begins at its block 0 and repeats until T, including a final partial block if necessary. All supplied actions finish their prefix and downtime before T. The null-measurement action has no prefix or downtime and one branch named `unobserved`; recognize it by its data, not its identifier.

An action is admissible if its entire prefix is safe for EVERY explanation compatible with the original campaign. An inadmissible action cannot be implemented as a robust policy; do not attempt to justify its prefix using information obtained only afterward.

For an inspection action, let a_end be true depth after the prefix and let e be `absolute_error_mm`. A reading can be any value in the following closed interval:

- `bias_mode: shared`: [a_end + depth_bias_mm - e, a_end + depth_bias_mm + e].
- `bias_mode: recalibrated`: [a_end - e, a_end + e].

The recalibrated bound includes its freshly bounded zero error. It does not include the historical offset. The historical offset is still the same jointly inferred parameter in all earlier measurements and all counterfactual histories. Neither measurement mode licenses refitting a different material, initial crack or historical bias for each schedule.

A bin is possible for an explanation when its closed `[lower_mm, upper_mm]` interval intersects that explanation's possible reading interval. Adjacent bins share their endpoints, so both can be reported at a boundary. The reporting bands cover all possible readings. The error bounds are not probability distributions, and no likelihood or prior over explanations or outcomes is supplied.

An explanation consists of a candidate family and ONE parameter vector satisfying the full original campaign. The branch set contains exactly those original explanations for which the action can produce that reported bin. A model remains possible in that branch if at least one such vector exists. Filtering a fitted point alone does not define the branch. The branch of a null-measurement action retains the entire original set. If no explanation supports a bin, it is unreachable and needs no operating plan.

## Production, regret and the required decision

The operator uses a conservative bounded-uncertainty decision criterion: minimize the largest production opportunity lost relative to knowing the specimen exactly. This is an explicitly chosen operating objective, not a universal rule for bearing maintenance. Inspection planning and the value of information are established damage-tolerance decisions; this exercise uses set-valued measurements rather than inventing a probability distribution.

Include `STOP` among the choices after every prefix. It means immediate maintenance after that prefix, with no subsequent cycles or production. Prefix production is retained, including for STOP. For an action d and plan p, denote by Q(d,p) the prefix's tonnes plus the chosen plan's production through the remaining time after downtime. Integrate each block's stated `production_tonnes_per_hour`, including partial blocks. Thus Q is determined by the schedule, not by uncertain crack parameters. Safety still depends on those parameters.

For a fixed compatible explanation theta, define its fully informed opportunity as

    Q_star(theta) = max Q(d,p)

where the maximum is over EVERY supplied action d and every supplied plan p or STOP whose complete physical trajectory is safe for that SAME theta. Each alternative starts from theta's original end-of-history crack and memory, follows its own prefix and incurs its own downtime. A fully informed decision-maker knows theta and does not need the inspection outcome. An action that is inadmissible for the whole original uncertainty set is still an eligible counterfactual for a theta on which it is physically safe. The comparator therefore includes all safe alternatives, even when the selected prefix changes damage or memory. Do not compare different parameter witnesses for the actual and counterfactual trajectories.

For a reachable branch B of an admissible action, the quantity to report is

    clairvoyant_tonnes(B) = max over theta in B of Q_star(theta).

Equivalently, a counterfactual strategy's deterministic production is an opportunity in B only if at least one SAME theta both belongs to B and makes that strategy safe. This is an existential joint condition. In contrast, the plan chosen to operate after that outcome must be safe for EVERY theta in B.

For a policy assigning plan p_B to each reachable branch of action d, define

    worst_regret_tonnes = max over reachable B of
                         [clairvoyant_tonnes(B) - Q(d,p_B)].

Report a policy attaining minimum worst regret for EACH admissible action, then recommend an admissible action attaining the global minimum. Report all actions; for admissible actions report every supplied bin, including unreachable ones. Alternative equally optimal policies are acceptable: a branch need not maximize its own production when a different choice leaves the action's overall worst regret optimal. There is no expectation or probability weighting in this criterion.

Use the JSON structure in `instruction.md`. For an inadmissible action report `admissible: false`, an empty `policy` and null `worst_regret_tonnes`. For an unreachable bin report empty `possible_models`, plan `UNREACHABLE` and null `clairvoyant_tonnes`. For an admissible null-measurement action report its single `unobserved` branch. If neither candidate model fits, report empty `supported_models`, empty `assessments` and recommendation `UNSUPPORTED`. Otherwise report all supported models and all listed actions, using the exact local identifiers. Model-name ordering is immaterial; repeated model names are invalid.

The verifier requires the correct original and conditional model sets, prefix admissibility, and physically safe chosen plans. Scalar production/regret reports must be within 1 tonne of their correct values. Each action's chosen policy must attain its optimum regret to within 1 tonne, and the recommended policy must attain the GLOBAL optimum to within 1 tonne. Those allowances do not accumulate: a policy 1 tonne above an action that is itself 1 tonne above the global optimum is not accepted as a global tie. No safety violation is excused by the production allowance.

## Scientific sources

- ASTM E647, public scope and significance: constant-amplitude growth data, stress-ratio dependence and load-sequence transfer limitations. https://store.astm.org/standards/e647
- AFGROW Damage Tolerance Design Handbook, section 5.2: load-interaction models and Wheeler plastic-zone retardation. https://www.afgrow.net/applications/dtdhandbook/pdfs/sec5_2_0.pdf
- NASA fracture-control handbook, overload models: https://ntrs.nasa.gov/api/citations/19950017686/downloads/19950017686.pdf
- NASA, Walker-equation fatigue-growth parameters: https://ntrs.nasa.gov/citations/20050232857
- Watanuki et al., bearing outer-ring defect/crack-growth assessment: https://doi.org/10.1111/ffe.13405

- Fatigue inspection and maintenance decisions using the value of information: https://doi.org/10.1016/j.oceaneng.2020.108286
- NIST, approaches to quantifying nondestructive-evaluation uncertainty: https://www.nist.gov/publications/three-approaches-quantification-nde-uncertainty-and-detailed-exposition-expert-panel

These sources support the model families and engineering setting. They do not supply or validate this synthetic specimen's coefficients. All information needed for the numerical contract is supplied locally; network access is unnecessary.
