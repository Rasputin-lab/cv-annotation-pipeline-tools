#!/usr/bin/env python3
"""Synthetic, ordered bearing-ring qualification campaigns.

Generation uses the dimensional Paris-Walker/Wheeler ODE, independently of
both submitted solution implementations. Moderate production excursions and
bounded metrology provide different degrees of model identification. Synthetic
coefficients are qualification scenarios, not experimentally measured steel
properties. Scientific model sources and restrictions are in DATA_README.md.
"""
import csv
import hashlib
import json
import math
import sys
from pathlib import Path
import numpy as np
from scipy.integrate import solve_ivp


def write_csv(path, rows):
    with path.open('w', newline='') as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def ode_step(a, Z, dt, rpm, low, high, theta, spec, kind):
    """Original dimensional ODE; a,Z in mm, growth material rate in m/cycle.

    Zero-duration records are measurements only and apply no load or memory update.
    """
    if dt == 0:
        return a, Z
    if dt < 0:
        raise ValueError("Block duration cannot be negative")
    v, m, g, residual, exponent, _ = theta[1:]
    geometry = spec['bearing_geometry']
    Y = spec['crack_geometry']['mode_I_factor']
    material = spec['material']
    cycles = (60 * rpm * geometry['kiln_tyre_diameter_m'] /
              geometry['support_roller_diameter_m'] * geometry['rolling_elements'] / 2 *
              (1 - geometry['element_diameter_mm'] / geometry['pitch_diameter_mm'] *
               math.cos(math.radians(geometry['contact_angle_deg']))))
    peak = high + residual
    stress_ratio = (low + residual) / peak
    kappa = Y * Y * peak * peak / (material['plastic_zone_denominator'] *
                                     material['yield_strength_mpa'] ** 2)
    Z = max(Z, a * (1 + kappa))
    def derivative(_time, depth):
        crack = max(float(depth[0]), 1e-12)
        kmax = Y * peak * math.sqrt(math.pi * crack / 1000)
        delta = kmax * (1 - stress_ratio)
        retardation = (min(1., (kappa * crack / max(Z - crack, 1e-30)) ** exponent)
                       if kind else 1.)
        return [1000 * cycles * v *
                (delta / (material['reference_delta_k_mpa_sqrt_m'] *
                          (1 - stress_ratio) ** (1 - g))) ** m * retardation]
    if dt:
        result = solve_ivp(derivative, (0, dt), [a], method='DOP853',
                           rtol=2e-11, atol=1e-13, max_step=max(dt / 12, 1e-7))
        if not result.success:
            raise RuntimeError('Dimensional ODE generation failed')
        a = float(result.y[0, -1])
    return a, max(Z, a * (1 + kappa))


PARAMETERS = [
    [.31, .020e-9, 3.75, .54, 95., 2.0, .008],
    [.29, .022e-9, 4.05, .40, 125., 2.2, -.009],
    [.33, .018e-9, 3.60, .67, 80., 2.8, .012],
    [.28, .025e-9, 4.15, .46, 110., .85, -.007],
    [.35, .016e-9, 3.80, .72, 70., .85, .006],
    [.30, .021e-9, 3.90, .34, 135., 3.0, -.010],
    [.32, .023e-9, 3.65, .63, 85., 2.0, .011],
]
KINDS = [1, 0, 1, 0, 1, 1, 0]


def generate_unit(path, seed, scenario):
    path = Path(path)
    path.mkdir(parents=True, exist_ok=True)
    if any(path.iterdir()):
        raise ValueError('Output directory must be empty')
    rng = np.random.default_rng(seed)
    i = scenario
    theta = list(PARAMETERS[i])
    kind = KINDS[i]
    policy_path = Path(__file__).with_name('policy_designs.json')
    policy = json.loads(policy_path.read_text())[str(i)]
    geometry = {'rolling_elements': 18 + i % 3, 'element_diameter_mm': 39 + 2 * i,
                'pitch_diameter_mm': 330 + 9 * i, 'contact_angle_deg': 8 + 2 * i,
                'kiln_tyre_diameter_m': 4.3 + .08 * i,
                'support_roller_diameter_m': 1.05 + .025 * i}
    spec = {
        'schema': 'bearing-inspection-policy-1',
        'component': 'stationary outer-ring opening-mode long crack',
        'bearing_geometry': geometry,
        'crack_geometry': {'mode_I_factor': 1.10 + .012 * i,
                          'ring_radial_thickness_mm': 48 + 2 * i,
                          'maximum_assessed_crack_mm': 2.0},
        'material': {'reference_delta_k_mpa_sqrt_m': 10., 'yield_strength_mpa': 1550.,
                     'plastic_zone_denominator': 6., 'service_k_mpa_sqrt_m': 32. + i * .5,
                     'fracture_toughness_mpa_sqrt_m': 55.,
                     'qualified_delta_k_range_mpa_sqrt_m': [2.5, 50.]},
        'bounds': {'initial_crack_mm': [.20, .45],
                   'reference_growth_m_per_cycle': [.004e-9, .09e-9],
                   'paris_exponent': [3., 4.8], 'walker_gamma': [.1, .95],
                   'residual_stress_mpa': [20., 210.], 'wheeler_exponent': [.7, 3.5],
                   'depth_bias_mm': [-.03, .03]},
        'shutdown_hours': policy['shutdown_hours'],
    }
    coupons = []
    for delta_k, stress_ratio in [(5., .05), (8., .05), (12., .05),
                                   (5.5, .4), (9., .4), (13., .7)]:
        rate = theta[1] * (delta_k / 10 / (1 - stress_ratio) ** (1 - theta[3])) ** theta[2]
        noise = rng.uniform(-.35, .35) * .05
        coupons.append({'delta_k_mpa_sqrt_m': delta_k, 'stress_ratio': stress_ratio,
                        'rate_lower_m_per_cycle': rate * math.exp(noise - .05),
                        'rate_upper_m_per_cycle': rate * math.exp(noise + .05)})
    calibration = []
    for depth in [.20, .50, .90]:
        value = depth + theta[-1] + rng.uniform(-.001, .001)
        calibration.append({'certified_depth_mm': depth,
                            'reading_lower_mm': value - .006,
                            'reading_upper_mm': value + .006})

    # Every campaign has three moderate excursions, changes of mean stress and
    # recovery observations. The incompletely identified campaigns are excited,
    # but have shorter recovery windows and coarser interval-bounded NDE.
    scale = [1., 1.10, 1.15, .50, .60, 1.10, 1.05][i]
    peak_shift = [110., 150., 125., 100., 145., 155., 170.][i]
    history = [
        (0, 2.4, 40, 245),
        (150 * scale, 2.4, 40, 245),
        (8, 2.3, 75, 350 + peak_shift),
        (20 * scale, 2.5, 55, 265),
        (40 * scale, 2.5, 55, 265),
        (70 * scale, 2.5, 55, 265),
        (5, 2.2, 90, 390 + peak_shift),
        (20 * scale, 2.3, 40, 245),
        (50 * scale, 2.3, 40, 245),
        (100 * scale, 2.3, 40, 245),
        (12, 2.6, 125, 335 + peak_shift),
        (180 * scale, 2.1, 60, 265),
        (160 * scale, 2.5, 45, 255),
    ]
    a = theta[0]
    Z = a
    rows = []
    width = .007 if i == 0 else (.0048 if i in [3, 4] else .0015)
    for duration, rpm, low, high in history:
        a, Z = ode_step(a, Z, duration, rpm, low, high, theta, spec, kind)
        noise = rng.uniform(-.30, .30) * width
        rows.append({'duration_hours': duration, 'kiln_rpm': rpm,
                     'stress_min_mpa': low, 'stress_max_mpa': high,
                     'reading_lower_mm': a + theta[-1] + noise - width,
                     'reading_upper_mm': a + theta[-1] + noise + width})

    # Production recipes and instrument bands are fixed decision inputs.
    # They are not uncertainty realizations or grading targets.
    plans = policy['future_duty']
    actions = policy['inspection_options']['actions']

    (path / 'bearing_spec.json').write_text(json.dumps(spec, indent=2) + '\n')
    write_csv(path / 'history.csv', rows)
    write_csv(path / 'coupon_growth.csv', coupons)
    write_csv(path / 'depth_calibration.csv', calibration)
    write_csv(path / 'future_duty.csv', plans)
    (path / 'inspection_options.json').write_text(json.dumps({'actions': actions}, indent=2) + '\n')
    contract = Path(__file__).with_name('DATA_README.md')
    if contract.exists():
        (path / 'README.md').write_bytes(contract.read_bytes())
    return {'seed': seed, 'scenario': i, 'generating_model': 'wheeler' if kind else 'walker',
            'generating_parameters': theta, 'final_true_depth_mm': a,
            'final_zone_boundary_mm': Z,
            'policy_design_sha256': hashlib.sha256(policy_path.read_bytes()).hexdigest(),
            'metrology_halfwidth_mm': width,
            'target_warning': 'Support and decisions require all compatible explanations; generating labels are not grading targets.',
            'generation_method': 'Dimensional DOP853 ODE; bounded synthetic metrology; fixed production and inspection designs.'}


if __name__ == '__main__':
    destination = Path(sys.argv[1])
    destination.mkdir(parents=True, exist_ok=True)
    manifest = {}
    for i, letter in enumerate('ABCDEFG'):
        manifest['unit_' + letter] = generate_unit(destination / ('unit_' + letter), 101 * (i + 1), i)
    (destination / 'generation_manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
