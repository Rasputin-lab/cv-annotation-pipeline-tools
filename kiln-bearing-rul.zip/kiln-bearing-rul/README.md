# Kiln bearing: inspection and damage-tolerance decisions

## Difficulty

Reliability engineers and fracture-mechanics specialists combine material qualification, component stress analysis and crack inspections to decide how damaged equipment can operate until maintenance. Here the decision is whether to inspect a cracked bearing outer ring, which permitted production schedule to use before that inspection, and how to operate after each possible result. All numerical records are synthetic. The Paris–Walker and Wheeler families are established engineering models, used within the restricted qualification in each unit's data README. Worst-case production regret is the operator's stated decision criterion; it is not presented as a universal maintenance standard.

An inspection changes both information and physical condition: the crack grows during the preceding production, while overload memory can retard later growth. A small reading can indicate a smaller crack, a shared instrument offset, or a different material response. Those explanations can agree with the complete past campaign while supporting different future operating choices. Resolving them requires coupon evidence, bearing passage kinematics, load order, residual stress, plastic-zone memory and correlated metrology to be considered together. Selecting a single best fit or mixing separately extreme parameter values does not establish safety.

The scientific judgment is whether new evidence justifies operating credit, and whether acquiring that evidence is worth its production cost and physical risk. A chosen continuation must protect every explanation still compatible with its inspection outcome. In contrast, the production opportunity foregone is available when at least one of those same explanations would safely support the alternative schedule. The actual measurement and the alternative trajectory must describe the same specimen. A later reassuring result cannot justify an initially unsafe inspection schedule. More informative inspection need not be the best decision.

Human specialists must assess model qualification, the value of correlated measurements and conservative operating decisions. Agents must preserve those distinctions across inference, conditional prediction and counterfactual comparison, rather than collapse them to one fitted trajectory or one unconditional risk envelope. The challenge is the interaction of these scientific judgments, not an undocumented rule, numerical precision contest or large input volume. Estimated expert effort is 16 hours for implementation and validation.

## Reference solution

`solution/solve_bearing.py` tests both physical families against every coupon, calibration and historical interval. It uses normalized parameters, a logarithmic growth-rate coordinate and deterministic multistart constrained search. Baseline growth is integrated analytically; retarded growth uses crack-space Gaussian quadrature and inversion. State and overload memory persist through the complete ordered load history.

For each inspection outcome, the reference conditions the original joint explanation set on the bounded reading. It tests prefix and continuation safety by minimizing finite-horizon clearance, and evaluates each counterfactual opportunity by maximizing clearance over that same conditional set. Only feasible witnesses are retained. A nonnegative-slack feasibility search checks apparently empty branches when squared penalties stall near zero. Existential success and universal failure can be established by one witness; the opposite classifications require the numerical search across starts. Search-based absence claims are not cached as permanent certificates.

`authoring/evidence/independent_solver.py` separately reads the records and propagates an adaptive log-depth ODE with RK4 step doubling, using Sobol rather than Halton initializations. It imports neither the reference, generator nor answer files. Its full assessment includes every safe continuation, not just the reference's selected policy. Both implementations use constrained SLSQP, so agreement is numerical evidence, not a mathematical proof of global optimization. A third dimensional DOP853 calculation checks physical propagation and qualification limits.

## Verification

`tests/test.sh` runs the single submitted Python artifact on six complete unseen units in a separate, offline image. It allows 8192 MB and 180 seconds per invocation. The artifact runs unprivileged, with no access to sealed tests, answer files or the reward directory. A private scratch copy supplies only the unit's public inputs, including its README. Python scientific dependencies are pinned in both images.

The semantic grader checks original and conditional model support, prefix admissibility, safe continuation choices, branch-specific fully informed opportunities, each action's achieved minimum regret and the globally optimal recommendation. Every unit must pass for binary reward 1. The 1-tonne reporting and tie allowance concerns deterministic production arithmetic; it does not permit any unsafe plan. All safe policies attaining the same optimum are accepted, including lower-production choices in noncontrolling branches. No author-selected method, generating parameter or hidden source-code convention is graded.

Local evidence in `authoring/evidence/` compares the two implementations, audits physical and measurement margins, and evaluates scientific controls against the same grader. The controls include an oracle-aided fixed continuation across inspection outcomes, an unconditioned opportunity calculation, always stopping, discarding future overload memory and treating a shared-bias inspection as recalibrated. Oracle-aided controls receive exact inference results so their failures isolate the omitted decision. Their results are not frontier-agent probe results and do not establish a remote solve rate.

The completed offline container checks give reference rewards `1, 1, 1`, no-change rewards `0, 0, 0`, independent-solution reward `1`, and direct-answer-access control reward `0`. Both correct implementations finish all six unit invocations successfully. The reference takes 88–90 seconds for the complete six-unit verification run; the independent implementation takes 169 seconds for that complete run. These are local measurements with two CPUs and 8192 MB, not platform timing guarantees. The permission audit confirms that the unprivileged artifact cannot read any sealed answer or write the verifier's reward directory.

All five scientific controls fail the binary suite: fixed continuation and unconditioned opportunity each pass only 1/6 units, always stopping passes 0/6, discarding future memory passes 4/6, and treating shared metrology as recalibrated passes 3/6. A sixth control wrongly excludes initially inadmissible schedules from the fully informed comparator; it fails unit B while the other five units remain unchanged. That control isolates the difference between a schedule unsafe for some compatible specimens and one safe for a particular specimen. The dimensional audit checks 3,326 safe or unsafe horizons with no classification discrepancies. Independent search with a second seed and increased starts reproduces every full assessment. These checks support feasibility and discrimination of the specified scientific decisions; they are not proofs of global search completeness.

The final reward writer explicitly writes literal `1\n` or `0\n` for the platform's binary-output check. `authoring/evidence/reward_write_validation.json` verifies both values, a partial-pass case, all 51 semantic checks and 71 retained predictions. Scientific inputs, private targets, the semantic grading function and all earlier evidence are unchanged. Earlier reports retain their original execution hashes and `1.0\n`/`0.0\n` runtime strings; the new report links the original and current grader hashes and verifies identical grading decisions. It does not reinterpret those earlier runs as executions of the corrected writer.

## Reproduction and provenance

Run the following from the task root with the pinned dependencies; each command writes its report in `authoring/evidence/`. Set `OPENBLAS_NUM_THREADS=1` and `OMP_NUM_THREADS=1` for comparable resource use. The provenance catalogue links every report to its producer and describes its limitations.

```sh
python3 authoring/evidence/run_evidence.py
python3 authoring/evidence/validate_search.py
python3 authoring/evidence/validate_science.py
python3 authoring/evidence/audit_branch_margins.py
python3 authoring/evidence/validate_grader.py
python3 authoring/evidence/run_ablations.py --output authoring/evidence/ablation_results.json
python3 authoring/evidence/audit_opportunity.py --output authoring/evidence/opportunity_control.json
python3 authoring/evidence/validate_reward_format.py
```

For the offline runtime checks, build `environment/` as `kiln-rul-agent:policy-20261013` and `tests/` as `kiln-rul-verifier:policy-20261013`, then run `python3 authoring/evidence/validate_containers.py <new-empty-working-directory>`. The runner requires Docker access and uses the actual `solution/solve.sh` and `tests/test.sh`. Authoring evidence is excluded from both runtime images; only the verifier image contains the sealed grading targets.

`authoring/provenance/generate_data.py <empty_directory>` reproduces the synthetic campaigns. It uses dimensional ODE integration, attaches `DATA_README.md`, and records a private generation manifest. The generating model is not necessarily the complete supported-model set and is not the grading target. [PROVENANCE.md](authoring/provenance/PROVENANCE.md) documents every shipped file's role; `authoring/provenance/checksums.txt` detects drift. Raw agent conversations, trajectory exports, exploratory candidates and dependency caches are not required by the task and are kept outside the submission.

Local checks cannot guarantee the platform's Quality review, Easiness probe, Difficulty probe or Run audit. Those gates must evaluate this exact bundle.
